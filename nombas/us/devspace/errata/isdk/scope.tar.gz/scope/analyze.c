/* analyze.c  Routines to do self-analysis.  These are useful for debugging.
 */

/************************************************************************
 *  Copyright (c) 1993-2004 Anchor Acquisition, Inc., a subsidiary of   *
 *  Openwave Systems Inc. All rights reserved.                          *
 *                                                                      *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Openwave Systems Inc. *
 *    The copyright notice above does not evidence any                  *
 *    actual or intended publication of such source code.               *
 ************************************************************************/

#define __ASSERT_FILENO__ 5

#include "srccore.h"

#if JSE_UTIL_SEGMENT==1 && !defined(SE_RELEASE_BUILD)
#if (SE_API_OBJECT_COUNT_WARNING!=0 || SE_API_STRING_COUNT_WARNING!=0)

   static uint JSE_NEAR_CALL
showAllLockedItems(struct seCall *call,const struct seapiLockItem *li,sebool want_object,sebool count_only)
{
   uint count = 0;
   uword16 api_mark = call->Global->api_mark;
   for ( ; NULL != li  &&  li->mark == api_mark; li = li->next )
   {
      if ( want_object  &&  NULL == li->str_lookup )
      {
         count++;
         if ( !count_only )
            DebugPrintf(UNISTR("   obj %08lX is locked"),li->data.obj);
      }
      else if ( !want_object  &&  NULL != li->str_lookup )
      {
         count++;
         if ( !count_only )
            DebugPrintf(UNISTR("   string %08lX (\"%s\") is locked"),\
                        li->str_lookup,li->str_lookup);
      }
      else
      {
         continue;
      }
      if ( !count_only )
      {
#        if JSE_TRACKVARS==1
#           if SEASSERT_TINY_VERSION==1
               DebugPrintf(UNISTR("  File %d, Line: %d\n"),li->file,li->line);
#           else
            {
               seconstcharptr ufile = AsciiToSechar(JSECONTEXT_FROM_CALL(call),li->file);
               DebugPrintf(UNISTR("  File %s, Line: %d\n"),ufile,li->line);
               FreeSecharString(JSECONTEXT_FROM_CALL(call),ufile);
            }
#           endif
#        else
            DebugPrintf("\n");
#        endif
      }
   }
   return count;
}


#if SE_API_OBJECT_COUNT_WARNING!=0
#define TOO_MANY_OBJECT_WARNINGS 10
void seShowIfTooManyObjects(struct seCall *call)
{
   if ( call->Global->object_count_was_warned < TOO_MANY_OBJECT_WARNINGS ) /* do not warn more than once */
   {
      /* run twice, because a GC may help free some up the first time */
      int loop;
      for ( loop = 0; loop < 2; loop++ )
      {
         uint total = showAllLockedItems(call,call->Global->api_local_lock_items.next,True,True)/*
                    + showAllLockedItems(call,call->Global->api_lock_items.next,True,True)*/;
         if ( total < SE_API_OBJECT_COUNT_WARNING )
            break;
         if ( loop == 0 )
         {
#           if JSE_GC==1
               /* a garbage collect may be enough to free it the first time through */
               secoreGarbageCollect(call);
#           endif
         }
         else
         {
            DebugPrintf(UNISTR("\n"));
            DebugPrintf(UNISTR("Warning: you have SE_API_OBJECT_COUNT_WARNING defined to show when an inefficient\n"));
            DebugPrintf(UNISTR("number of temp objects is allocated and you should use more jseFreeObject()\n"));
            DebugPrintf(UNISTR("You currently have %u api objects locked.\n"),total);
            if ( ++call->Global->object_count_was_warned == TOO_MANY_OBJECT_WARNINGS )
            {
               DebugPrintf(UNISTR("Too many warnings.  This warning will not be re-issued...\n"),total);
            }
            showAllLockedItems(call,call->Global->api_local_lock_items.next,True,False);
            /*showAllLockedItems(call,call->Global->api_lock_items.next,True,False);*/
            DebugPrintf(UNISTR("\n"));
         }
      }
   }
}
#endif

#if SE_API_STRING_COUNT_WARNING!=0
#define TOO_MANY_STRING_WARNINGS 10
void seShowIfTooManyStrings(struct seCall *call)
{
   if ( call->Global->string_count_was_warned < TOO_MANY_STRING_WARNINGS ) /* do not warn more than once */
   {
      /* run twice, because a GC may help free some up the first time */
      int loop;
      for ( loop = 0; loop < 2; loop++ )
      {
         uint total = showAllLockedItems(call,call->Global->api_local_lock_items.next,False,True)/*
                    + showAllLockedItems(call,call->Global->api_lock_items.next,False,True)*/;
         if ( total < SE_API_STRING_COUNT_WARNING )
            break;
         if ( loop == 0 )
         {
#           if JSE_GC==1
               /* a garbage collect may be enough to free it the first time through */
               secoreGarbageCollect(call);
#           endif
         }
         else
         {
            DebugPrintf(UNISTR("\n"));
            DebugPrintf(UNISTR("Warning: you have SE_API_STRING_COUNT_WARNING defined to show when an inefficient\n"));
            DebugPrintf(UNISTR("number of temp strings is allocated and you should use more jseFreeString()\n"));
            DebugPrintf(UNISTR("You currently have %u api strings locked.\n"),total);;
            if ( ++call->Global->string_count_was_warned == TOO_MANY_STRING_WARNINGS )
            {
               DebugPrintf(UNISTR("Too many warnings.  This warning will not be re-issued...\n"),total);
            }
            showAllLockedItems(call,call->Global->api_local_lock_items.next,False,False);
            /*showAllLockedItems(call,call->Global->api_lock_items.next,False,False);*/
            DebugPrintf(UNISTR("\n"));
         }
      }
   }
}
#endif

#endif /* #if (SE_API_OBJECT_COUNT_WARNING!=0 || SE_API_STRING_COUNT_WARNING!=0) */
#endif /* #if JSE_UTIL_SEGMENT==1  &&  !defined(SE_RELEASE_BUILD) */



#if SE_ANALYZER==1 && JSE_COMPILER_SEGMENT==1

#if JSE_GC==1
#if 0
   static ulong JSE_NEAR_CALL
memcount(struct seCall *call,ulong *total,ulong *pool, ulong *overhead)
{
   hSEObject hobj;
   ulong ret = 0;
#  if JSE_ONE_STRING_TABLE==0
      uint hashSize = call->Global->hashSize;
      struct HashList ** hashTable = call->Global->hashTable;
#  endif

   *total = 0;
   *pool = 0;
   *overhead = 0;

   hobj = call->Global->all_hobjs;
   while( hobj != hSEObjectNull )
   {
      wSEObject wobj;
      SEOBJECT_ASSIGN_LOCK_W(wobj,hobj);

      if( hSEMembersNull != SEOBJECT_PTR(wobj)->hsemembers  )
      {
#        if JSE_PACK_OBJECTS==0
            *total += SEOBJECT_PTR(wobj)->alloced*sizeof(struct _SEObjectMem);
            *overhead +=
               (SEOBJECT_PTR(wobj)->alloced-SEOBJECT_PTR(wobj)->used)*sizeof(struct _SEObjectMem);
#        else
            *total += SEOBJECT_PTR(wobj)->used*sizeof(struct _SEObjectMem);
#        endif
      }
      *total += sizeof(struct _SEObject);

      if( (SEOBJECT_PTR(wobj)->flags & SEOBJ_SWEEP_BIT)!=0 )
      {
         ret += sizeof(struct _SEObject);
         if( hSEMembersNull != SEOBJECT_PTR(wobj)->hsemembers )
         {
#        if JSE_PACK_OBJECTS==0
            ret += SEOBJECT_PTR(wobj)->alloced*sizeof(struct _SEObjectMem);
#        else
            ret += SEOBJECT_PTR(wobj)->used*sizeof(struct _SEObjectMem);
#        endif
         }
      }
      if( (SEOBJECT_PTR(wobj)->flags & SEOBJ_FREE_LIST_BIT)!=0 )
      {
         *pool += sizeof(struct _SEObject);
         if( hSEMembersNull != SEOBJECT_PTR(wobj)->hsemembers )
         {
#           if JSE_PACK_OBJECTS==0
               *pool += SEOBJECT_PTR(wobj)->alloced*sizeof(struct _SEObjectMem);
#           else
               *pool += SEOBJECT_PTR(wobj)->used*sizeof(struct _SEObjectMem);
#           endif
         }
      }
      SEOBJECT_PTR(wobj)->flags &= (objflag)(~SEOBJ_SWEEP_BIT);
      hobj = SEOBJECT_PTR(wobj)->hNext;
      SEOBJECT_UNLOCK_W(wobj);
   }

#  if JSE_REFCOUNT==0
   {
      struct seFunction *func;
      /* count functions */
      for( func = call->Global->funcs;func!=NULL;func = func->next )
      {
         *total += FUNCTION_IS_LOCAL(func)?
            sizeof(struct LocalFunction):
            sizeof(struct LibraryFunction);

         if( (func->flags&Func_SweepBit)!=0 )
         {
            ret += FUNCTION_IS_LOCAL(func)?
            sizeof(struct LocalFunction):
            sizeof(struct LibraryFunction);
         }
         func->flags &= (uword8)~Func_SweepBit;
      }
   }
#  endif

#  if JSE_REFCOUNT==0
   {
      seString string;
      /* count strings */
      for( string = call->Global->stringdatas;string!=NULL;string = string->prev )
      {
         *total += sizeof(*string);
         *total += string->length*sizeof(sechar);

         if( SESTR_MARKED(string)!=0 )
         {
            ret += sizeof(*string);
            ret += string->length*sizeof(sechar);
         }
         SESTR_UNMARK(string);
      }
   }
#  endif

#  if JSE_REFCOUNT==0
   {
      ulong i;
      /* ignore the string table for now, just unmark it */
      for( i = 0; i < hashSize; i++ )
      {
         struct HashList *current = hashTable[i],*next;

         while( current!=NULL )
         {
            /* Grab it first, since once we free it, we can't access it */
            next = current->next;
            current->locks &= (stringlocks)(~JSE_STRING_SWEEP_BIT);
            current = next;
         }
      }
   }
#  endif

   return ret;
}

   static void JSE_NEAR_CALL
memreport(struct seCall *call,seconstcharptr usage)
{
   ulong used,total,pool,overhead;

   used = memcount(call,&total,&pool,&overhead);

   DebugPrintf(UNISTR("      %s:\n"),usage);
   DebugPrintf(UNISTR("        total bytes:    %d\n"),total);
   DebugPrintf(UNISTR("        overhead:       %d\n"),overhead);
   DebugPrintf(UNISTR("        bytes in pools: %d\n"),pool);
   DebugPrintf(UNISTR("        locked in:      %d\n"),used);
}
#endif

   static void JSE_NEAR_CALL
memcheck(struct seCall *call)
{
   SE_UNUSED_PARAMETER(call);
#if 0

 NYI:

   struct seGlobal_ *global = call->Global;
   struct seCall *loop;
   wSEVar i;


   while( call->next!=NULL ) call = call->next;

   /* global variable cache's are on a per-call basis,
    * and just record indexes into the global, so they
    * mark nothing new. In each case, when we go to use
    * the cache, if the item is in the cache, but the
    * index doesn't match (i.e. that element is not the
    * name we are looking for), the item is just
    * purged from the cache.
    */

   for( i = call->stack_base;i<=call->stackptr;i++ )
      MARK_VARIABLE(i);

   memreport(call,UNISTR("secode stack\n"));



   loop = call;
   while( loop!=NULL )
   {
      vloop = call->tempvars;
      while( vloop!=NULL )
      {
         MARK_VARIABLE(&(vloop->value));
         MARK_VARIABLE(&(vloop->last_access));
         vloop = vloop->next;
      }
      loop = loop->next;
   }
   memreport(call,UNISTR("API tempvars\n"));


   loop = call;
   while( loop!=NULL )
   {
      MARK_OBJECT(call->hGlobalObject);
      loop = loop->prev;
   }
   memreport(call,UNISTR("global variable(s)\n"));
#endif
}
#endif /* #if JSE_GC==1 */

   static void JSE_NEAR_CALL
stringTableStuff(struct seCall *call)
{
   struct seHashList *entry;
   uint index;
   ulong totalStrings = 0;
#  if JSE_ONE_STRING_TABLE==0
      uint sehashSize = call->Global->sehashSize;
      struct seHashList ** sehashTable = call->Global->sehashTable;
#  endif

   /* string table stuff */
   DebugPrintf(UNISTR("    String Table:\n"));
   for ( index = 0; index < sehashSize; index++ )
   {
      DebugPrintf(UNISTR("      index: %d\n"),index);
      for ( entry = sehashTable[index]; NULL != entry; entry = entry->next )
      {
         DebugPrintf(UNISTR("        \"%s\"\n"),NameFromseHashList(entry));
         totalStrings++;
      }
   }
   DebugPrintf(UNISTR("      Total Strings: %ld\n"),(long)totalStrings);
}

   static void JSE_NEAR_CALL
showCallVarCounts(struct seCall *call,uint depth)
{
   secharptr depthbuf;
   uint i;

   depthbuf = (secharptr)secoreAllocEx(call,NULL,(depth*2+1),sizeof(sechar),NULL,SE_ALLOC_NOGC|SE_ALLOC_NOTHROW);
   if( depthbuf!=NULL )
   {
      SECHARPTR_PUTC(depthbuf,'\0');
      for ( i = 0; i < depth; i++ )
         strcat_sechar(depthbuf,UNISTR("  "));
      DebugPrintf(UNISTR("  %sGlobalObject = %08lX\n"),depthbuf,(ulong)(SE_POINTER_UINT)(CALL_GLOBAL(call)));
      DebugPrintf(UNISTR("  %sglobal vars = %d\n"),depthbuf,
                  SEOBJECT_GET(call,CALL_GLOBAL(call),used));
      secoreFree(call,depthbuf);
   }
}

#if JSE_GC==1
   static void JSE_NEAR_CALL
lotsOfMemoryStuff(struct seCall *call)
{
   /* show how much memory is being used where */
   DebugPrintf(UNISTR("    memory use:\n"));
   memcheck(call);

   /* string and chunk data no longer shown because they are not
    * allocated in checks, the memreport() shows all need to know
    * about them
    */
}
#endif /* #if JSE_GC==1 */

#define VISIT_ALLOC_CHUNK_SIZE   50
#define SHOW_TOO_DEEP   30 /* beyond this is some showing error */
#define SHOW_SPACE      3  /* how many space for each show */
struct visobj_ {
   hSEObject hobj;
   secharptr name;
};
struct visitedObjects
{
   struct visobj_ *visobj;
   uint count;
   sememcount alloced;
   uint depth;
   sechar spaceBuf[(SHOW_TOO_DEEP+2)*SHOW_SPACE];
   secharptr Names[SHOW_TOO_DEEP+2]; /* keep list of names as they're grown */
};
static void JSE_NEAR_CALL
showVar(struct seCall *call,rSEVar var,struct visitedObjects *visited,seconstcharptr label);
static void JSE_NEAR_CALL
showFunction(struct seCall *call,struct seFunction *func,struct visitedObjects *visited,seconstcharptr label);

   static void JSE_NEAR_CALL
prepareSpaceBuf(struct visitedObjects *visited)
{
   uint i;

   SEASSERT( visited->depth < SHOW_TOO_DEEP );
   strcpy_sechar((secharptr)(visited->spaceBuf),UNISTR(""));
   for ( i = 0; i < visited->depth; i++ )
   {
      strcat_sechar((secharptr)(visited->spaceBuf),UNISTR(".  "));
   }
}

   static void JSE_NEAR_CALL
setVisitedName(struct seCall *call,seconstcharptr name,struct visitedObjects *visited)
{
   if ( NULL != visited->Names[visited->depth] )
      secoreFree(call,visited->Names[visited->depth]);
   visited->Names[visited->depth] = secoreStrdup(call,name==NULL?UNISTR("?"):name);
}

   static void JSE_NEAR_CALL
showMembers(struct seCall *call,hSEObject hobj,struct visitedObjects *visited)
{
   sememcount used;
   struct seFunction *func;

   used = SEOBJECT_GET(call,hobj,used);
   func = SEOBJECT_GET_func(call,hobj);
   if ( NULL != func )
   {
      showFunction(call,func,visited,NULL);
   }
   if ( 0 != used )
   {
      sememcount i;

      visited->depth++;
#     if JSE_GC==1
         SEASSERT( 0 != call->Global->collect_disable ); /* following code assumes it won't move around */
#     endif
      for ( i = 0; i < used; i++ )
      {
         seconstcharptr name;
         secharptr alloc_name = NULL;
         seVarName vname;
         hSEMembers mems;
         sechar buf[40];

         mems = SEOBJECT_GET(call,hobj,hsemembers);
         vname = SEMEMBERS_GET(call,mems,i,name);
         if ( SE_NO_VARNAME == vname )
         {
            se_sprintf((secharptr)buf,UNISTR("[idx: %lu]"),(ulong)i);
            name = (seconstcharptr)buf;
         }
         else
         {
            name = GetSEStringTableEntry(call,SEMEMBERS_GET(call,mems,i,name),NULL);
            if ( IS_HIDDEN_PROP(vname) )
            {
               seconstcharptr hidden_tag = UNISTR(" [HIDDEN]");
               alloc_name = secoreAlloc(call,NULL,\
                  (sememcount)(bytestrlen_sechar(name) + bytestrsize_sechar(hidden_tag)),SE_DEFAULT);
               if ( NULL != alloc_name )
               {
                  se_sprintf(alloc_name,UNISTR("%s%s"),name,hidden_tag);
                  name = (seconstcharptr)alloc_name;
               }
            }
         }
         setVisitedName(call,name,visited);
         mems = SEOBJECT_GET(call,hobj,hsemembers);
         showVar(call,SEMEMBERS_GET_sevar(call,mems,i),visited,name);
         if ( NULL != alloc_name )
            secoreFree(call,alloc_name);
      }
      visited->depth--;
   }
}

   static sint JSE_NEAR_CALL
addShownObject(struct seCall *call,hSEObject hobj,struct visitedObjects *visited)
   /* return 0 if this is newly added, else return index of previous+1.
    * return -1 on error.
    */
{
   uint i;

   /* if already in the list return False and do nothing */
   for ( i = visited->count; 0 != i--; )
   {
      if ( visited->visobj[i].hobj == hobj )
         return (sint)(i+1);
   }

   /* allocate more room if needed */
   if ( ++(visited->count) == visited->alloced )
   {
      struct visobj_ *new_visobj = (struct visobj_ *)
         secoreAllocEx(call,visited->visobj,(size_t)(visited->alloced + VISIT_ALLOC_CHUNK_SIZE),sizeof(struct visobj_),
                       &(visited->alloced),SE_ALLOC_NOGC | SE_ALLOC_NOTHROW);

      if( new_visobj )
      {
         visited->visobj = new_visobj;
      }
      else
      {
         return -1;
      }
   }
   HSEOBJECT_BRUTE_ASSIGN(visited->visobj[visited->count-1].hobj,hobj);
   {
      secharptr concat;
      sememcount concat_len = sizeof_sechar('\0');

      for ( i = 0; i <= visited->depth; i++ )
      {
         concat_len += (sememcount)bytestrlen_sechar(visited->Names[i]);
         if ( i != 0 )
            concat_len += sizeof_sechar('.');
      }
      concat = (secharptr)secoreAlloc(call,NULL,concat_len,SE_ALLOC_NOGC | SE_ALLOC_NOTHROW);
      if( concat==NULL ) return -1;
      strcpy_sechar(concat,visited->Names[0]);
      for ( i = 1; i <= visited->depth; i++ )
      {
         strcat_sechar(concat,UNISTR("."));
         strcat_sechar(concat,visited->Names[i]);
      }
      visited->visobj[visited->count-1].name = concat;
   }
   return 0;
}

   static void JSE_NEAR_CALL
showObject(struct seCall *call,hSEObject hobj,struct visitedObjects *visited,seconstcharptr label)
{
   SEASSERT( call->next == NULL );
   if ( hSEObjectNull != hobj )
   {
      sint seen_before;

      if ( label != NULL )
      {
         setVisitedName(call,label,visited);
      }

      seen_before = addShownObject(call,hobj,visited);
      prepareSpaceBuf(visited);
      if( seen_before==-1 )
      {
         DebugPrintf(UNISTR(" [Out of Memory]"));
      }
      else
      {
         if ( label == NULL )
         {
            DebugPrintf(UNISTR(" [%08lX]"),(ulong)(SE_POINTER_UINT)hobj);
         }
         else
         {
            DebugPrintf(UNISTR("      %s%s [%08lX]"),
                        visited->spaceBuf,
                        label,(ulong)(SE_POINTER_UINT)hobj);
         }
#        if JSE_DYNAMIC_CALLBACKS==1
            if ( NULL != SEOBJECT_GET_callbacks(call,hobj) )
            {
               DebugPrintf(UNISTR(" [callbacks:%08lX]"),(ulong)SEOBJECT_GET_callbacks(call,hobj));
            }
#        endif
         if ( seen_before==0 )
         {
            DebugPrintf(UNISTR("\n"));
            showMembers(call,hobj,visited);
         }
         else
         {
            DebugPrintf(UNISTR(" <revisited: %s>\n"),visited->visobj[seen_before-1].name);
         }
      }
   }
}

   static void JSE_NEAR_CALL
showAPIItem(struct seCall *call,struct seapiLockItem *apiItem,struct visitedObjects *visited)
{
#  if JSE_TRACKVARS==1  &&   SEASSERT_TINY_VERSION==0
      seconstcharptr unifile;
#  endif
   if ( NULL == apiItem->str_lookup )
   {
      SEASSERT( seLI_GET_TYPE(apiItem->flags) == seLI_OBJECT );
      if( 0 == (apiItem->flags & seLI_WEAK) )
      {
         seconstcharptr label;
#        if JSE_TRACKVARS==1
#           if SEASSERT_TINY_VERSION==1
               sechar label_buf[50];
#           else
               sechar label_buf[200];
#           endif
#           if SEASSERT_TINY_VERSION==1
               se_sprintf((secharptr)label_buf,UNISTR("[api object file:%d line:%d]"),apiItem->file,apiItem->line);
               label = (seconstcharptr)label_buf;
               SEASSERT( bytestrsize_sechar(label) < sizeof(label_buf) );
#           else
               unifile = AsciiToSechar(JSECONTEXT_FROM_CALL(call),apiItem->file);
               se_sprintf((secharptr)label_buf,UNISTR("[api object file:%s line:%d]"),unifile,apiItem->line);
               label = (seconstcharptr)label_buf;
               SEASSERT( bytestrsize_sechar(label) < sizeof(label_buf) );
               FreeSecharString(JSECONTEXT_FROM_CALL(call),unifile);
#           endif
#        else
            label = UNISTR("[api object]");
#        endif
         showObject(call,apiItem->data.obj,visited,label);
         showObject(call,apiItem->hSavedScopeChain,visited,UNISTR("[api savedScopeChain]"));
      }
   }
   else
   {
#     if JSE_TRACKVARS==1
#        if SEASSERT_TINY_VERSION==1
            DebugPrintf(UNISTR("   API Locked String (file:%d line:%d) = %s\n"),\
                        apiItem->file,apiItem->line,apiItem->str_lookup);
#        else
            unifile = AsciiToSechar(JSECONTEXT_FROM_CALL(call),apiItem->file);
            DebugPrintf(UNISTR("   API Locked String (file:%s line:%d) = %s\n"),\
                        unifile,apiItem->line,apiItem->str_lookup);
            FreeSecharString(JSECONTEXT_FROM_CALL(call),unifile);
#        endif
#     else
         DebugPrintf(UNISTR("  API Locked String = %s\n"),apiItem->str_lookup);
#     endif
   }
}

   static void JSE_NEAR_CALL
showVar(struct seCall *call,rSEVar var,struct visitedObjects *visited,seconstcharptr label)
{
   seconstcharptr type;

   SEASSERT( call->next == NULL );
   prepareSpaceBuf(visited);
   switch ( var->type )
   {
      case VNumber:     type = UNISTR("number");   break;
      case VString:
      case VShortString:
         type = UNISTR("string");   break;
      case VObject:     type = UNISTR("object");   break;
      case VNull:       type = UNISTR("null");     break;
      case VUndefined:  type = UNISTR("undefined");break;
      case VBoolean:    type = UNISTR("boolean");  break;
      case VStorage:    type = UNISTR("VStorage"); break;
#     if JSE_COMPACT_LIBFUNCS==1
      case VLibFunc:    type = UNISTR("VLibFunc"); break;
#     endif
      case VReference:  type = UNISTR("VReference");break;
      case VReferenceIndex:type=UNISTR("VReferenceIndex");break;
      default:
         type = UNISTR("!!!UNKNOWN!!!");
         SEASSERT( False );
         break;
   }
   DebugPrintf(UNISTR("      %s%s%s[%08lX] %s"),
               visited->spaceBuf,
               NULL==label?UNISTR(""):label,NULL==label?UNISTR(""):UNISTR(" "),
               (ulong)(SE_POINTER_UINT)var,type);
   if ( var->type != VObject )
      DebugPrintf(UNISTR("\n"));
   switch( (var)->type )
   {
      case VObject:
         showObject(call,SEVAR_GET_OBJECT(var),visited,NULL);
         showObject(call,(var)->data.object_val.hSavedScopeChain,visited,UNISTR("[[hSavedScopeChain]]"));
         break;
      case VReference:
      {
         seconstcharptr ref;
         ref = GetSEStringTableEntry(call,(var)->data.ref_val.reference,NULL);
         showObject(call,(var)->data.ref_val.hBase,visited,ref);
      }  break;
      case VReferenceIndex:
         showObject(call,(var)->data.ref_val.hBase,visited,UNISTR("[[hBase]]"));
         break;
      default:
         break;
   }
}

   static void JSE_NEAR_CALL
showFunction(struct seCall *call,struct seFunction *func,
             struct visitedObjects *visited,seconstcharptr label)
{
   SEASSERT( NULL != func );
   visited->depth++;
   if ( NULL == label )
   {
      label = UNISTR("");
   }
#  if JSE_MULTIPLE_GLOBAL==1
   {
      seconstcharptr name = UNISTR("[[function->hglobal_object]]");
      secharptr tmp = (secharptr)secoreAlloc(call,NULL,(sememcount)(bytestrlen_sechar(label)+bytestrsize_sechar(name)), \
                                             SE_ALLOC_NOGC | SE_ALLOC_NOTHROW);

      if( tmp!=NULL )
      {
         strcpy_sechar(tmp,label);
         strcat_sechar(tmp,name);
         showObject(call,(func)->hglobal_object,visited,tmp);
         secoreFree(call,tmp);
      }
      else
      {
         showObject(call,(func)->hglobal_object,visited,name);
      }
   }
#  endif
   if( FUNCTION_IS_LOCAL((func)) )
   {
      showObject(call,((struct LocalFunction *)(func))->hConstants,visited,UNISTR("[[hConstants]]"));
   }
   visited->depth--;
}

#if JSE_SECUREJSE==1
   static void JSE_NEAR_CALL
showSecurityVars(struct seCall *call,struct visitedObjects *visited)
{
   struct Security *sloop;
   for ( sloop = call->Global->allSecurity; sloop != NULL; sloop = sloop->next )
   {
      uint i;

      for( i=0;i<sloop->accept.Used;i++ )
      {
         SEASSERT( sloop->accept.Funcs[i]!=NULL );
         showFunction(call,sloop->accept.Funcs[i],visited,UNISTR("[[acceptFuncs]]"));
      }
      for( i=0;i<sloop->guard.Used;i++ )
      {
         SEASSERT( sloop->guard.Funcs[i]!=NULL );
         showFunction(call,sloop->guard.Funcs[i],visited,UNISTR("[[guardFuncs]]"));
      }
      showObject(call,sloop->hObj[SECURITY_OBJ_VARIABLE],visited,UNISTR("[[[hObj[SECURITY_OBJ_VARIABLE]]]"));
      showObject(call,sloop->hObj[SECURITY_OBJ_GUARD],visited,UNISTR("[[[hObj[SECURITY_OBJ_GUARD]]]"));
      showObject(call,sloop->hObj[SECURITY_OBJ_INIT],visited,UNISTR("[[[hObj[SECURITY_OBJ_INIT]]]"));
      showObject(call,sloop->hObj[SECURITY_OBJ_TERM],visited,UNISTR("[[[hObj[SECURITY_OBJ_TERM]]]"));
   }
}
#endif

   static void JSE_NEAR_CALL
showAllCallLocks(struct seCall *call,struct visitedObjects *visited)
{
   struct seCall *endCall = call->end;
   struct seCall *reverse_call;

   SEASSERT( 0 == visited->depth );

   showObject(endCall,CALL_GLOBAL(call),visited,UNISTR("[[GlobalObject]]"));

#  if SE_LOCK_PROTOTYPE_CACHE==1
   if ( call->PrototypeCache.locked )
#  else
   if ( CALL_GLOBAL(call) == call->PrototypeCache.GlobalObject )
#  endif
   {
      SEASSERT( hSEObjectNull != CALL_GLOBAL(call) );
      showObject(endCall,call->PrototypeCache.Object,visited,UNISTR("[[PrototypeCache.Object]]"));
      showObject(endCall,call->PrototypeCache.Function,visited,UNISTR("[[PrototypeCache.Function]]"));
      showObject(endCall,call->PrototypeCache.Array,visited,UNISTR("[[PrototypeCache.Array]]"));
      showObject(endCall,call->PrototypeCache.String,visited,UNISTR("[[PrototypeCache.String]]"));
   }

   showObject(endCall,call->hDynamicDefault,visited,UNISTR("[[hDynamicDefault]]"));

   showObject(endCall,call->hScopeChain,visited,UNISTR("[[hScopeChain]]"));
   showVar(endCall,CALL_NEWSCOPE(call),visited,UNISTR("[[new_scope_chain]]"));
   showObject(endCall,CALL_VAROBJ(call),visited,UNISTR("[[hVariableObject]]"));

   if( CALL_ERROR(endCall) )
      showVar(endCall,&(call->return_var),visited,UNISTR("[[return_var]]"));

   showObject(endCall,call->wrapper_temp,visited,UNISTR("[[wrapper_temp]]"));
   showObject(endCall,call->Global->api_services,visited,UNISTR("[[services]]"));
   {
      struct seapiLockItem *apiloop = call->Global->api_local_lock_items.next;

      while( apiloop )
      {
         showAPIItem(endCall,apiloop,visited);
         apiloop = apiloop->next;
      }
   }

#  if JSE_COMPACT_LIBFUNCS==1 && JSE_MULTIPLE_GLOBAL==1
   {
      struct secoreLibrary *myLib;
      for ( myLib = call->TheLibrary; myLib != NULL; myLib = myLib->next )
      {
         if ( myLib->global != hSEObjectNull )
            showObject(endCall,myLib->global,visited,UNISTR("[[CompactFunctionLib->global]]"));
      }
   }
#  endif

   for( reverse_call = endCall; reverse_call != NULL; reverse_call = reverse_call->prev )
   {
      STACKPTR base;
      STACKPTR end;
      struct functionSave *fsave_loop;

      base = reverse_call->save.stackbase;
      end = reverse_call->stackptr;
      fsave_loop = &(reverse_call->save);

      do
      {
         struct functionSave *old_loop = NULL;

         if( reverse_call->next==NULL ||
             base!=reverse_call->next->save.stackbase )
         {
            wSEVar i;

            for( i = base;i<=end;i++ )
            {
               showVar(endCall,i,visited,UNISTR("[[stack variable]]"));
            }
         }

         /* find the next stack */
         old_loop = fsave_loop;

         for ( ; ; )
         {
            fsave_loop = fsave_loop->prev;
            if( fsave_loop==NULL ) break;
            if( fsave_loop->stackbase!=old_loop->stackbase )
            {
               base = fsave_loop->stackbase;
               end = fsave_loop->saved_stackptr;
            }
         }
      }
      while( fsave_loop!=NULL );
   }
}

   static void JSE_NEAR_CALL
showAllCallInformation(struct seCall *call)
{
   sechar buffer[500];
   struct seCall *next;
   struct seCall *prev;
   struct seCall *fiber_loop;
   struct seCall *base_call;
   struct seCall *endCall = call;
   struct visitedObjects *visited;
   uint i;

#  if JSE_GC==1
   {
      uword16 old_collect_disable;
      DebugPrintf(UNISTR("  BEFORE GARBAGE COLLECTION:\n"));
      lotsOfMemoryStuff(call);

      old_collect_disable = call->Global->collect_disable;
      call->Global->collect_disable = 0;
      secoreGarbageCollect(call);
      call->Global->collect_disable = old_collect_disable;

      DebugPrintf(UNISTR("  AFTER GARBAGE COLLECTION:\n"));
      lotsOfMemoryStuff(call);
   }
#  endif

   stringTableStuff(call);

   /* first get to the base of this call-chain */
   fiber_loop = call->start;

   /* then to the base of all fibers */
#  if JSE_TASK_SCHEDULER==1
   while( fiber_loop->fiber_prev ) fiber_loop = fiber_loop->fiber_prev;

   for( ;fiber_loop!=NULL;fiber_loop = fiber_loop->fiber_next )
#  endif
   {
      call = fiber_loop;

      DebugPrintf(UNISTR("  call = %08lX\n"),(ulong)(SE_POINTER_UINT)call);
      showCallVarCounts(call,1);

      /* show all prev calls */
      strcpy_sechar((secharptr)buffer,UNISTR("call"));
      prev = call;
      while ( NULL != (prev=prev->prev) )
      {
         strcat_sechar((secharptr)buffer,UNISTR("->prev"));
         DebugPrintf(UNISTR("  %s = %08lX\n"),buffer,(ulong)(SE_POINTER_UINT)prev);
         showCallVarCounts(prev,1);
      }

      /* show all next calls */
      strcpy_sechar((secharptr)buffer,UNISTR("call"));
      next = call;
      while ( NULL != (next=next->next) )
      {
         strcat_sechar((secharptr)buffer,UNISTR("->next"));
         DebugPrintf(UNISTR("  %s = %08lX\n"),buffer,(ulong)(SE_POINTER_UINT)next);
         showCallVarCounts(next,1);
      }

      DebugPrintf(UNISTR("  stack offset = %lu\n"),(long)(call->stackptr - call->save.stackbase));

      DebugPrintf(UNISTR("  GlobalObject %08lX\n"),(ulong)(SE_POINTER_UINT)(CALL_GLOBAL(call)));
   }

   /* show all locks on variables, and why they're locked */
   visited = (struct visitedObjects *)secoreAllocEx(call,NULL,1,sizeof(*visited),\
      NULL,SE_ALLOC_NOGC | SE_ALLOC_NOTHROW | SE_ALLOCEX_ZERO_FILL);
   if( visited==NULL )
   {
      DebugPrintf(UNISTR("[memory allocation failure.]"));
      return;
   }

   visited->visobj = (struct visobj_ *)secoreAllocEx(call,NULL,VISIT_ALLOC_CHUNK_SIZE,sizeof(struct visobj_),
      &(visited->alloced),SE_ALLOC_NOGC | SE_ALLOC_NOTHROW);

   if( visited->visobj==NULL )
   {
      secoreFree(call,visited);
      DebugPrintf(UNISTR("[aborted due to memory allocation failure.]"));
      return;
   }

   for ( i = 0; i < (sizeof(visited->Names)/sizeof(visited->Names[0])); i++ )
   {
      visited->Names[i] = secoreStrdup(call,UNISTR("?"));

      if( visited->Names[i]==NULL )
      {
         while( i>0 )
         {
            i--;
            secoreFree(call,visited->Names[i]);
         }

         secoreFree(call,visited->visobj);
         secoreFree(call,visited);
         DebugPrintf(UNISTR("[aborted due to memory allocation failure.]"));
         return;
      }
   }

   DebugPrintf(UNISTR("   ================== BEGIN OBJECT TREE ==================\n"));
   /* get to the base of the call/fiber chain */
   call = call->start;
   fiber_loop = call;
#  if JSE_TASK_SCHEDULER==1
   while ( NULL != fiber_loop->fiber_prev )
      fiber_loop = fiber_loop->fiber_prev;
#  endif
   base_call = fiber_loop;
   DebugPrintf(UNISTR("   ROOT CONTEXT [%08lX]\n"),(ulong)(SE_POINTER_UINT)fiber_loop);
#  if JSE_TASK_SCHEDULER==1
   for ( ; fiber_loop != NULL; fiber_loop = fiber_loop->fiber_next )
#  endif
   {
#     if JSE_TASK_SCHEDULER==1
      if ( NULL != fiber_loop->fiber_prev )
         DebugPrintf(UNISTR("   FIBER [%08lX]\n"),(ulong)(SE_POINTER_UINT)fiber_loop);
#     endif
      for ( call = fiber_loop; NULL != call; call = call->next )
      {
         if ( call != fiber_loop )
            DebugPrintf(UNISTR("   NEXT CALL [%08lX]\n"),(ulong)(SE_POINTER_UINT)call);
         showAllCallLocks(call,visited);
         SEASSERT( 0 == visited->depth );
      }
   }
#  if JSE_SECUREJSE==1
      DebugPrintf(UNISTR("   SECURITY VARS\n"));
      showSecurityVars(base_call,visited);
#  endif
   showObject(base_call->end,base_call->Global->global_temp,visited,UNISTR("[[global_temp]]"));
   {
      struct seapiLockItem *apiloop = base_call->Global->api_lock_items.next;

      while( apiloop )
      {
         showAPIItem(base_call->end,apiloop,visited);
         apiloop = apiloop->next;
      }
   }
   /* show all variables locked in recent callback savers */
   {
      struct seCallbackSaver *callback_saver;
      for ( callback_saver = base_call->Global->recentCallbackSaver;
            callback_saver != NULL;
            callback_saver = callback_saver->prev )
      {
         DebugPrintf(UNISTR("   SAVED DURING CALLBACKS\n"));
         showVar(endCall,&(callback_saver->return_var),visited,UNISTR("[[return_var]]"));
         showObject(endCall,callback_saver->wrapper_temp,visited,UNISTR("[[wrapper_temp]]"));
      }
   }
   DebugPrintf(UNISTR("   ================== END OBJECT TREE ==================\n"));
   for ( i = 0; i < visited->count; i++ )
   {
      secoreFree(endCall,visited->visobj[i].name);
   }
   for ( i = 0; i < (sizeof(visited->Names)/sizeof(visited->Names[0])); i++ )
   {
      if ( NULL != visited->Names[i] )
         secoreFree(endCall,visited->Names[i]);
   }
   secoreFree(endCall,visited->visobj);
   secoreFree(endCall,visited);
}

void seInternalAnalysis(struct seCall *call)
{
   DebugPrintf(UNISTR("start seInternalAnalysis\n"));
   SYNCH_PROTOTYPE_CACHE(call);
#  if JSE_GC==1
      DebugPrintf(UNISTR("  collect_disable was %d\n"),call->Global->collect_disable);
      call->Global->collect_disable++;
#  endif
#  if JSE_TRACK_MEMUSE==1
#     if JSE_MULTI_CORE==1
         jseFuncs(call)->jsememDisplayMemuseFunc(call->Global->Params.allocator_cookie);
#     else
         jsememDisplayMemuse(call->Global->Params.allocator_cookie);
#     endif
#  endif
   showAllCallInformation(call);
#  if JSE_GC==1
      call->Global->collect_disable--;
#  endif

#  if JSE_TRACK_MEMUSE==1
#     if JSE_MULTI_CORE==1
         jseFuncs(call)->jsememDisplayMemuseFunc(call->Global->Params.allocator_cookie);
#     else
         jsememDisplayMemuse(call->Global->Params.allocator_cookie);
#     endif
#  endif

   DebugPrintf(UNISTR("end seInternalAnalysis\n"));
   DebugPrintf(UNISTR("\n"));
}

#else

   ALLOW_EMPTY_FILE

#endif /* #if SE_ANALYZER==1 && JSE_COMPILER_SEGMENT==1 */
