/* Garbage.c  - This is the garbage collector. It also has routines
 *              for allocating the items it later collects. See
 *              'srccore/var.h' for a thorough description.
 */

/************************************************************************
 *  Copyright (c) 1993-2004 Anchor Acquisition, Inc., a subsidiary of   *
 *  Openwave Systems Inc. All rights reserved.                          *
 *                                                                      *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Openwave Systems Inc. *
 *    The copyright notice above does not evidence any                  *
 *    actual or intended publication of such source code.               *
 ************************************************************************/

#define __ASSERT_FILENO__ 7

#include "srccore.h"

#if JSE_COMPILER_SEGMENT==1

/* define string that must fit into VSHORTSTRING to be used as last-ditch if stralloc fails */
#define STR_ALLOC_FAILURE  UNISTR("err")

   seconstcharptr
#if JSE_MEMEXT_STRINGS==1
sevarGetStrEx(struct seCall *call,rSEVar var,sememcount *len,sememcount *bytelen)
#else
sevarGetStrEx(rSEVar var,sememcount *len,sememcount *bytelen)
#endif
{
   seString string_val;

   SEASSERT( VString == var->type  ||  VShortString == var->type );

   if ( VShortString == var->type )
   {
      *len = var->data.shortstr[0];
#     if (JSE_MBCS==1)
         *bytelen = (*len) & 0x0F;
         *len = ((*len) >> 4) & 0x0F;
#     else
         *bytelen = BYTECOUNT_FROM_STRLEN(NULL,(*len));
#     endif
#     ifdef DISABLE_VSHORTSTRING_FOR_DEBUGGING
         SEASSERT( !strcmp_sechar( &(var->data.shortstr[1]), STR_ALLOC_FAILURE ) );
#     endif
      return &(var->data.shortstr[1]);
   }

   string_val = var->data.string_val;
   *len = string_val->length;
#  if JSE_MBCS==1
      *bytelen = string_val->bytelength;
#  else
      *bytelen = BYTECOUNT_FROM_STRLEN(NULL,(*len));
#  endif

   return SESTRING_GET_DATA(call,string_val);
}

   static void JSE_NEAR_CALL
sevarStrAllocFailure(struct seCall *call,wSEVar var)
{
   /* this must fit within shortstring */
   SEASSERT( bytestrlen_sechar(STR_ALLOC_FAILURE) <= (sizeof(var->data)-sizeof(secharptrdatum)) );
   SEVAR_INIT_STR(call,var,STR_ALLOC_FAILURE,SIS_CALC_ASCIICHAR,SIS_CALC_ASCIICHAR);
   SEASSERT( VShortString == var->type );
}

   void
sevarInitString(struct seCall *call,wSEVar var,seconstcharptr mem,
                SE_POINTER_UINDEX len,   /* may be SIS_CALC_SECHAR or SIS_CALC_ASCIICHAR to calculate */
#               if JSE_MBCS==1
                   SE_POINTER_UINDEX bytelen, /* maybe SIS_CALC_SECHAR or SIS_CALC_ASCIICHAR to calculate */
#               endif
                int sevarIS_flags)
{
#  if JSE_POOL_STRINGDATA==1  ||  JSE_REFCOUNT==0
      struct seGlobal_ *global = call->Global;
#  endif
   seString ret;
#  if JSE_POOL_STRINGDATA==1
      sebool cached;
#  endif
#  if JSE_MBCS==0
      SE_POINTER_UINDEX bytelen;
#  endif
   int allocate = sevarIS_flags & sevarIS_allocate;
   int should_free = sevarIS_flags & sevarIS_should_free;

   if ( SIS_CALC_ANY(len) )
   {
      /* coded value was passed in to calculate length from the length of null-termed string */
      SEASSERT( mem != NULL );
      if ( len == SIS_CALC_SECHAR )
      {
         len = (sememcount) strlen_sechar(mem);
      }
      else
      {
         SEASSERT( len == SIS_CALC_ASCIICHAR );
#        if JSE_MBCS==1
            len = (sememcount) strlen(mem);
            /* was a mistake to call if not all ascii characters */
            SEASSERT( len == strlen_sechar(mem) );
#        else
            len = (sememcount)strlen_sechar(mem);
#        endif
      }
   }

#  if JSE_MBCS==1
      if ( SIS_CALC_ANY(bytelen) )
      {
         SEASSERT( mem != NULL  ||  len==0 );
         if ( bytelen == SIS_CALC_SECHAR )
         {
            bytelen = BYTECOUNT_FROM_STRLEN(mem,len);
         }
         else
         {
            SEASSERT( bytelen == SIS_CALC_ASCIICHAR );
            bytelen = len;
            SEASSERT( bytelen = BYTECOUNT_FROM_STRLEN(mem,len) );
         }
      }
#  else
      bytelen = BYTECOUNT_FROM_STRLEN((secharptr)mem,len);
#  endif

   /* if this is short enough to fit in data itself, then do so */
   if ( (bytelen <= (sizeof(var->data)-sizeof(secharptrdatum)))
     && 0==(sevarIS_flags&sevarIS_no_short) )
   {
#     ifdef DISABLE_VSHORTSTRING_FOR_DEBUGGING
      /* use real allocation for everything except the failure string */
      if ( bytelen == bytestrlen_sechar(STR_ALLOC_FAILURE)
        && !strcmp_sechar( mem, STR_ALLOC_FAILURE ) )
#     endif
      {
         memcpy( &(var->data.shortstr[1]),mem,bytelen );
#        if JSE_MBCS==1
            /* high half is len, short half is bytelen */
            var->data.shortstr[0] = (secharptrdatum)((len << 4) | bytelen);
#        else
            var->data.shortstr[0] = (secharptrdatum)len;
#        endif
         SECHARPTR_PUTC(((ubyte *)(&(var->data.shortstr[1])))+bytelen,'\0');
         var->type = VShortString;

         FreeWhatWeGot:
            if( !allocate && should_free )
            {
               secoreFree(call,(void *)mem);
            }
         return;
      }
   }

   SEVAR_INIT_UNDEFINED(var);

#  if JSE_POOL_STRINGDATA==1
      cached = ( global->sestringPoolCount != 0 );
      if ( cached )
      {
         ret = global->sestring_pool[--global->sestringPoolCount];
         if ( !allocate ||
#          if JSE_MBCS==1
              ret->bytelength < bytelen
#          else
              ret->length < len
#          endif
              )
         {
            SESTRING_FREE_DATA(call,ret);
            cached = False;
         }
         /* following code would have forced GC */
         ALWAYS_COLLECT(call)
      }
      else
#  endif
      {
         ret = (struct _seString *)secoreAlloc(call,NULL,sizeof(struct _seString),SE_DEFAULT);
      }


   if( ret==NULL )
   {
      sevarStrAllocFailure(call,var);
      goto FreeWhatWeGot;
   }

   if( allocate )
   {
      void *newmem;

#     if JSE_POOL_STRINGDATA==1
      if( cached )
      {
         newmem = SESTRING_GET_DATA(call,ret);
         /* following code would have forced GC */
         ALWAYS_COLLECT(call)
      }
      else
#     endif
      {
         SEASSERT( sizeof_sechar('\0') == sizeof(secharptrdatum) );
         var->type = VUndefined;
         newmem = (void *)secoreAlloc(call,NULL,(sememcount)(bytelen+sizeof(secharptrdatum)),SE_DEFAULT);

         if( newmem==NULL )
         {
            secoreFree(call,ret);
            sevarStrAllocFailure(call,var);
            return;
         }
      }
      memcpy(newmem,mem,bytelen);

      mem = newmem;

      /* If not allocated here, must already be null terminated. */
      *((secharptrdatum *)((ubyte *)mem+bytelen)) = '\0';
   }

#  if JSE_REFCOUNT==0
#     if JSE_ALWAYS_COLLECT==0
      if( JSE_STRINGS_COLLECT <= (global->stringallocs += (uword32)(bytelen+40/*overhead estimate*/)) )
#     endif
      {
         global->stringallocs = 0;
         var->type = VUndefined; /* protect in case of garbage collection */
         secoreGarbageCollect(call);
      }
#  endif

   /* NYI - instead of shrinking this all the time - the pool should keep track of length
    * so that the pool item is not deleted each time a str-alloc follows a shorter str-alloc
    * also in seTempLockString
    */
   ret->length = len;
#  if JSE_MBCS==1
      ret->bytelength = bytelen;
#  endif
   ret->flags = 0;

   if( !should_free )
      ret->flags |= SESTR_NOFREE_FLAG;

   /* NYI: for memext would it be more efficient to not allocate and free - (if not RO) same in seTempLockString */
   SESTRING_PUT_DATA(call,ret,(void *)mem,
                     (sememcount)(bytelen+((SE_POINTER_UINDEX)sizeof(sechar))));

#  if JSE_REFCOUNT==0
      /* Link it in */
      ret->prev = global->stringdatas;
      global->stringdatas = ret;
#  endif

   var->data.string_val = ret;
   var->type = VString;
}

   void
seConcatenateStrings(struct seCall *call,wSEVar dest,rSEVar s1,rSEVar s2)
{
   sememcount len1, bytelen1, len2, bytelen2;
   size_t totallen, totalbytelen;
   seconstcharptr mem1, mem2;

   SEASSERT( sevarIsValid(call,s1) );
   SEASSERT( sevarIsValid(call,s2) );

   mem1 = sevarGetStr(call,s1,&len1,&bytelen1);
   mem2 = sevarGetStr(call,s2,&len2,&bytelen2);

   totallen = (size_t)(len1 + len2);
   totalbytelen =(size_t)( bytelen1 + bytelen2);
#  ifndef DISABLE_VSHORTSTRING_FOR_DEBUGGING
   if ( totalbytelen <= (sizeof(dest->data)-sizeof(secharptrdatum)) )
   {
      /* this is small enough to fit directly into the string; no need to allocate */
      memcpy( &(dest->data.shortstr[1]), mem1, bytelen1 );
      memcpy( ((ubyte *)(&(dest->data.shortstr[1])))+bytelen1, mem2, bytelen2 );
#     if JSE_MBCS==1
         /* high half is len, short half is bytelen */
         dest->data.shortstr[0] = (secharptrdatum)((totallen << 4) | totalbytelen);
#     else
         dest->data.shortstr[0] = (secharptrdatum)totallen;
#     endif
      SECHARPTR_PUTC( ((ubyte *)(&(dest->data.shortstr[1])))+totalbytelen, '\0' );
      dest->type = VShortString;
      /* following code would have forced GC */
      ALWAYS_COLLECT(call)
   }
   else
#  endif
   {
      secharptr ConcatMem;
      SEASSERT( sizeof_sechar('\0') == sizeof(secharptrdatum) );
      ConcatMem = (secharptr)secoreAlloc(call,NULL,(sememcount)(totalbytelen+sizeof(secharptrdatum)),SE_DEFAULT);
      if( ConcatMem==NULL )
      {
         sevarStrAllocFailure(call,dest);
      }
      else
      {
         memcpy(ConcatMem,mem1,bytelen1);
         memcpy(((ubyte *)ConcatMem)+bytelen1,mem2,bytelen2);
         /* to be nice, all our strings are null-terminated */
         SECHARPTR_PUTC(((ubyte *)ConcatMem+totalbytelen),'\0');
         sevarInitString(call,dest,ConcatMem,(sememcount)totallen,
#                        if JSE_MBCS==1
                            (sememcount)totalbytelen,
#                        endif
                         sevarIS_should_free);
      }
   }
}
#endif /* #if JSE_COMPILER_SEGMENT==1 */


#if JSE_PACK_OBJECTS==0
   hSEMembers NEAR_CALL
get_initial_members(struct seCall *call,sememcount *wanted)
{
   hSEMembers hsemembers;
#  if JSE_DONT_POOL==0
      struct seGlobal_ *global = call->Global;
      if( global->memPoolCount!=0 )
      {
         hsemembers = global->mem_pool[--global->memPoolCount];
         /* We 'cheat' by keeping track of how many members were in this
          * allocated by storing that data in the 'name' member of
          * the 0 element.  For example, if we free up at 32 member
          * object and put it back into the pool, when we need it
          * again we might as well use all 32 members.
          *
          * The user can control the max size that gets put into the
          * pool by defining JSE_MEM_POOL_MAX_SIZE
          */
         *wanted = (sememcount)(SEMEMBERS_GET(call,hsemembers,0,name));
         SEASSERT( 0 != *wanted );
         /* following code would have forced GC */
         ALWAYS_COLLECT(call)
      }
      else
#  endif
      {
         SEASSERT( 0 != *wanted );
#        if JSE_MEMEXT_MEMBERS==0
         {
            sememcount try_for = *wanted;
            *wanted = 0;
            hsemembers = (struct _SEMembers *)secoreAllocEx(call,NULL,try_for,sizeof(struct _SEMembers),wanted,
                                                            SE_ALLOCEX_ONE_IS_ENOUGH);
         }
#        else
            hsemembers = semembersAlloc(call,*wanted) ;
            if ( hSEMembersNull == hsemembers )
            {
               /* failed first time - try again with only one element */
               *wanted = 1;
               hsemembers = semembersAlloc(call,1) ;
            }
#        endif
      }
   return hsemembers;
}
#endif /* #if JSE_PACK_OBJECTS==0 */

   hSEObject
seobj_new(struct seCall *call,sememcount unordered_count)
{
   hSEObject hobj;
   struct _SEObject *wobj;
   hSEMembers hsemembers;
#  if JSE_DONT_POOL==0
      struct seGlobal_ *global = call->Global;
#  endif
#  if JSE_PACK_OBJECTS==0
      sememcount alloced;     /* how many members allocated */
      sememcount wanted, needed;
#  endif

   /* get hsemembers first, to prevent GC from destroying obj if we get that first */
#  if JSE_PACK_OBJECTS==1

      hsemembers = hSEMembersNull;

#  else

      if ( 0 < (sesmemcount)(wanted = unordered_count) )
      {
         needed = wanted;
      }
      else
      {
         wanted = OBJ_DEFAULT_SIZE;
         needed = 1;
      }
      alloced = wanted;
      hsemembers = get_initial_members(call,&alloced);

      /* If the allocation failed, an error will be in the
       * context.
       */
      if ( hSEMembersNull == hsemembers )
      {
         /* allocation failed; return alloc-fail object */
#        if JSE_MEMEXT_OBJECTS==1
            return global->internal_out_of_mem_hobj;
#        else
            return &(global->internal_out_of_mem_obj);
#        endif
      }

#  endif


   /* next allocated the hobj, onto which the above hsemembers will be added */

#  if JSE_DONT_POOL==0
#     if JSE_ALWAYS_COLLECT==0
      if( 0 == global->hobjPoolCount )
#     endif
      {
#        if JSE_GC==1
            secoreGarbageCollect(call);
#        else
            seCollectRefill(call);
#        endif

         if ( 0 == global->hobjPoolCount )
         {
            /* darn - seem to be out of memory */
            /* in rare rare cases the collectrefill flag is off, for those cases call it explicitly */
#           if JSE_GC==1
               if ( 0 != (global->flags & collect_do_not_refill) )
               {
                  seCollectRefill(call);
                  if ( 0 != global->hobjPoolCount )
                     goto got_at_least_one_in_pool;
               }
#           endif

            /* DARN! No room to allocate even one more object */
#           if JSE_PACK_OBJECTS==0
               semembersFree(call,hsemembers);
#           endif
#           if JSE_MEM_SABOTAGE==1
            {
               /* collectRefill assumes that it is not tragic if it cannot put anything in.  This is
                * the one case where that really is a tragedy.
                */
               struct jsememDebugData *dbgData = global->Params.allocator_cookie;
               SEASSERT( dbgData->jsememSabNotcriticalFailure );
               dbgData->jsememSabNotcriticalFailure--;
            }
#           endif
            global->flags |= se_alloc_failed; /* secore_Alloc_failure() would have called if it knew was critical */
            callQuit(call,textcoreOUT_OF_MEMORY);
#           if JSE_MEMEXT_OBJECTS==1
               return global->internal_out_of_mem_hobj;
#           else
               return &(global->internal_out_of_mem_obj);
#           endif
         }
      }

#     if JSE_GC==1
      got_at_least_one_in_pool:
#     endif

      HSEOBJECT_BRUTE_ASSIGN(hobj,global->hobj_pool[--global->hobjPoolCount]);

#  else
      hobj = seobjectAlloc(call);

      if( hobj==NULL )
      {
#        if JSE_PACK_OBJECTS==0
            semembersFree(call,hsemembers);
#        endif
#        if JSE_MEMEXT_OBJECTS==1
            return global->internal_out_of_mem_hobj;
#        else
            return &(global->internal_out_of_mem_obj);
#        endif
      }
#  endif

   /* grabbed an object from the pool, add it to the list of all
    * objects.
    */
   wobj = LOCK_WRITE_OBJECT(call,hobj);
#  if JSE_GC==1
      HSEOBJECT_BRUTE_ASSIGN(wobj->hNext,global->all_hobjs);
      HSEOBJECT_BRUTE_ASSIGN(global->all_hobjs,hobj);
#  endif

   /* initialize the object */
#  if JSE_PER_OBJECT_MISS_CACHE==1
      wobj->miss_cache = SE_NO_VARNAME;
#  endif
#  if JSE_PER_OBJECT_CACHE==1
      wobj->cache = 0;
#  endif
   wobj->used = 0;
   wobj->flag = (objflag)(( 0 == unordered_count ) ? 0 : SEOBJ_DONT_SORT );
#  if JSE_DYNAMIC_CALLBACKS==1 && JSE_MIN_OBJ_SIZE==0
      wobj->callbacks = NULL;
#  endif
#  if JSE_MIN_OBJ_SIZE==0
      wobj->func = NULL;
#  endif
#  if JSE_REFCOUNT==1
      wobj->refcount = 1;
#  endif
   wobj->hsemembers = hsemembers;

#  if JSE_PACK_OBJECTS==0
      if ( (wobj->alloced = alloced) < needed )
      {
         wSEVar tmp = STACK_PUSH;
         SEVAR_INIT_NEW_OBJECT(tmp,hobj);
         if( !ResizeObjectMembers(call,hobj,needed,True) )
         {
#           if JSE_PACK_OBJECTS==0
               semembersFree(call,hsemembers);
#           endif

#           if JSE_MEMEXT_OBJECTS==1
               hobj = global->internal_out_of_mem_hobj;
#           else
               HSEOBJECT_BRUTE_ASSIGN(hobj,&(global->internal_out_of_mem_obj));
#           endif
         }
         STACK_POP;
      }
#     if JSE_ALWAYS_COLLECT==1
      else
      {
#        if JSE_SHRINK_STABLE_OBJECTS==1
            SEMembers memory = LOCK_WRITE_MEMBERS(call,SEOBJECT_GET(call,hobj,hsemembers));
#        endif
         /* theoretically, the above ResizeObjectMembers could have caused GC, so do it now */
         wSEVar tmp = STACK_PUSH;
         SEVAR_INIT_NEW_OBJECT(tmp,hobj);
#        if JSE_SHRINK_STABLE_OBJECTS==1
         {
            /* do not let this artifical GC shrink this particular object */
            sememcount i;
            memory = LOCK_WRITE_MEMBERS(call,SEOBJECT_GET(call,hobj,hsemembers));
            SEOBJECT_PUT(call,hobj,used,needed);
            for ( i = 0; i < needed; i++ )
            {
               SEVAR_INIT_UNDEFINED((wSEVar)(memory+i));
               (memory+i)->name = SE_NO_VARNAME;
            }
         }
#        endif
         secoreGarbageCollect(call);
#        if JSE_SHRINK_STABLE_OBJECTS==1
            SEOBJECT_PUT(se,hobj,used,0);
            memory = LOCK_WRITE_MEMBERS(call,SEOBJECT_GET(call,hobj,hsemembers));
            memset(memory,0xee,needed * sizeof(*memory));
#        endif
         STACK_POP;
      }
#     endif
#  endif

   return hobj;
}

#if JSE_DONT_POOL==0
#if JSE_UTIL_SEGMENT==1

   static void JSE_NEAR_CALL release_object_semembers(struct seCall *call,struct _SEObject *wObj);

   void
seCollectRefill(struct seCall *call)
{
   struct seGlobal_ *global = call->Global;

   while( global->hobjPoolCount < SE_OBJ_POOL_SIZE )
   {
      struct _SEObject *wTmp;
      hSEObject hTmp;

      /* NYI: new object in both cases may be NULL.  must be able to recover from that */
#     if JSE_MEMEXT_OBJECTS==0
         HSEOBJECT_BRUTE_ASSIGN(hTmp,(struct _SEObject *)
                                secoreAlloc(call,NULL,sizeof(struct _SEObject),
                                            SE_ALLOC_NOGC|SE_ALLOC_NOTHROW|SE_ALLOC_NOEMPTYOBJPOOL|SE_ALLOC_RECOVERABLE));
#     else
         HSEOBJECT_BRUTE_ASSIGN(hTmp,(hSEObject)seobjectAlloc(call));
#     endif

      if( hSEObjectNull == hTmp )
      {
         /* darn, no memory available to allocate a new object */

         /* even a single item is just fine; if there's not even one then empty pools and retry */
         if ( 0 == global->hobjPoolCount )
         {
            /* old version: JSEMEMSAB_TRY_AGAIN */
            seEmptyPools(call);
#           if JSE_MEMEXT_OBJECTS==0
               HSEOBJECT_BRUTE_ASSIGN(hTmp,(struct _SEObject *)
                  secoreAlloc(call,NULL,sizeof(struct _SEObject),
                              SE_ALLOC_NOGC|SE_ALLOC_NOTHROW|SE_ALLOC_NOEMPTYOBJPOOL|SE_ALLOC_RECOVERABLE));
#           else
               HSEOBJECT_BRUTE_ASSIGN(hTmp,(hSEObject)seobjectAlloc(call));
#           endif
         }

         if( hSEObjectNull == hTmp )
         {
#           if JSE_MEM_SABOTAGE==1
               /* in all but one case, which is handled below, even a null return here is non-critical */
               /* JSEMEMSAB_TRY_AGAIN */
#           endif
            break;
         }
      }

      HSEOBJECT_BRUTE_ASSIGN(global->hobj_pool[global->hobjPoolCount++],hTmp);

      wTmp = LOCK_WRITE_OBJECT(call,hTmp);
      wTmp->flag = SE_DEFAULT;
      wTmp->hsemembers = hSEMembersNull;
   }
}

   sebool
seEmptyPools(struct seCall *call)
/* to free as much memory as possible clean everything out of the pools */
{
   uint i;
   struct seGlobal_ *global = call->Global;
   sebool was_anything_freed = False;
#  if JSE_GC==1
      hSEObject hobj;
#  endif

#  if JSE_GC==1
      if ( NULL != global->hDestructors
        && global->destructorCount < global->destructorAlloced)
      {
         if ( 0 == global->destructorCount )
         {
            SEASSERT( NULL != global->hDestructors );
            secoreFree(call,global->hDestructors);
            global->hDestructors = NULL;
         }
         else
         {
            global->hDestructors = secoreAlloc(call,global->hDestructors,\
               (sememcount)(global->destructorCount * sizeof(global->hDestructors[0])),\
               SE_ALLOC_NOGC|SE_ALLOC_NOEMPTYOBJPOOL);
            SEASSERT( NULL != global->hDestructors );
         }
         global->destructorAlloced = global->destructorCount;
         was_anything_freed = True;
      }
#  endif /* #if JSE_GC==1 */

#  if JSE_GC==1 /* refcount will need to just empty each member */
   {
      /* empty hobj_pool[]; */

      for( i=0; i<global->hobjPoolCount; i++ )
      {
         hSEMembers hsemembers;

         HSEOBJECT_BRUTE_ASSIGN(hobj,global->hobj_pool[i]);

         hsemembers = SEOBJECT_GET(call,hobj,hsemembers);
         if ( hSEMembersNull != hsemembers )
         {
            /* these members are no longer allocated, so free them */
#           ifndef SE_RELEASE_BUILD
#           if JSE_PACK_OBJECTS==0
            memset(LOCK_WRITE_MEMBERS(call,hsemembers),JSE_INVALID_COLLECT,
                   sizeof(struct _SEMembers)*SEOBJECT_GET(call,hobj,alloced));
#           else
            memset(LOCK_WRITE_MEMBERS(call,hsemembers),JSE_INVALID_COLLECT,
                   sizeof(struct _SEMembers)*SEOBJECT_GET(call,hobj,used));
#           endif
#           endif
#           ifdef MEMCOUNT_MAX_MEMORY
#           if JSE_PACK_OBJECTS==0
            SEASSERT( (sizeof(struct _SEMembers)*wObj->alloced)<MEMCOUNT_MAX_MEMORY );
#           else
            SEASSERT( (sizeof(struct _SEMembers)*wObj->used)<MEMCOUNT_MAX_MEMORY );
#           endif
#           endif
#           if JSE_NEVER_FREE==1
            callAddFreeItem(call,hsemember);
#           else
            semembersFree(call,hsemembers);
#           endif
         }

#        ifndef SE_RELEASE_BUILD
         memset(LOCK_WRITE_OBJECT(call,hobj),JSE_INVALID_COLLECT,sizeof(struct _SEObject));
#        endif
#        if JSE_NEVER_FREE==1
         callAddFreeItem(call,hobj);
#        else
         seobjectFree(call,hobj);
#        endif
         was_anything_freed = True;
      }
      global->hobjPoolCount = 0;
   }
#  endif /* if JSE_GC==1 */

   /* empty mem_pool[]; */
#  if JSE_DONT_POOL==0
      for( i=global->memPoolCount; i--; )
      {
         semembersFree(call,global->mem_pool[i]);
         was_anything_freed = True;
      }
      global->memPoolCount = 0;
#  endif

   /* empty sestring_pool[]; */
#  if JSE_DONT_POOL==0
      for( i=global->sestringPoolCount; i--; )
      {
#        if JSE_POOL_STRINGDATA==1
            SESTRING_FREE_DATA(call,global->sestring_pool[i]);
#        endif
         secoreFree(call,global->sestring_pool[i]);
         was_anything_freed = True;
      }
      global->sestringPoolCount = 0;
#  endif

   /* empty seobject_pool[] */
   for ( i = global->seapi_temp_pool_count; i--; )
   {
      secoreFree(call,global->seapi_temp_pool[i]);
      was_anything_freed = True;
   }
   global->seapi_temp_pool_count = 0;

   /* empty func_save_pool[]; */
   for ( i = global->func_save_pool_count; i--; )
   {
      secoreFree(call,global->func_save_pool[i]);
      was_anything_freed = True;
   }
   global->func_save_pool_count = 0;

#  if JSE_PACK_OBJECTS==0 && JSE_GC==1
#     if JSE_SHRINK_STABLE_OBJECTS==1
      /* if ( 0 == global->collect_disable ) */ /* if within GC then may already be shrinking */
#     endif
      {
         /* shrink every existing object */
         hSEObject hnext = global->all_hobjs;
         while ( hSEObjectNull != (HSEOBJECT_BRUTE_ASSIGN(hobj,hnext)) )
         {
            struct _SEObject *wObj = LOCK_WRITE_OBJECT(call,hobj);
            HSEOBJECT_BRUTE_ASSIGN(hnext,wObj->hNext);
            if ( wObj->used != wObj->alloced ) /* all moot if used == alloced */
            {
               was_anything_freed = True;
               SEASSERT( wObj->used < wObj->alloced );
               /* this object can be reduced */
               if ( 0 == wObj->used )
               {
                  release_object_semembers(call,wObj);
               }
               else
               {
                  /* don't worry if it fails, we are only trying to shrink
                   * it, so if the original, too large, block remains, so
                   * be it.
                   */
                  ResizeObjectMembers(call,hobj,wObj->used,False);
               }
            }
         }
      }
#  endif

   return was_anything_freed;
}
#endif /* #if JSE_UTIL_SEGMENT==1 */
#endif /* #if JSE_DONT_POOL==0 */

#if JSE_GC==1

#ifdef JSE_MEM_SUMMARY
   static void JSE_NEAR_CALL memDump(struct seCall *call);
#endif

#if JSE_UTIL_SEGMENT==1

#if JSE_NEVER_FREE==1
   static void JSE_NEAR_CALL
callAddFreeItem(struct seCall *call,void *mem)
{
   struct seGlobal_ *global = call->Global;

   if( global->max_blocks_to_free <= global->num_blocks_to_free )
   {
      SEASSERT( global->num_blocks_to_free==global->max_blocks_to_free );
      if( global->num_blocks_to_free )
      {
         void **nb = (void **)
            secoreAlloc(call,global->blocks_to_free,
                        100 + global->max_blocks_to_free,sizeof(void *),
                        &(global->max_blocks_to_free),SE_ALLOC_ONE_IS_ENOUGH);

         if( nb!=NULL )
         {
            global->blocks_to_free = nb;
         }
         else
         {
            secoreFree(call,mem);
            return;
         }
      }
      else
      {
         global->blocks_to_free = (void **)
            secoreAlloc(call,NULL,global->max_blocks_to_free=100,sizeof(void *),NULL,SE_DEFAULT);

         /* no space to save it */
         if( global->blocks_to_free==NULL )
         {
            secoreFree(call,mem);
            return;
         }
      }
   }
   ELSE_ALWAYS_COLLECT(call)

   global->blocks_to_free[global->num_blocks_to_free++] = mem;
}
#endif /* #if JSE_NEVER_FREE==1 */

/* All of the items that we garbage collect, we have a list
 * of, so we free everything when we exit.
 */
   void NEAR_CALL
collectUnallocate(struct seCall *call)
{
   struct seGlobal_ *global = call->Global;
   hSEObject hThis;

#  if JSE_MEM_SUMMARY
      memDump(call);
#  endif

   seEmptyPools(call);

   /* GC causes too many unrealistic warnings here, so disable */
   global->collect_disable++;

   /* free all remaining objects */
   while( hSEObjectNull != (HSEOBJECT_BRUTE_ASSIGN(hThis,global->all_hobjs)) )
   {
      hSEMembers hmembers;

      HSEOBJECT_BRUTE_ASSIGN(global->all_hobjs,SEOBJECT_GET(call,hThis,hNext));
      if( (hmembers=SEOBJECT_GET(call,hThis,hsemembers)) != hSEMembersNull )
      {
         semembersFree( call, hmembers );
      }
      seobjectFree(call,hThis);
   }
   global->collect_disable--;


#  if JSE_REFCOUNT==0
      /* Free up string buffer data. */
      {
         seString sd, prev;
         prev = global->stringdatas;
         while ( NULL != (sd=prev) )
         {
            prev = sd->prev;
            SESTRING_FREE_DATA(call,sd);
            secoreFree(call,sd);
         }
      }
      global->stringdatas = NULL;
#  endif

#  if JSE_REFCOUNT==0
      /* Free all remaining functions */
      while( global->funcs )
      {
         struct seFunction *tmp = global->funcs->next;

         sefunctionDelete(call,global->funcs);
         global->funcs = tmp;
      }
#  endif

   seEmptyPools(call);

#  if JSE_NEVER_FREE==1
      for( i=0;i<global->num_blocks_to_free;i++ )
         secoreFree(call,global->blocks_to_free[i]);
      if( global->blocks_to_free!=NULL )
         secoreFree(call,global->blocks_to_free);
#  endif

}



/* ----------------------------------------------------------------------
 * The mark/sweep collector. It is possible I will rewrite this later
 * to be more efficient, but it will probably not change. We use a
 * relatively simple collection of things need to be swept, and this
 * collector does a pretty good job.
 * ---------------------------------------------------------------------- */

/*
 * Algorithm:
 *
 * We go through all objects/vars and mark them and their children.  If there
 * is a stack limit then there is a possibility that marking objects gets
 * to recursively deep.  In that case we'll set a flag in mark_info that
 * we need to go through the linked-list of all and mark all those that are
 * marked but do not have all children marked.  The other rare case is if some
 * objects need to have destructors called but we cannot grow the destructor
 * list enough.  In that case objects unable to be destroyed this pass mmust have
 * themselves and all decendants marked again.  Both these re-loop cases are
 * rare.
 */

struct segc_mark_info
{
   struct seCall *call; /* save so we don't need to pass this AND call all over the place */
#  if JSE_STACKCHK==1
      sebool try_again; /* set true in the rare case of objects re-marked because there was not
                         * enough stack space, or re-marked because they the destructor list
                         * ran out of memory and these could not be added.
                         */
      SE_POINTER_UINT go_no_further;
               /* if in markObject() the stack ptr is lower than this (as
                * calculated by experimentation and set up in garbageCollect()
                * then do not continue to call recursively.
                */
      /* something about bottom of stack goes here */
      uint mark_object_depth; /* incremented each time we enter mark_object around, and decremented
                               * when we leave.  If this is 0 we will always make the call
                               * to markvariable, else we'll only do so if there is enough stack
                               */
#  endif
};


/* We check the permlock bit first before turning it on. This is
 * because shared varnames are read-only. We do not want to just
 * overwrite it because they are read-only, and may be in read-only
 * memory.
 */
#if SE_SHARED_OBJECTS==1
#  define MARK_SEVARNAME(s)                                                \
      if( IsNormalSEStringTableEntry(s)                                    \
       && (HashListFromSEVarName(s)->locks&JSE_SESTRING_PERMLOCK_BIT)==0 ) \
         HashListFromSEVarName(s)->locks |= JSE_SESTRING_SWEEP_BIT
#else
#  define MARK_SEVARNAME(s)                                                \
      if( IsNormalSEStringTableEntry(s) )                                  \
         HashListFromSEVarName(s)->locks |= JSE_SESTRING_SWEEP_BIT
#endif

static void JSE_NEAR_CALL markFunction(struct seFunction *func,struct segc_mark_info *gcmi);
static void JSE_NEAR_CALL markVariable(rSEVar var,struct segc_mark_info *gcmi);

   static void JSE_NEAR_CALL
markObject(hSEObject obj,struct segc_mark_info *gcmi)
{
   /* don't mark an object if it is already marked (obvious), but
    * also shared objects are read-only and last to the end of
    * the program; they and their children do not get marked
    * either.  If JSE_STACKCHK is in effect then only mark object
    * if it has some unmarked children (assume that if children are
    * marked then the SWEEP BIT is already on.
    */
   if ( hSEObjectNull != obj )
   {
#     if SE_SHARED_OBJECTS==1
#        if JSE_STACKCHK==1
#           define NO_NEED_TO_MARK_OBJECT    (SEOBJ_SWEPT_MEMS|SEOBJ_SHARED)
#        else
#           define NO_NEED_TO_MARK_OBJECT    (SEOBJ_SWEEP_BIT|SEOBJ_SHARED)
#        endif
#     else
#        if JSE_STACKCHK==1
#           define NO_NEED_TO_MARK_OBJECT    SEOBJ_SWEPT_MEMS
#        else
#           define NO_NEED_TO_MARK_OBJECT    SEOBJ_SWEEP_BIT
#        endif
#     endif
      if ( 0 == (SEOBJECT_GET(gcmi->call,obj,flag) & NO_NEED_TO_MARK_OBJECT) )
      {
         {
            struct seFunction *obj_func;
#           if JSE_STACKCHK==1
               SEOBJECT_PUT(gcmi->call,obj,flag,\
                            (objflag)(SEOBJECT_GET(gcmi->call,obj,flag)|(objflag)(SEOBJ_SWEEP_BIT|SEOBJ_SWEPT_MEMS)));
#           else
               SEOBJECT_PUT(gcmi->call,obj,flag,(objflag)(SEOBJECT_GET(gcmi->call,obj,flag)|(objflag)SEOBJ_SWEEP_BIT));
#           endif
            if( NULL != (obj_func = SEOBJECT_GET_func(gcmi->call->end,obj)) )
            {
               markFunction(obj_func,gcmi);
            }

#           if JSE_STACKCHK==1
            if ( 0 != gcmi->mark_object_depth++ )
            {
#              if !defined(DISABLE_SEGC_MARK_RECURSION) /* a way to force us never to recurse */
#              if SE_STACK_DIRECTION == -1
               if ( (SE_POINTER_UINT)(&obj_func) < gcmi->go_no_further )
#              else
               if ( gcmi->go_no_further < (SE_POINTER_UINT)(&obj_func) )
#              endif
#              endif
               {
                  gcmi->try_again = True;
                  SEOBJECT_PUT(gcmi->call,obj,flag,(objflag)(SEOBJECT_GET(gcmi->call,obj,flag)&(objflag)~SEOBJ_SWEPT_MEMS));
                  gcmi->mark_object_depth--;
                  return;
               }
            }
#           endif
         }
         {
            /* mark all members of this object and so on recursively */
            hSEMembers hMembers = SEOBJECT_GET(gcmi->call,obj,hsemembers);
            sememcount used = SEOBJECT_GET(gcmi->call,obj,used);
            while( used-- )
            {
#              if JSE_REFCOUNT==0
               {
                  seVarName vn = SEMEMBERS_GET(gcmi->call,hMembers,used,name);
                  if( SE_NO_VARNAME != vn )
                  {
                     MARK_SEVARNAME(vn);
                  }
               }
#              endif

#              if JSE_MEMEXT_MEMBERS
               {
                  /* must save var somewhere because while operating on it it can
                   * easily be removed from the cache--but do not need to push it on
                   * with STACK_PUSH because GC cannot ever overwrite it.
                   */
                  struct _SEVar save_var;
                  save_var = *(SEMEMBERS_GET_sevar(gcmi->call,hMembers,used));
                  markVariable(&save_var,gcmi);
               }
#              else
                  markVariable(SEMEMBERS_GET_sevar(gcmi->call,hMembers,used),gcmi);
#              endif
            }
         }
#        if JSE_STACKCHK==1
         gcmi->mark_object_depth--;
#        endif
      }
   }
   return;
}

   static void JSE_NEAR_CALL
markFunction(struct seFunction *func,struct segc_mark_info *gcmi)
{
   /* shared functions do not get marked */
#  if JSE_REFCOUNT==0 && SE_SHARED_OBJECTS==1
   if ( 0 == ( func->flags & (Func_SweepBit|Func_Shared) ) )
#  elif JSE_REFCOUNT==0
   if ( 0 == ( func->flags & Func_SweepBit ) )
#  elif SE_SHARED_OBJECTS==1
   if ( 0 == ( func->flags & Func_Shared ) )
#  endif
   {
#     if JSE_REFCOUNT==0
         func->flags |= Func_SweepBit;
#     endif
#     if JSE_MULTIPLE_GLOBAL==1
         markObject(func->hglobal_object,gcmi);
#     endif
      if( FUNCTION_IS_LOCAL(func) )
      {
         markObject(((struct LocalFunction *)func)->hConstants,gcmi);
      }
   }
}

   static void JSE_NEAR_CALL
markVariable(rSEVar var,struct segc_mark_info *gcmi)
{
   SEASSERT( STACK_TYPE_IS_VALID((var)->type) );
   switch( (var)->type )
   {
#     if JSE_REFCOUNT==0
      case VString:
#        if SE_SHARED_OBJECTS==1
         if( 0 == (var->data.string_val->flags & SESTR_SHARED) )
#        endif
         {
            SESTR_MARK(var->data.string_val);
         }
         break;
#     endif
      case VObject:
         markObject(SEVAR_GET_OBJECT(var),gcmi);
         markObject(var->data.object_val.hSavedScopeChain,gcmi);
         break;
      case VReference:
         markObject(var->data.ref_val.hBase,gcmi);
#        if JSE_REFCOUNT==0
            MARK_SEVARNAME(var->data.ref_val.reference);
#        endif
         break;
      case VReferenceIndex:
         SEASSERT( var->data.ref_val.hBase!=hSEObjectNull );
         markObject(var->data.ref_val.hBase,gcmi);
         break;
   }
   return;
}

#if JSE_DYNAMIC_CALLBACKS==1
/* All seObjects are marked as used. Put all those unused and with
 * destructors onto the destructor list.
 */
   static sebool JSE_NEAR_CALL
roomForOneMoreDestructor(struct seCall *call)
{
   struct seGlobal_ *global = call->Global;
   if( global->destructorAlloced <= global->destructorCount )
   {
      hSEObject *hNewD = (hSEObject *)secoreAllocEx(call,global->hDestructors,
                              (size_t)(global->destructorAlloced + 20),sizeof(hSEObject),
                              &(global->destructorAlloced),
                              SE_ALLOCEX_ONE_IS_ENOUGH|SE_ALLOC_NOGC|SE_ALLOC_NOTHROW|SE_ALLOC_RECOVERABLE);
      if( hNewD == NULL )
         return False;
      global->hDestructors = hNewD;
   }
   return True;
}
   static void JSE_NEAR_CALL
noteAllDestructors(struct segc_mark_info *gcmi)
{
   struct seCall *call = gcmi->call;
   struct seGlobal_ *global = call->Global;
   if ( 0 == (global->flags & final_destructors) )
   {
      hSEObject hobj;
      uint i;

      global->destructorCount = 0;

      HSEOBJECT_BRUTE_ASSIGN(hobj,global->all_hobjs);
      while( hobj!=hSEObjectNull )
      {
         hSEObject hNextObj;

         HSEOBJECT_BRUTE_ASSIGN(hNextObj,SEOBJECT_GET(call,hobj,hNext));
         /* If it is not in use or currently on the free list, and has a destructor */
         if ( 0 == (SEOBJECT_GET(call,hobj,flag) & SEOBJ_SWEEP_BIT)
           && SEOBJ_IS_DYNAMIC_PROP(call,hobj,deleteProp) )
         {
            /* if there is no room to store this then no problem, it will get caught next time
             * GC happens
             */
            if ( roomForOneMoreDestructor(call) )
            {
               /* realloc may have removed next, se re-get next */
               HSEOBJECT_BRUTE_ASSIGN(hNextObj,SEOBJECT_GET(call,hobj,hNext));
               HSEOBJECT_ASSIGN(global->hDestructors[global->destructorCount++],hobj); /* maybe brute? */
            }
            else
            {
               /* this could not fit onto the destructors list because we ran out of memory.  But
                * that is recoverable simply by marking this object (so it will not be deleted this
                * time but will be caught the next time around).  So set this object back to being
                * marked again.
                */
               markObject(hobj,gcmi);
               /* although this failed the code will continue through this loop and continue to mark all
                * of the objects with destructors that did not make it onto this list.  It would be slightly
                * faster to set a flag because roomforonemore will continue to fail, but this circumstance
                * is so rare that it is not worth the extra code.
                */
            }
         }
         HSEOBJECT_BRUTE_ASSIGN(hobj,hNextObj);
      }

      /* every object that was just put on the list needs to be marked so that it
       * (and its descendants) are not removed by the sweeper.  This marking of objects is
       * done here instead of a few lines up (in the loop) because if we marked in the loop
       * the some destructors may not have been added to the list because an earlier
       * destructor object that references it may have marked it.
       */
      for ( i = global->destructorCount; i--; )
      {
         markObject(global->hDestructors[i],gcmi);
      }
   }
}
#endif /* #if JSE_DYNAMIC_CALLBACKS==1 */

   static void JSE_NEAR_CALL
mark_seapiLockItem_list(struct segc_mark_info *gcmi,struct seapiLockItem *apiloop)
{
   for( ; NULL!=apiloop; apiloop = apiloop->next )
   {
      uword8 flags;
      if ( (flags = apiloop->flags) < seLI_STOCK )
      {
         /* these types must be marked by GC */
         if ( seLI_OBJECT <= flags )
         {
            SEASSERT( seLI_OBJECT == seLI_GET_TYPE(flags) );
            if ( 0 == (flags & seLI_WEAK) )
            {
               markObject(apiloop->data.obj,gcmi);
            }

            if ( apiloop->hSavedScopeChain != hSEObjectNull )
               markObject(apiloop->hSavedScopeChain,gcmi);
         }
#        if JSE_MEMEXT_STRINGS==0 && JSE_REFCOUNT==0
         else if ( flags < seLI_HASHLIST )
         {
            SEASSERT( seLI_SESTR == seLI_GET_TYPE(flags) );
            SESTR_MARK(apiloop->data.sestr);
         }
#        endif
         else
         {
            SEASSERT( seLI_HASHLIST == seLI_GET_TYPE(flags) );
#           if SE_SHARED_OBJECTS==1
            if ( (apiloop->data.name->locks & JSE_SESTRING_PERMLOCK_BIT) == 0 )
#           endif
               apiloop->data.name->locks |= JSE_SESTRING_SWEEP_BIT;
         }
      }
   }
}

   static void JSE_NEAR_CALL
mark(struct seCall *basecall)
{
   struct seGlobal_ *global = basecall->Global;
   struct seCall *curCall, *fiber_loop, *fiber_base;
   struct segc_mark_info gcmi;
#  if JSE_SECUREJSE==1
      struct Security *sloop = global->allSecurity;
#  endif

   curCall = gcmi.call = basecall;

   SEASSERT( basecall->next == NULL );
#  if JSE_STACKCHK==1
      gcmi.try_again = False;
      gcmi.mark_object_depth = 0;
#  endif
   SEASSERT( global!=NULL );

   /* Setup */

   /* first get to the base of this call-chain */
   fiber_loop = basecall->start;
#  if JSE_TASK_SCHEDULER==1
      /* then to the base of all fibers */
      while( fiber_loop->fiber_prev ) fiber_loop = fiber_loop->fiber_prev;
#  endif
   fiber_base = fiber_loop;
   SEASSERT( basecall!=NULL );

   /* First part, we mark all root items. Any objects marked, but that
    * did not have space to end up on the markstack will be picked up
    * during repeated passes through all objects on the system, looking
    * for such 'partially marked' objects.
    */

#  if JSE_STACKCHK==1
      /* can avoid the rare but possible case that a long link of referenced objects
       * is such that marking all the objects recursively would go too deep in the
       * chain.  The numbers taken here are from setting up test cases and seeing
       * how much stack was used between recursive calls to markObject(), and then
       * adding a little extra just to be cautious.  The only harm in making this
       * value too high is that it won't let the stack be as recursive so GC may
       * take slightly longer.
       */
      gcmi.go_no_further = (SE_POINTER_UINT)global->Params.stack_limit
#        if SE_STACK_DIRECTION == -1
         +
#        else
         -
#        endif
         (
#        if defined(SE_RELEASE_BUILD)
            68    /* from experiments */
#        else
            412   /* from expreiments */
#        endif
#        if JSE_MEMEXT_MEMBERS==1
            + 300
#        endif
         + 200    /* extra stack for caution */);


#  endif

#  if SE_SHARED_OBJECTS==1
      /* Assert not valid because garbage collection can be called during
       * context creation before the shared services object is set up
       */
      /* SEASSERT( SE_SHARED_SERVICES_OBJECT!=hSEObjectNull ); */
      markObject(SE_SHARED_SERVICES_OBJECT,&gcmi);
#  endif

   /* ----------------------------------------------------------------------
    * Mark the call's global structure
    * ---------------------------------------------------------------------- */

#  if JSE_MIN_OBJ_SIZE
   {
      struct func_being_put *now_being_put = global->now_being_put;
      while( now_being_put )
      {
         if ( NULL != now_being_put->func )
         {
            markFunction(now_being_put->func,&gcmi);
         }
         now_being_put = now_being_put->next;
      }
   }
#  endif

   /* show all variables locked in recent callback savers */
   {
      struct seCallbackSaver *callback_saver;
      for ( callback_saver = global->recentCallbackSaver;
            callback_saver != NULL;
            callback_saver = callback_saver->prev )
      {
         markVariable(&(callback_saver->return_var),&gcmi);
         markObject(callback_saver->wrapper_temp,&gcmi);
      }
   }

   markObject(global->stock_out_of_mem_obj,&gcmi);


#  if JSE_SECUREJSE==1
   while( sloop!=NULL )
   {
      uint i, j;

      for( i=0; i < sloop->accept.Used; i++ )
      {
         SEASSERT( sloop->accept.Funcs[i]!=NULL );
         markFunction(sloop->accept.Funcs[i],&gcmi);
      }
      for( i=0; i < sloop->guard.Used; i++ )
      {
         SEASSERT( sloop->guard.Funcs[i]!=NULL );
         markFunction(sloop->guard.Funcs[i],&gcmi);
      }
      for ( j = 0; j < SECURITY_OBJ_COUNT; j++ )
      {
         markObject(sloop->hObj[j],&gcmi);
      }
      sloop = sloop->next;
   }
#  endif
   markObject(global->global_temp,&gcmi);

   mark_seapiLockItem_list(&gcmi,global->api_lock_items.next);

   markObject(global->api_services,&gcmi);

   markObject(curCall->atexit_functions,&gcmi);

   mark_seapiLockItem_list(&gcmi,global->api_local_lock_items.next);

   /* recurse_stack: must not be used during a garbage collect */

#  if JSE_PER_OBJECT_CACHE==0
      markObject(global->recentObjectCache.hobj,&gcmi);
#  endif

   /* Don't need to mark SE501 varnames, because they keep a
    * reference count for their lock. Don't need to lock strings
    * because they use the underlying sevarGetData locking.
    */

   /* Now go through and mark all the calls */

   fiber_loop = fiber_base;
#  if JSE_TASK_SCHEDULER==1
   for( ;fiber_loop!=NULL;fiber_loop = fiber_loop->fiber_next )
#  endif
   {
      /* the 'fiber' stuff should be linking only the heads of the respective
       * chains.
          */
      SEASSERT( fiber_loop->prev==NULL );
      for( curCall = fiber_loop; curCall!=NULL; curCall = curCall->next )
      {
         struct functionSave *fsave_loop,*old_loop;
         STACKPTR base;
         STACKPTR end;

         fsave_loop = &(curCall->save);
         base = fsave_loop->stackbase;
         end = curCall->stackptr;

         do
         {
            /* mark this stack if not already going to be marked in next call */

            if ( NULL == curCall->next
              || base!=curCall->next->save.stackbase )
            {
               wSEVar i;

               for( i = base;i<=end;i++ )
                  markVariable(i,&gcmi);
#              if !defined(SE_RELEASE_BUILD) && 0
                  /* a lot of our internal code leaves tack debugging markers by putting
                   * 0xff as the type on any stack var no longer used.  Verify here that
                   * those routines are doing their job.
                   */
                  for ( ;i < (base + SE_STACK_SIZE); i++ )
                  {
                     SEASSERT( i->type == (secharptrdatum)0xFF );
                  }
#              endif
            }

            /* find the next stack */
            for ( ; ; )
            {
               old_loop = fsave_loop;
               fsave_loop = fsave_loop->prev;
               if( fsave_loop==NULL ) break;
               if( fsave_loop->stackbase!=base )
               {
                  base = fsave_loop->stackbase;
                  end = old_loop->saved_stackptr;
                  break;
               }
            }
         }
         while( fsave_loop!=NULL );

         markObject(curCall->hDynamicDefault,&gcmi);

#        if SE_LOCK_PROTOTYPE_CACHE==1
         if ( curCall->PrototypeCache.locked )
#        else
         if ( CALL_GLOBAL(curCall) == curCall->PrototypeCache.GlobalObject )
#        endif
         {
            markObject(curCall->PrototypeCache.Object,&gcmi);
            markObject(curCall->PrototypeCache.Array,&gcmi);
            markObject(curCall->PrototypeCache.Function,&gcmi);
            markObject(curCall->PrototypeCache.String,&gcmi);
         }

         markObject(CALL_GLOBAL(curCall),&gcmi);

#        if JSE_COMPACT_LIBFUNCS==1 && JSE_MULTIPLE_GLOBAL==1
         {
            struct secoreLibrary *myLib;
            for ( myLib = curCall->TheLibrary; myLib != NULL; myLib = myLib->next )
            {
               markObject(myLib->global,&gcmi);
            }
         }
#        endif

         markObject(curCall->hScopeChain,&gcmi);
         markVariable(CALL_NEWSCOPE(curCall),&gcmi);
         markObject(CALL_VAROBJ(curCall),&gcmi);

         markVariable(&(curCall->return_var),&gcmi);

         markObject(curCall->wrapper_temp,&gcmi);

         if( curCall->funcptr!=NULL )
            markFunction(curCall->funcptr,&gcmi);

         markObject(curCall->atexit_functions,&gcmi);

#        if SE_ECMA_RETURNS==1
            markVariable(&(curCall->last_expr),&gcmi);
#        endif

         for( fsave_loop = &curCall->save;
              fsave_loop!=NULL;
              fsave_loop = fsave_loop->prev )
         {
#           if JSE_MULTIPLE_GLOBAL==1
               markObject(fsave_loop->CurrentGlobalObject,&gcmi);
#           endif
            markVariable(&(fsave_loop->new_scope_chain),&gcmi);
            markObject(fsave_loop->hVariableObject,&gcmi);

            markVariable(&(fsave_loop->callback_param),&gcmi);
            markVariable(&(fsave_loop->preserve_return_var),&gcmi);
            markObject(fsave_loop->callback_this,&gcmi);

#           if JSE_NAMED_PARAMS==1
               markObject(fsave_loop->wrapper_named,&gcmi);
#           endif
         }
      }
   }

#  if JSE_DYNAMIC_CALLBACKS==1 || JSE_STACKCHK==1

#     if JSE_STACKCHK==0

         /* without JSE_STACKCHK there is no need to loop again and again to make sure everything
          * is fully marked.  One simple call do noteAllDestructors is enough.
          */
         noteAllDestructors(&gcmi);

#     else
      {
         /* it is possible that there was not enough stack space to mark the descendents
          * of all objects, and so find all marked objects that have not marked all members
          * and mark them now (and repeat until finished.)
          */
#        if JSE_DYNAMIC_CALLBACKS==1
         sebool destructors_have_been_noted = False;
         for ( ; ; )
#        endif
         {
            while( gcmi.try_again )
            {
               hSEObject hObj, hNextObj;

               gcmi.try_again = False; /* if this pass fails anywhere the point of failure will reset this */

               HSEOBJECT_BRUTE_ASSIGN(hNextObj,global->all_hobjs);
               while ( hSEObjectNull != (HSEOBJECT_BRUTE_ASSIGN(hObj,hNextObj)) )
               {
                  HSEOBJECT_BRUTE_ASSIGN(hNextObj,SEOBJECT_GET(basecall,hObj,hNext));

                  if ( SEOBJ_SWEEP_BIT == ((SEOBJ_SWEEP_BIT|SEOBJ_SWEPT_MEMS) & SEOBJECT_GET(gcmi.call,hObj,flag)) )
                  {
                     markObject(hObj,&gcmi); /* this will finish, or at minimum get one level deeper */
                  }
               }
            }

#           if JSE_DYNAMIC_CALLBACKS==1
               /* If all objects are marked than can be marked then now its time to find all destructors and
                * and possibly add them back to the mark list.  But do not do this more than once because
                * that would be a waste of time (no new destructors will be found the second time around.
                */
               if ( destructors_have_been_noted )
                  break;
               destructors_have_been_noted = True; /* so we will not do noteAllDestructors again */
               noteAllDestructors(&gcmi);
#           endif
         }
      }
#     endif

#  endif /* #if JSE_DYNAMIC_CALLBACKS==1 || JSE_STACKCHK==1 */
}

#ifndef SE_RELEASE_BUILD
   static void JSE_NEAR_CALL
assertNothingIsMarked(struct seCall *call)
{
   struct seGlobal_ *global = call->Global;
   { /* OBJECTS */
      hSEObject hobjs, hnext;
      for ( HSEOBJECT_BRUTE_ASSIGN(hobjs,global->all_hobjs); hSEObjectNull != hobjs; HSEOBJECT_BRUTE_ASSIGN(hobjs,hnext) )
      {
#        if JSE_STACKCHK==1
         if( 0 != (SEOBJECT_GET(call,hobjs,flag) & (SEOBJ_SWEEP_BIT|SEOBJ_SWEPT_MEMS)) )
#        else
         if( 0 != (SEOBJECT_GET(call,hobjs,flag) & SEOBJ_SWEEP_BIT) )
#        endif
         {
            SEASSERT( False );
         }
         HSEOBJECT_BRUTE_ASSIGN(hnext,SEOBJECT_GET(call,hobjs,hNext));
      }
   }

#  if JSE_REFCOUNT==0
      { /* FUNCTIONS */
         struct seFunction *funcs;
         for ( funcs = global->funcs; NULL != funcs; funcs = funcs->next )
         {
            if ( 0 != (funcs->flags & Func_SweepBit) )
            {
               SEASSERT( False );
            }
         }
      }
#  endif

#  if JSE_REFCOUNT==0
      { /* STRINGS */
         seString strings;
         for ( strings = global->stringdatas; NULL != strings; strings = strings->prev )
         {
            if ( 0 != SESTR_MARKED(strings) )
            {
               SEASSERT( False );
            }
         }
      }
#  endif

#  if JSE_REFCOUNT==0
      { /* STRING TABLE */
         uint i;
#        if JSE_ONE_STRING_TABLE==0
            uint sehashSize = global->sehashSize;
            struct seHashList ** sehashTable = global->sehashTable;
#        endif
         for( i = 0; i < sehashSize; i++ )
         {
            struct seHashList *current;
            for ( current = sehashTable[i]; NULL != current; current = current->next )
            {
               if ( 0 != (current->locks & JSE_SESTRING_SWEEP_BIT) )
               {
                  SEASSERT( False );
               }
            }
         }
      }
#  endif
}
#endif /* #ifndef SE_RELEASE_BUILD */

   static void JSE_NEAR_CALL
release_object_semembers(struct seCall *call,struct _SEObject *wObj)
{
   struct seGlobal_ *global = call->Global;
#  if JSE_DONT_POOL==0
   /* When items are later extracted from the object pool it is assumed
    * that they are big enough to hold at least OBJ_DEFAULT_SIZE.  Sometimes
    * the following lines will pool the object even if it's a little bigger
    * than OBJ_DEFAULT_SIZE; the reason for this decision is that allocation
    * time is saved if things are already allocated and this gives a nice
    * balance between memory use and performance.
    */
#  if JSE_PACK_OBJECTS==0
#     define WOBJ_ALLOCED wObj->alloced
#  else
#     define WOBJ_ALLOCED wObj->used
#  endif
   if( global->memPoolCount < SE_MEM_POOL_SIZE
#   if JSE_MIN_MEMORY==1
    && OBJ_DEFAULT_SIZE == WOBJ_ALLOCED )
#   else
    && OBJ_DEFAULT_SIZE <= WOBJ_ALLOCED
       && WOBJ_ALLOCED <= JSE_MEM_POOL_MAX_SIZE )
#   endif
   {
      global->mem_pool[global->memPoolCount] = wObj->hsemembers;
      /* cheat with first member to say how big it is */
      SEMEMBERS_PUT(call,wObj->hsemembers,0,name,WOBJ_ALLOCED);
      global->memPoolCount++;
   }
   else /* #if JSE_DONT_POOL==0 */
#  endif
   {
#     ifdef MEMCOUNT_MAX_MEMORY
#        if JSE_PACK_OBJECTS==0
            SEASSERT( (sizeof(struct _SEMembers)*wObj->alloced)<MEMCOUNT_MAX_MEMORY );
#        else
            SEASSERT( (sizeof(struct _SEMembers)*wObj->used)<MEMCOUNT_MAX_MEMORY );
#        endif
#     endif
      {
#        if JSE_NEVER_FREE==1
            callAddFreeItem(call,pObj->Members);
#        else
         {
            hSEMembers hThis = wObj->hsemembers;
            semembersFree(call,hThis);
         }
#        endif
      }
   }
   wObj->hsemembers = hSEMembersNull;
#  if JSE_PACK_OBJECTS==0
   wObj->alloced =
#  endif
   wObj->used = 0;
}

/* The sweeper looks through the items we garbage collect: strings, objects,
 * VarName entries, and functions. It discards unused items, either by
 * freeing them to the system or putting them back in the memory pools.
 * It restores all mark flags to unmarked if the object is not freed.
 */
   static void JSE_NEAR_CALL
sweep(struct seCall *call)
{
   struct seGlobal_ *global = call->Global;
   hSEObject hThisObj, hNextObj, hPrevObj;
#  if JSE_ONE_STRING_TABLE==0
      uint sehashSize = global->sehashSize;
      struct seHashList ** sehashTable = global->sehashTable;
#  endif

   /* Free up all objects no longer used */

   /* build up new list of still-used objects */
   HSEOBJECT_INIT_NULL(hPrevObj);
   HSEOBJECT_BRUTE_ASSIGN(hNextObj,global->all_hobjs);
   while ( hSEObjectNull != (HSEOBJECT_BRUTE_ASSIGN(hThisObj,hNextObj)) )
   {
      struct _SEObject *wObj;

      wObj = LOCK_WRITE_OBJECT(call,hThisObj);

      HSEOBJECT_BRUTE_ASSIGN(hNextObj,wObj->hNext);

      if ( (wObj->flag&SEOBJ_SWEEP_BIT)==0 )
      {
         if( wObj->hsemembers == hSEMembersNull )
         {
            SEASSERT( wObj->used == 0 );
         }
         else
         {
#           ifndef SE_RELEASE_BUILD
#              if JSE_PACK_OBJECTS==0
                  memset(LOCK_WRITE_MEMBERS(call,wObj->hsemembers),JSE_INVALID_COLLECT,
                         sizeof(struct _SEMembers)*(wObj->alloced));
#              else
                  memset(LOCK_WRITE_MEMBERS(call,wObj->hsemembers),JSE_INVALID_COLLECT,
                         sizeof(struct _SEMembers)*(wObj->used));
#              endif
#           endif
            release_object_semembers(call,wObj);
         }

         /* Unlink it from the list of all objects to either return
          * it to the system or put it in the pool.
          */
         if ( hSEObjectNull == hPrevObj )
         {
            /* no previous object, so this is the start of the list */
            SEASSERT( global->all_hobjs == hThisObj );
            HSEOBJECT_BRUTE_ASSIGN(global->all_hobjs,hNextObj);
         }
         else
         {
            /* update hPrevObj to point to whatever this points to */
            wObj = LOCK_WRITE_OBJECT(call,hPrevObj);
            HSEOBJECT_BRUTE_ASSIGN(wObj->hNext,hNextObj);
            wObj = LOCK_WRITE_OBJECT(call,hThisObj);
         }

#        if JSE_DONT_POOL==0
         if( global->hobjPoolCount < SE_OBJ_POOL_SIZE )
         {
            HSEOBJECT_BRUTE_ASSIGN(global->hobj_pool[global->hobjPoolCount++],hThisObj);
            wObj->flag = SE_DEFAULT;
         }
         else
#        endif
         {
            /* item in question must be returned to the system.
             * update pointer to next link.
             */

            /* free it */
#           ifndef SE_RELEASE_BUILD
            memset(LOCK_WRITE_OBJECT(call,hThisObj),JSE_INVALID_COLLECT,sizeof(struct _SEObject));
#           endif
#           if JSE_NEVER_FREE==1
            callAddFreeItem(call,hThisObj);
#           else
            seobjectFree(call,hThisObj);
#           endif

            /* continue so that following objs link won't change */
            continue;
         }
      }
      else
      {
         /* object is still in use, or is already on the free list,
          * restore its sweep bit flag.
          */
         HSEOBJECT_BRUTE_ASSIGN(hPrevObj,hThisObj);

#        if JSE_STACKCHK==1
            SEASSERT( (wObj->flag&SEOBJ_SWEPT_MEMS)!=0 );
            wObj->flag &= (objflag)~(SEOBJ_SWEEP_BIT|SEOBJ_SWEPT_MEMS);
#        else
            wObj->flag &= (objflag)~SEOBJ_SWEEP_BIT;
#        endif

#        if !defined(SE_RELEASE_BUILD) && JSE_MEM_DEBUG==1 && JSE_TRACK_MEMUSE==0
         {
            /* theoretically, any object may have changed as a result of
             * garbage collections (deletes or dynamics) and so the members
             * list might possibly have moved.  Here we will force it to move
             * to encourage any possible bugs to show up as early as possible.
             */
            sememcount alloced;
#           if JSE_PACK_OBJECTS==0
            alloced = wObj->alloced;
#           else
            alloced = wObj->used;
#           endif
            if ( 0 != alloced )
            {
               /* resizing to current size just to force it to move,
                * don't worry about failure.
                */
               ResizeObjectMembers(call,hThisObj,alloced,False);
               wObj = LOCK_WRITE_OBJECT(call,hThisObj);
            }
         }
#        endif

#        if JSE_SHRINK_STABLE_OBJECTS==1 && JSE_PACK_OBJECTS==0
         {
            /* sometimes the number of objects allocated is much more than the
             * number used.  Than can eat up a lot of memory.  GC is a good time
             * to adjust that, since growth usually only happens while building
             * an object, this is not likely to cause a growth-shrinkage cycle.
             * Also, this only happens on non-stable objects so objects that are
             * probably currently changing frequenlty will not be shrunk.
             */
            if ( wObj->used != wObj->alloced ) /* all moot if used == alloced */
            {
               SEASSERT( wObj->used < wObj->alloced );
#              if JSE_ALWAYS_COLLECT==1
                  SEASSERT( 0 == (wObj->flag & SEOBJ_UNSTABLE) );
#              endif
               if ( 0 == (wObj->flag & SEOBJ_UNSTABLE) )
               {
                  /* this object can be reduced */
                  if ( 0 == wObj->used )
                  {
                     release_object_semembers(call,wObj);
                  }
                  else
                  {
                     /* don't worry if it fails, we are only trying to shrink
                      * it, so if the original, too large, block remains, so
                      * be it.
                      */
                     ResizeObjectMembers(call,hThisObj,wObj->used,False);
                  }
               }
               else
               {
                  /* mark as stable between this pass of GC and the next pass so
                   * if there is not change by then this this object will be cleaned.
                   */
                  wObj->flag &= (objflag)~SEOBJ_UNSTABLE;
               }
            }
         }
#        endif
      }
   }

#  if JSE_REFCOUNT==0
   {
      struct seFunction **funcplace;
      struct seFunction *funcs;

      /* Free up all functions no longer used */
      funcs = global->funcs;

      /* build up new list of still-used functions */
      funcplace = &(global->funcs);

      while( funcs!=NULL )
      {
         struct seFunction *tmp = funcs->next;

         if( (funcs->flags & Func_SweepBit)==0 )
         {
            /* get rid of it */
            sefunctionDelete(call,funcs);
         }
         else
         {
            /* keep it */
            funcs->flags &= (uword8)~Func_SweepBit;

            *funcplace = funcs;
            funcplace = &(funcs->next);
         }
         funcs = tmp;
      }
      *funcplace = NULL;
   }
#  endif

#  if JSE_REFCOUNT==0
   {
      seString *strings, string;
      /* Free up all strings no longer used */
      strings = &(global->stringdatas);
      while( NULL != (string=*strings) )
      {
         /* shared strings should be in the global list only */
#        if SE_SHARED_OBJECTS==1
            SEASSERT( (string->flags&SESTR_SHARED)==0 );
#        endif
         if( !SESTR_MARKED(string) )
         {
            /* unlink it and get rid of it */
            *strings = string->prev;

#           if !defined(SE_RELEASE_BUILD) && JSE_MEMEXT_STRINGS==0 /* don't let this flush cache */
            {
               void *data = SESTRING_GET_DATA(call,string);
#              if JSE_MBCS==1
                  memset(data,JSE_INVALID_COLLECT,string->bytelength);
#              else
                  /* We used to memset *sizeof(sechar). The problem is that
                   * in Unicode builds, if this was a buffer, then the
                   * 'length' is in bytes. So zero as much memory as we are
                   * sure is ok to do so.
                   */
                  memset(data,JSE_INVALID_COLLECT,(string->length));
#              endif
            }
#           endif

#           if JSE_POOL_STRINGDATA==0
               SESTRING_FREE_DATA(call,string);
#           endif

#           if JSE_DONT_POOL==0
               if( global->sestringPoolCount < SE_STRING_POOL_SIZE )
                  global->sestring_pool[global->sestringPoolCount++] = string;
               else
#           endif
            {
#              if JSE_POOL_STRINGDATA==1
                  SESTRING_FREE_DATA(call,string);
#              endif

#           if !defined(SE_RELEASE_BUILD) && JSE_POOL_STRINGDATA==0
               memset(string,JSE_INVALID_COLLECT,sizeof(*string));
#           endif

#           if JSE_NEVER_FREE==1
               callAddFreeItem(call,string);
#           else
               secoreFree(call,string);
#           endif
            }
         }
         else
         {
            SESTR_UNMARK(string);
            strings = &(string->prev);
         }
      }
   }
#  endif

#  if JSE_REFCOUNT==0
   {
      uint i;

      /* sweep the string table */
      for( i = 0; i < sehashSize; i++ )
      {
         struct seHashList **next = &(sehashTable[i]);

         while( *next!=NULL )
         {
            if( (*next)->locks==0 )
            {
               struct seHashList *old = (*next);
               *next = (*next)->next;
               /* Not marked and not locked */
               RemoveSEStringTableEntry(call,old);
            }
            else
            {
               (*next)->locks &= (sestringlocks)(~JSE_SESTRING_SWEEP_BIT);
               next = &((*next)->next);
            }
         }
      }
   }
#  endif
}

#endif /* #if JSE_UTIL_SEGMENT==1 */


#if JSE_DYNAMIC_CALLBACKS==1
#if JSE_UTIL_SEGMENT==1
/* Call each of the destructors in the call's global destructor table.
 * All are called, destructors cannot resurrect themselves (the object
 * may no longer be garbage, but its destructor will be called.)
 */
   static void JSE_NEAR_CALL
destructors(struct seCall *call)
{
   struct seGlobal_ *global = call->Global;

   /* This may seem weird, but it allows recursive collection/
    * destructor calling to work - they use the same 'global'
    * area.
    */

   /* on some occasions calldyna will happen and GC may happen, so force it always */
   ALWAYS_COLLECT(call)

   while( global->destructorCount>0 )
   {
      hSEObject hToDestroy;
      const struct seObjectCallbacks * callbacks;

      HSEOBJECT_BRUTE_ASSIGN(hToDestroy,global->hDestructors[--global->destructorCount]);

      /* on some occasions calldyna will happen and GC may happen, so force it always */
      ALWAYS_COLLECT(call)

      /* can't destroy it while it is in use. */
      callbacks = SEOBJECT_GET_callbacks(call,hToDestroy);
      if ( NULL != callbacks )
      {
         if ( NULL != callbacks->deleteProp )
         {
            seobjCallDynamicProperty(call,hToDestroy,SE_DELETEPROP_CALLBACK,
                                     SE_NO_VARNAME,NULL,NULL);
         }
#        if JSE_MIN_OBJ_SIZE==1
            SEOBJECT_PUT_callbacks(call,hToDestroy,NULL);
#        else
            SEOBJECT_PUT(call,hToDestroy,flag,
                         (objflag)(SEOBJECT_GET(call,hToDestroy,flag)&(objflag)(~OBJ_IS_DYNAMIC)));
#        endif
      }
   }
}


/* Call _all_ destructors in any seObject left. Because we remove
 * destructors after we call them, no destructors will be called
 * twice. This is used when the program is about to exit, a last
 * chance call of all remaining destructors.
 */
   void NEAR_CALL
callDestructors(struct seCall *call,sebool shared)
{
   struct seGlobal_ *global = call->Global;
   sebool again;

   global->flags |= final_destructors;


#  if SE_SHARED_OBJECTS==0
      SEASSERT( shared==FALSE );
      SE_UNUSED_PARAMETER(shared);
#  endif

   do {
      hSEObject hobj;

      again = False;
      global->destructorCount = 0;

#     if SE_SHARED_OBJECTS==1
      if( shared )
      {
         HSEOBJECT_BRUTE_ASSIGN(hobj,se_all_hobjs);
      }
      else
#     endif
      {
         HSEOBJECT_BRUTE_ASSIGN(hobj,global->all_hobjs);
      }
      while( hobj!=hSEObjectNull )
      {
         hSEObject hNextObj;
         sebool hasDeleteProp;

         HSEOBJECT_BRUTE_ASSIGN(hNextObj,SEOBJECT_GET(call,hobj,hNext));
         hasDeleteProp = SEOBJ_IS_DYNAMIC_PROP(call,hobj,deleteProp);
         if( hasDeleteProp )
         {
            if ( !roomForOneMoreDestructor(call) )
            {
               if( global->destructorAlloced==0 )
               {
                  /* In this case, we have no storage to even do some
                   * of the destructors, not much we can do except try
                   * to call it right away. This is even more likely to
                   * an infinite loop than the above case. However, such
                   * a thing is still a mistake in the user's object design.
                   * It is better to protect the customer who is using it
                   * right (by not just aborting his program for lack of
                   * memory) than favor the customer who is using it wrong
                   * (by aborting because we cannot guarantee an infinite loop
                   * won't happen), IMO. Thus, we call the destructors one
                   * at a time and an infinite loop cannot always be detected.
                   */
                  global->destructorCount = 1;
                  SEASSERT( global->hDestructors==NULL );
                  global->hDestructors = &hobj;
                  destructors(call);
                  global->destructorCount = 0;
                  global->hDestructors = NULL;

                  /* Continue looking for objects and calling them one at
                   * a time.
                   */
                  continue;
               }
               again = True;
               break;
            }
            /* hNextObj may have moved, so refind */
            HSEOBJECT_BRUTE_ASSIGN(hNextObj,SEOBJECT_GET(call,hobj,hNext));
            HSEOBJECT_ASSIGN(global->hDestructors[global->destructorCount++],hobj); /* maybe brute? */
         }
         HSEOBJECT_BRUTE_ASSIGN(hobj,hNextObj);
      }

      destructors(call);
   } while( again );
}
#endif /* #if JSE_UTIL_SEGMENT==1 */
#endif /* #if JSE_DYNAMIC_CALLBACKS!=0 */


/* ----------------------------------------------------------------------
 * Garbage collects. It expects the sweep bits on all variables to be
 * not set, and it will make sure that is still the case before it exits.
 * After it collects, it will 'fill up' the allocator pools.
 * ---------------------------------------------------------------------- */

#if JSE_UTIL_SEGMENT==1









































   void
secoreGarbageCollect(struct seCall *call)
{
   struct seGlobal_ *global = call->Global;
   sebool do_not_refill = ( 0 != (global->flags & collect_do_not_refill) );

#  if SE_WRITE_SHARED_OBJECTS==1
   /* If cannot get semaphore, don't collect and let caller
    * just allocate one more item.
    */
   if( !SE_SEMAPHORE_TRYSTART(&se_markbits_semaphore) )
      return;
#  endif


   /* global fine since all calls in chain share it */
   call = call->end;
   SEASSERT( NULL == call->next );

#  ifndef SE_RELEASE_BUILD
   {
      /* we should frequently check that the out_of_mem object has not been messed up. This
       * is a good place to check on that, just to be sure.
       */
#     if JSE_MEMEXT_OBJECTS==1
#        define oum_obj global->internal_out_of_mem_hobj
#     else
#        define oum_obj &(global->internal_out_of_mem_obj)
#     endif

      SEASSERT( SEOBJECT_GET(call,oum_obj,used) == 0 );
      SEASSERT( 0 != (SEOBJECT_GET(call,oum_obj,flag) & SEOBJ_READ_ONLY) );
#     if JSE_STACKCHK==1
         SEASSERT( 0 == ( SEOBJECT_GET(call,oum_obj,flag) \
                        & ~(SEOBJ_READ_ONLY|SEOBJ_SWEEP_BIT|SEOBJ_SWEPT_MEMS|SEOBJ_IS_ARRAY)) );
#     else
         SEASSERT( 0 == ( SEOBJECT_GET(call,oum_obj,flag) \
                        & ~(SEOBJ_READ_ONLY|SEOBJ_SWEEP_BIT|SEOBJ_IS_ARRAY)) );
#     endif
      SEASSERT( NULL == SEOBJECT_GET_func(call,oum_obj) );
#     if JSE_CALLBACKS==1
         SEASSERT( NULL == SEOBJECT_GET_callbacks(call,oum_obj) );
#     endif
   }
#  endif

   if ( 0 == global->collect_disable++ )
   {
      TIMER_SAVE

      TIMING(call,garbage);

#     if JSE_REFCOUNT==0
         /* We will be collecting as many strings as possible, so zero this. */
         global->stringallocs = 0;
#     endif

#     ifndef SE_RELEASE_BUILD
         assertNothingIsMarked(call);
#     endif

      /* go through and mark everything that is being used */
      mark(call);

      /* sweep unused stuff onto the free lists */
      sweep(call);

#     ifndef SE_RELEASE_BUILD
         assertNothingIsMarked(call);
#     endif





#     if JSE_DONT_POOL==0
         /* collectRefill the allocator pools so the destructors have the needed structures
          * to allocate.
          */
         if ( !do_not_refill )
         {
            seCollectRefill(call);
         }
#     endif

#     if JSE_DYNAMIC_CALLBACKS==1
         destructors(call);
#        if JSE_DONT_POOL==0
            if ( 0 == global->hobjPoolCount )
            {
               /* destructors ate up all objects. Memory must be very low.  One last try to get objects */
               if ( !do_not_refill )
               {
                  seCollectRefill(call);
               }
            }
#        endif
#     endif

      /* we call destructors and return, so that really isn't
       * part of garbage collection, that is part of the generic
       * ScriptEase execution time.
       */
      END_TIMING(call);
   }
   else
   {
      /* Garbage collection is disabled, we only collectRefill the allocator
       * pools. This allows a program to specify a realtime block it
       * doesn't want garbage collected in.  But GC can be called for many
       * reasons-the only one that must must must be attempted is to make sure
       * the object pool is not totally empty.
       */
#     if JSE_DONT_POOL==0
         if( global->hobjPoolCount==0 )
         {
            if ( !do_not_refill )
            {
               seCollectRefill(call);
            }
         }
#     endif
   }
   global->collect_disable--;


#  if SE_WRITE_SHARED_OBJECTS==1
   if( se_collection_count++>=SE_WRITE_SHARED_COLLECTIONS )
   {
      sharedGarbageCollect(call);
      se_collection_count = 0;
   }

   SE_SEMAPHORE_STOP(&se_markbits_semaphore);
#  endif
}
#endif /* #if JSE_UTIL_SEGMENT==1 */


/* ---------------------------------------------------------------------- */



#ifdef JSE_MEM_SUMMARY
struct AnalMalloc {
   struct AnalMalloc *Prev;
   uint size; /* this does not include the four bytes at the beginning
                 and end */
   ulong AllocSequenceCounter;
   ulong line;           /*__LINE__*/
   seassert_filetype file; /*__FILE__*/
   ubyte Head[4];
   ubyte data[1];
};
extern VAR_DATA(struct AnalMalloc *) RecentMalloc;

   static void JSE_NEAR_CALL
memDump(struct seCall *call)
{
   struct AnalMalloc *AM;
   ulong stable_count = 0,stable_mem = 0;
   ulong misc_count = 0,misc_mem = 0;
   ulong sdata_count = 0,sdata_mem = 0;
   ulong sdesc_count = 0,sdesc_mem = 0;
   ulong objmem_count = 0,objmem_mem = 0;
   ulong object_count = 0,object_mem = 0;
#  if JSE_DONT_POOL==0
      ulong argvpool_count = 0,argvpool_mem = 0;
#  endif
   ulong libfunc_count = 0,libfunc_mem = 0;
   ulong locfunc_count = 0,locfunc_mem = 0;
   ulong strcpy_count = 0,strcpy_mem = 0;
   ulong desttable_count = 0,desttable_mem = 0;
   ulong gstack_count = 0,gstack_mem = 0;
   ulong global_count = 0,global_mem = 0;
   ulong cenvi_count = 0,cenvi_mem = 0;
   ulong total_count = 0,total_mem = 0;

   for ( AM = RecentMalloc; NULL != AM; AM = AM->Prev )
   {
      if( AM->line==434 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\util.c")==0 )
      {
#        if 0
         struct seHashList *hl = (struct seHashList *)AM->data;
         printf("String table entry: %s\n",VarNameFromHashList(hl));
#        endif
         stable_count++; stable_mem += AM->size;
      }
      else if( AM->line==1245 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\util.c")==0 )
      {
         stable_count++; stable_mem += AM->size;
      }
      else if( AM->line==1228 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\util.c")==0 )
      {
         global_count++; global_mem += AM->size;
      }
      else if( AM->line==1210 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\util.c")==0 )
      {
         global_count++; global_mem += AM->size;
      }
      else if( AM->line==313 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\call.c")==0 )
      {
         gstack_count++; gstack_mem += AM->size;
      }
      else if( AM->line==1280 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\util.c")==0 )
      {
         gstack_count++; gstack_mem += AM->size;
      }
      else if( AM->line==1580 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\jselib.c")==0 )
      {
         sdata_count++; sdata_mem += AM->size;
      }
      else if( AM->line==1568 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\jselib.c")==0 )
      {
         sdata_count++; sdata_mem += AM->size;
      }
      else if( AM->line==1363 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\varutil.c")==0 )
      {
         /* obj member realloc */
         objmem_count++; objmem_mem += AM->size;
      }
      else if( AM->line==1353 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\varutil.c")==0 )
      {
         /* obj member first alloc alternate */
         objmem_count++; objmem_mem += AM->size;
      }
      else if( AM->line==2405 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\util.c")==0 )
      {
         /* expand vlibfunc */
         libfunc_count++; libfunc_mem += AM->size;
      }
      else if( AM->line==2450 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\util.c")==0 )
      {
         /* regular function */
         libfunc_count++; libfunc_mem += AM->size;
      }
      else if( AM->line==40 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\loclfunc.c")==0 )
      {
         /* local function structure */
         locfunc_count++; locfunc_mem += AM->size;
      }
      else if( AM->line==86 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\loclfunc.c")==0 )
      {
         /* realloc tokens */
         locfunc_count++; locfunc_mem += AM->size;
      }
      else if( AM->line==244 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\loclfunc.c")==0 )
      {
         /* realloc arrays */
         locfunc_count++; locfunc_mem += AM->size;
      }
      else if( AM->line==157 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\loclfunc.c")==0 )
      {
         locfunc_count++; locfunc_mem += AM->size;
      }
      else if( AM->line==1471 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\expressn.c")==0 )
      {
         locfunc_count++; locfunc_mem += AM->size;
      }
#     if JSE_DONT_POOL==0
      else if( AM->line==1298 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\util.c")==0 )
      {
         argvpool_count++; argvpool_mem += AM->size;
      }
#     endif
      else if( AM->line==698 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\garbage.c")==0 )
      {
         /* allocate object */
         object_count++; object_mem += AM->size;
      }
      else if( AM->line==1062 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\garbage.c")==0 )
      {
         objmem_count++; objmem_mem += AM->size;
      }
      else if( AM->line==1157 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\garbage.c")==0 )
      {
         sdata_count++; sdata_mem += AM->size;
      }
      else if( AM->line==1220 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\garbage.c")==0 )
      {
         /* create buffer */
         sdata_count++; sdata_mem += AM->size;
      }
      else if( AM->line==880 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\garbage.c")==0 )
      {
         /* create buffer */
         desttable_count++; desttable_mem += AM->size;
      }
      else if( AM->line==234 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\var.c")==0 )
      {
         /* realloc of string data */
         sdata_count++; sdata_mem += AM->size;
      }
      else if( AM->line==63 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\varutil.c")==0 )
      {
         sdata_count++; sdata_mem += AM->size;
      }
      else if( AM->line==1085 && strcmp(AM->file,"..\\..\\..\\..\\..\\srccore\\garbage.c")==0 )
      {
         sdesc_count++; sdesc_mem += AM->size;
      }
      else if( AM->line==549 && strcmp(AM->file,"..\\..\\srcmisc\\utilstr.c")==0 )
      {
         strcpy_count++; strcpy_mem += AM->size;
      }
      else if( strstr(AM->file,"srccenvi")!=NULL )
      {
         cenvi_count++; cenvi_mem += AM->size;
      }
      else
      {
         printf(
           UNISTR("Memory Block: Sequence = %lu, size = %u, ptr = %08lX line=%lu of file=%s\n"),
           AM->AllocSequenceCounter,AM->size,AM->data,AM->line,AM->file);
         misc_count++; misc_mem += AM->size;
      }
      total_count++; total_mem += AM->size;
   }

   printf("Objects:                     %04d:%08d\n",object_count,object_mem);
   printf("Object member arrays:        %04d:%08d\n",objmem_count,objmem_mem);
   printf("StringTable entries:         %04d:%08d\n",stable_count,stable_mem);
   printf("String descriptors:          %04d:%08d\n",sdesc_count,sdesc_mem);
   printf("String data:                 %04d:%08d\n",sdata_count,sdata_mem);
   printf("Library functions:           %04d:%08d\n",libfunc_count,libfunc_mem);
   printf("Script functions:            %04d:%08d\n",locfunc_count,locfunc_mem);
#  if JSE_DONT_POOL==0
   printf("Argv pool:                   %04d:%08d\n",argvpool_count,argvpool_mem);
#  endif
   printf("Strcpys:                     %04d:%08d\n",strcpy_count,strcpy_mem);
   printf("Destructor table:            %04d:%08d\n",desttable_count,desttable_mem);
   printf("The secode stack:            %04d:%08d\n",gstack_count,gstack_mem);
   printf("Calls and their global:      %04d:%08d\n",global_count,global_mem);
   printf("Cenvi allocations:           %04d:%08d\n",cenvi_count,cenvi_mem);
   printf("Unknown:                     %04d:%08d\n\n",misc_count,misc_mem);

   printf("Totals:                      %04d:%08d\n",total_count,total_mem);
   printf("Assuming 12 byte overhead per allocation,\n"
          "Total memory used:                %08d\n\n",12*total_count+total_mem);
   printf("Maximum:                     %04d:%08d\n",jseMaxTotalMemoryAllocations,jseMaxTotalMemoryAllocated);
   printf("Assuming 12 byte overhead per allocation,\n"
          "Max total memory used:            %08d\n",12*jseMaxTotalMemoryAllocations+jseMaxTotalMemoryAllocated);
}
#endif /* #ifdef JSE_MEM_SUMMARY */

#endif   /* if JSE_GC==1 */
