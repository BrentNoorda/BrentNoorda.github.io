/* se501.c
 *
 * SE501 API interface. This file replaces 'jselib.c' and
 * the few SE440 API funcs elsewhere (jseengin.c, util.c).
 * It can coexist or completely replace it.
 */

/************************************************************************
 *  Copyright (c) 1993-2004 Anchor Acquisition, Inc., a subsidiary of   *
 *  Openwave Systems Inc. All rights reserved.                          *
 *                                                                      *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Openwave Systems Inc. *
 *    The copyright notice above does not evidence any                  *
 *    actual or intended publication of such source code.               *
 ************************************************************************/

#define __ASSERT_FILENO__ 10

#include "srccore.h"


















#if 0
/* Here is my todo list. The write shared document, intented
 * to become a manual section, is in codedoc as writeshare.txt.
 * I'm not sure if se501 got an existing GC writeup, if so
 * update to this new version else add this new version
 * somewhere appropriate.
 *
 * The write shared coding is all #ifdefed via
 * SE_WRITE_SHARED_OBJECTS and is not complete. The checklist
 * below indicates all the items left to do to make it work.
 * I've thought about it a lot and I'm pretty confident it will
 * work and that I didn't overlook any gotchas.
 *
 * The SE_SHARED_SERVICES read-shared stuff is done and in
 * the manual. I updated the cleanup with the problems Brent
 * found, as is noted below our library code needs a going-
 * over to make it is shared compatible. There is a grep in
 * 'c:\se501\tmp' of our accesses to SE_SERVICES that need
 * investigation.
 *
 * The rest of the stuff is mostly miscellaneous tests I wanted
 * to make more thorough. Some of them may have been done
 * by others already. There is also a few desktop glitches
 * I noticed recently. Though the se501 desktop is building
 * now, I believe we still have 440 as our release desktop
 * so se501 is bound to have more problems.
 *
 *
 * As can be seen, there is not much here other than the
 * shared object stuff I was working on. In the last couple
 * months, Brent hasn't dumped too much new stuff on me
 * so I was able to get basically everything I had on hold
 * done. This is especially noticeable in the Unix distributions.
 * They are now done 'well', updated to be easy to use and
 * simple, and all the tests work (ones that had failed due to
 * being Windows-specific didn't seem too pressing compared to
 * stuff that didn't work.) This is an example of the sort of
 * thing my todo list had consisted of, a bunch of little items
 * that I'd like to see done better but they were good enough
 * when more pressing issues were at hand.
 *
 * Of course, I hate to see it all end, but the timing code-wise
 * is pretty good. At least for the stuff I was doing, nothing is
 * broken. The code state, especially the Unix distributions
 * which are about the only area that I work on exclusively
 * (i.e. all other areas other people work on too), is as
 * good as it has ever been. Right now, I can think of nothing
 * that I need to do with the Unix distributions and with the
 * code. Basically, all existing work is done and the only changes
 * needed are in response to bugs being found. The shared object
 * stuff is all new additions and so can just be forgotten and
 * at least customers can use the engine in the best state its
 * ever been in. Of course, this is all from my point of view,
 * it may be that others did not get so lucky in the timing and
 * have flaky code they were in the middle of working on.
 *
 * The read-shared addition is done but not thoroughly tested
 * and our libraries are not updated yet. It might be best to
 * pretend it doesn't exist. The write-shared stuff will never
 * see the light of day at all, but it would have been cool.
 *
 *
 *                                              Rich Robinson
 *                                              Feb 5, 2003
 */


----------------------------------------------------------------------
o go through our libraries and see if any are not read-shared
  via SE_SERVICES compatible. - see 'tmp'

  Basically, either make them SE_SHARED_SERVICES or if they
  need to use SE_SERVICES, also throw in an at-exit function
  to clean it up. The at-exit function should erase itself
  and the SE_SERVICES member.

  Ensure that none of the libraries do any cleanup in a lib
  termination function of SE_SERVICES that should be done in
  an at-exit function
----------------------------------------------------------------------
write shared checklist:


SE_WRITE_SHARED_OBJECTS==1
   - initialize and terminate the semaphores
   - initialize and terminate the shared lists (same as read-shared)
     also free the shared pools

   - each context gets a list of used shared items
   - protect read of an object mem via the semaphore, if
     object is read may potentially have to move the object
     to the shared list for the thread
   - add a cache of recently added items for the above
   - protect write of an object mem via the semaphore, before
     grabbing the semaphore, if the object is shared then
     mark the thingee being stored as shared if not already.
     When marking a thingee and its children as shared,
     each one marked also has to be put on the in-use list.
     Move these to a temporary global list that is not GCd
     (i.e. will not be deleted because of inuse) and these
     get moved to the real list before each shared collection.
     This means if a context wants to add them during a
     collection, it is not held up by waiting for the collection.
     Likewise, they are moved to a temporary context shared
     list. They are marked as temp shared.

     Note that the object is marked as temp-shared, the reference
     added to the temp list, then the object moved to its temp
     list in that order.
   - make GC not traverse shared items, just mark them at
     the top level, then go through the lists of shared items
     and remove them if not marked (and remove from cache too)
   - each context must get the 'access lists' lock before it can
     clean up - it protects the list of current contexts as well.
   - write the shared-object gc. temp-shared objects are just
     ignored when found. garbage.c - sharedGarbageCollect
   - shared pools
   - each context needs to keep an allocation count for each
     item and if this exceeds the pool size, do a collection
     (if it can). Collections zero these counts. This prevents
     one thread from never collecting and building up junk
     because it just happens to always find pool members
     refilled by other threads collecting.
----------------------------------------------------------------------
o var arguments; - when initializing local vars, hardcode
  a check for arguments. If so, instead of initializing it
  to undefined, initialize it to the arguments object.

  search on 'pass one is only for creating locals on the stack' in call.c

o FAQ: under construction in c:\se501\faq.txt

o look at valgrind in n:\joust\tars on new linux machine

o >> doesnt work in con32 shell, works fine in win32

tests
-----

o browser tests, dynamic enumeration and scoping, and
  the security model.
o extend eval.c to test flags & evalparams when calling a function,
  not just when calling a script.
o write security.c test for seEval + security
o extend the fiber test to test yield and suspend.
o much more extensive tests on the XML stuff.
o add to seEval/call function a test of an error in the
  called function.
o add a JSE_PASSBYREF off test

#endif


/* ---------------------------------------------------------------------- */

#define DONE_SEVARNAME(call,t,vn) if( (t)<=SE_HIDDEN_TYPE ) RemoveSEVarNameLock((vn))
#define SESTACKINFO(x) (STOCK_OBJ_NUM(x)-SE_STACK_INFO_NUM)
#define seIsValidMemType(a) ( SE_UNIMEM_TYPE<=(a) && (a)<=SE_STOCK_TYPE )
#define STOCK_OBJ_NUM(x)   ((((seVarName)(SE_POINTER_UINT)(x))-1)/2)

#if defined(SE_RELEASE_BUILD)


#  define seassert_is_context(call)    /* no check */
#  define seassert_is_object(obj)      /* no check */
#  define seassert_is_varname(vname)   /* no check */
#  define seassert_is_string(call,str) /* no check */

#  define IS_STOCK_OBJ(x)  ( ((seVarName)(SE_POINTER_UINT)(x)) < (seVarName)SEOBJECT(NUM_STOCK_OBJECTS) )

#  define IS_STACK_INFO(x) ( (seVarName)SE_STACK_INFO(0) <= ((seVarName)(SE_POINTER_UINT)(x)) )
   /* called only when we already know it is a STOCK_OBJ */                                           \

#else

      static sebool JSE_NEAR_CALL
   IS_STOCK_OBJ(seobject x)
   {
      if ( ((seVarName)(SE_POINTER_UINT)(x)) < (seVarName)SEOBJECT(NUM_STOCK_OBJECTS) )
      {
         SEASSERT( ( (((uint)(seVarName)(SE_POINTER_UINT)(x)) & 1) != 0 ) );
         SEASSERT( (seVarName)SE_GLOBAL <= ((seVarName)(SE_POINTER_UINT)(x)) );
         return True;
      }
      return False;
   }

      static sebool JSE_NEAR_CALL
   IS_STACK_INFO(seobject x)  /* called only when we already know it is a STOCK_OBJ */
   {
      SEASSERT( IS_STOCK_OBJ(x) );
      return ( (seVarName)SE_STACK_INFO(0) <= ((seVarName)(SE_POINTER_UINT)(x)) );
   }

#  define SE501_VARNAME_ID 0x9178

#  define seassert_is_context(call) SEASSERT( (call)!=NULL && (call)->cookie==jseContext_cookie );

      static void JSE_NEAR_CALL
   seassert_is_object(seobject obj)
   {
      SEASSERT( NULL != obj );
      if ( !IS_STOCK_OBJ(obj) )
      {
         SEASSERT( NULL != obj->prev );
         SEASSERT( seLI_GET_TYPE((obj)->flags) == seLI_OBJECT );
      }
   }

#  define seassert_is_varname(n) SEASSERT( (n)!=SE_NO_VARNAME && NULL!=GetSEStringTableEntry(call,(n),NULL) );

#  if JSE_UTIL_SEGMENT==1
      static struct seapiLockItem * JSE_NEAR_CALL
      find_seTempLockString(struct seCall *call,seconstcharptr str);

         static void JSE_NEAR_CALL
      seassert_is_string(struct seCall *call,seconstcharptr data)
      {
         SEASSERT( NULL != data );
         if ( data != call->Global->null_TempString )
         {
            struct seapiLockItem *li;
            li = find_seTempLockString(call,data);
            SEASSERT( NULL != li );
            SEASSERT( NULL != li->prev );
         }
      }
#  endif

#endif


#if SE_SHARED_OBJECTS==1
static sebool JSE_NEAR_CALL moveObjectToReadShared(struct seCall *call,hSEObject hobj);
#endif

/* utility routines */

/* ---------------------------------------------------------------------- */

#if JSE_UTIL_SEGMENT==1
/* Implement the standard SE501 lifetime rules */

   static struct seapiLockItem * JSE_NEAR_CALL
get_seapiLockItem(struct seCall *call,hSEObject lock_o  RECV_FILE_AND_LINE_PARMS )
/* lock_o will be protected in case of GC; return NULL if failure */
{
   struct seapiLockItem *li;
   wSEVar tmp;
   struct seGlobal_ * global = call->Global;

   SEASSERT( hSEObjectNull != lock_o );

   if( global->seapi_temp_pool_count )
   {
      li = global->seapi_temp_pool[--(global->seapi_temp_pool_count)];
#     if JSE_ALWAYS_COLLECT==1
         /* following code could have force GC; so force here too */
         tmp = STACK_PUSH; /* just to lock in case of GC */
         SEVAR_INIT_OBJECT(tmp,lock_o);
         secoreGarbageCollect(call);
         STACK_POP; /* tmp */
#     endif
   }
   else
   {
      /* rare chance of GC happening and killing obj before it's locked, so
       * lock within stack
       */
      tmp = STACK_PUSH; /* just to lock in case of GC */
      SEVAR_INIT_OBJECT(tmp,lock_o);
      li = (struct seapiLockItem *)secoreAlloc(call,NULL,sizeof(struct seapiLockItem),SE_DEFAULT);
      STACK_POP; /* tmp */
      if ( NULL == li )
         return NULL;
   }
#  if JSE_TRACKVARS==1
      li->file = file;
      li->line = line;
#  endif
   li->next = global->api_local_lock_items.next;
   li->prev = &(global->api_local_lock_items);
   if( li->next ) li->next->prev = li;
   global->api_local_lock_items.next = li;
   li->mark = global->api_mark;
   li->hSavedScopeChain = hSEObjectNull;

   return li;
}

   static seobject JSE_NEAR_CALL
seTempLockObject(struct seCall *call,hSEObject o,hSEObject ssc  RECV_FILE_AND_LINE_PARMS )
{
   /* all locks start out in the api_temps area */
   seobject obj;

   if ( IS_OUT_OF_MEM_OBJ(call,o)
     || NULL == (obj = get_seapiLockItem(call,o  PASS_FILE_AND_LINE_PARMS)) )
   {
      return SE_NOWHERE;
   }

   HSEOBJECT_INIT_ASSIGN(obj->data.obj,o);
   HSEOBJECT_INIT_ASSIGN(obj->hSavedScopeChain,ssc);
   obj->flags = seLI_OBJECT | seLI_IS_TEMP;
   obj->str_lookup = NULL; /* so string lookup never matches this */
#  if SE_API_OBJECT_COUNT_WARNING!=0  &&  !defined(SE_RELEASE_BUILD)
      seShowIfTooManyObjects(call);
#  endif

   return obj;
}

   static struct seapiLockItem * JSE_NEAR_CALL
find_seTempLockString(struct seCall *call,seconstcharptr str)
/* return whether this string is already in one of the lists */
{
   int i;
   struct seapiLockItem *apiList = call->Global->api_local_lock_items.next;
   for ( i = 0; i < 2; i++ )
   {
      while( NULL != apiList )
      {
         if ( apiList->str_lookup == str )
         {
            return apiList;
         }
         apiList = apiList->next;
      }
      apiList = call->Global->api_lock_items.next;
   }
   return NULL;
}

#define seLOCKSTR__AS_VAR  0 /* parameter passed in is an sevar */
#define seLOCKSTR__AS_NAME 1 /* parameter passed in is an varname */
#define seLOCKSTR__AS_STR  2 /* parameter passed in is an seconstcharptr, and *get_len must point to length */
   static seconstcharptr JSE_NEAR_CALL
seTempLockString(struct seCall *call,const t_sememdata data,int lockstr_type,sememcount *get_len,
                 sebool check_for_duplication  RECV_FILE_AND_LINE_PARMS )
/* if as_val is NULL then use as_name - get_len can be NULL */
{
   /* all locks start out in the api_temps area */
   seconstcharptr ret;
   struct seapiLockItem *li;

   if ( seLOCKSTR__AS_STR == lockstr_type )
   {
      SEASSERT( NULL != get_len );
      if ( *get_len == 0 )
         goto ret_null_string;

#     if SE_GETSTRING_SHORT_POOL!=0
         if ( *get_len < ( sizeof(call->Global->sestring_short_pool[0].data)         \
                         / sizeof(call->Global->sestring_short_pool[0].data[0]) ) )
         {
            /* this string is short enough to fit into one of our short pools.  Store it
             * there if one is available.
             */
            struct seStringShortPoolItem *spi = call->Global->sestring_short_pool;
            int i;
            for ( i = SE_GETSTRING_SHORT_POOL; i--; spi++ )
            {
               if ( !spi->used )
               {
                  /* this slot is available, so return this one */
                  if ( NULL == (li=get_seapiLockItem(call,call->hDynamicDefault  PASS_FILE_AND_LINE_PARMS)) )
                  {
                     goto ret_null_string;
                  }
                  STRCPYLEN_SECHAR(spi->data,(seconstcharptr)data,*get_len);
                  spi->used = 1;
                  li->flags = seLI_STR_POOL | seLI_IS_TEMP;
                  li->data.len = *get_len;
                  li->str_lookup = spi->data;
#                 if SE_API_STRING_COUNT_WARNING!=0 && !defined(SE_RELEASE_BUILD)
                     seShowIfTooManyStrings(call);
#                 endif
                  return spi->data;
               }
            }
         }
#     endif

      /* must allocate memory and store in the allocated memory */
      ret = secoreStrndup(call,(seconstcharptr)data,*get_len);
      if ( NULL == ret )
         goto ret_null_string;

      if ( NULL == (li=get_seapiLockItem(call,call->hDynamicDefault  PASS_FILE_AND_LINE_PARMS)) )
      {
         secoreFree(call,(void *)ret);
         goto ret_null_string;
      }

      li->flags = seLI_STRALLOC | seLI_IS_TEMP;
      li->data.len = *get_len;
      li->str_lookup = ret;
#     if SE_API_STRING_COUNT_WARNING!=0 && !defined(SE_RELEASE_BUILD)
         seShowIfTooManyStrings(call);
#     endif
   }
   else
   {
      sememcount get_len_holder;
      if ( NULL == get_len )
         get_len = &get_len_holder;

      if ( seLOCKSTR__AS_NAME == lockstr_type )
      {
         seVarName as_name = (seVarName)data;

         SEASSERT( SE_NO_VARNAME != as_name );

         if( IsNormalSEStringTableEntry(as_name) )
         {
            /* normal strings can return their pointer directly, if it's not already in the api_temps list */
            struct seHashList *vname = HashListFromSEVarName(as_name);
            ret = NameFromseHashList(vname);
            *get_len = (sememcount)LenFromseHashList(vname);
            SEASSERT( check_for_duplication || NULL==find_seTempLockString(call,ret) );
            if ( check_for_duplication && find_seTempLockString(call,ret) )
            {
               ret = seTempLockString(call,(const t_sememdata)(SE_POINTER_UINT)ret,seLOCKSTR__AS_STR,get_len,\
                                      False  PASS_FILE_AND_LINE_PARMS );
            }
            else
            {
               /* great! this name can be returned directly */
               if ( NULL == (li=get_seapiLockItem(call,call->hDynamicDefault  PASS_FILE_AND_LINE_PARMS)) )
               {
                  goto ret_null_string;
               }

               li->str_lookup = ret;
               li->data.name = vname;
               li->flags = seLI_HASHLIST | seLI_IS_TEMP;
#              if SE_API_STRING_COUNT_WARNING!=0 && !defined(SE_RELEASE_BUILD)
                  seShowIfTooManyStrings(call);
#              endif
            }
         }
         else if ( ST_STOCK_ENTRY == ST_FORMAT(as_name) )
         {
            /* stock entries are always in memory */
            enum jseStockStringID id = (enum jseStockStringID)ST_DATA(as_name);
            ret = (seconstcharptr)jseGetStockString(JSECONTEXT_FROM_CALL(call),id);
            *get_len = (sememcount)strlen_sechar(ret);
            SEASSERT( 0 != *get_len );
            SEASSERT( check_for_duplication || NULL==find_seTempLockString(call,ret) );
            if ( check_for_duplication && find_seTempLockString(call,ret) )
            {
               ret = seTempLockString(call,(const t_sememdata)(SE_POINTER_UINT)ret,seLOCKSTR__AS_STR,get_len,\
                                      False  PASS_FILE_AND_LINE_PARMS );
            }
            else
            {
               /* great! this name can be returned directly */
               if ( NULL == (li=get_seapiLockItem(call,call->hDynamicDefault  PASS_FILE_AND_LINE_PARMS)) )
               {
                  goto ret_null_string;
               }
               li->str_lookup = ret;
               li->data.len = *get_len;
               li->flags = seLI_STOCK | seLI_IS_TEMP;
#              if SE_API_STRING_COUNT_WARNING!=0 && !defined(SE_RELEASE_BUILD)
                  seShowIfTooManyStrings(call);
#              endif
            }
         }
         else
         {
            /* this is a shortened string, which must be expanded to get full form.  So make this into
             * a variable type and call this function recursively to save it in the as_var format.
             */
            sestringLenType slt_len;
            ret = GetSEStringTableEntry(call,as_name,&slt_len);

            *get_len = slt_len;
            ret = seTempLockString(call,(const t_sememdata)(SE_POINTER_UINT)ret, \
                                   seLOCKSTR__AS_STR,get_len,False  PASS_FILE_AND_LINE_PARMS );
         }
      }
      else
      {
         /* data is in the as_val temporary variable */
         sememcount bytelen;
         wSEVar as_val = (wSEVar)data;
         SEASSERT( seLOCKSTR__AS_VAR == lockstr_type );
         SEASSERT( SEVAR_GET_TYPE(as_val)==VString  ||  SEVAR_GET_TYPE(as_val)==VShortString );

         ret = sevarGetStr(call,as_val,get_len,&bytelen);

         SEASSERT( check_for_duplication || NULL==find_seTempLockString(call,ret) );

#        if JSE_MEMEXT_STRINGS==1

            /* the result of sevarGetStr() may only be in the lock-cache, and not be as long-lived
             * as the user may want.  So, darnit, this must be allocated separately.
             */
            ret = seTempLockString(call,(const t_sememdata)ret,seLOCKSTR__AS_STR,get_len,False  PASS_FILE_AND_LINE_PARMS );

#        else

            SEASSERT( check_for_duplication || NULL==find_seTempLockString(call,ret) );

            if ( VShortString==SEVAR_GET_TYPE(as_val)
              || ( check_for_duplication && find_seTempLockString(call,ret) ) )
            {
               /* return a duplicated version here */
               ret = seTempLockString(call,(const t_sememdata)(SE_POINTER_UINT)ret,\
                                      seLOCKSTR__AS_STR,get_len,False  PASS_FILE_AND_LINE_PARMS );
            }
            else
            {
               /* save as new seLI_IS_STRING type */
               if ( NULL == (li=get_seapiLockItem(call,call->hDynamicDefault  PASS_FILE_AND_LINE_PARMS)) )
                  goto ret_null_string;

               li->str_lookup = ret;
               li->data.sestr = as_val->data.string_val;
               li->flags = seLI_SESTR | seLI_IS_TEMP;
#              if SE_API_STRING_COUNT_WARNING!=0 && !defined(SE_RELEASE_BUILD)
                     seShowIfTooManyStrings(call);
#              endif
            }
#        endif
      }
   }
   return ret;

ret_null_string:
   *get_len = 0;
   return call->Global->null_TempString;
}
#endif /* #if JSE_UTIL_SEGMENT==1 */

#if JSE_EXECUTE_SEGMENT==1
   void
seTempFreeItem(struct seCall *call,struct seapiLockItem *apiItem)
{
   SEASSERT( call != NULL );
   SEASSERT( apiItem!=NULL );

#  ifndef SE_RELEASE_BUILD
   {
      uword8 t = seLI_GET_TYPE(apiItem->flags);
      sebool ok = False;
      if ( t == seLI_HASHLIST )           ok = True;
#     if JSE_MEMEXT_STRINGS==0
         else if ( t == seLI_SESTR )      ok = True;
#     endif
      else if ( t == seLI_OBJECT )        ok = True;
      else if ( t == seLI_STOCK )         ok = True;
      else if ( t == seLI_STRALLOC )      ok = True;
#     if SE_GETSTRING_SHORT_POOL!=0
      else if ( t == seLI_STR_POOL )      ok = True;
#     endif
      SEASSERT( ok );
      if ( apiItem->str_lookup == NULL )
      {
         SEASSERT( t == seLI_OBJECT );
         seassert_is_object(apiItem);
      }
      else
      {
         SEASSERT( t != seLI_OBJECT );
#        if JSE_UTIL_SEGMENT==1
            /* would be nice to test in all segments, but not worth
             * adding another pointer just for this assert
             */
            seassert_is_string(call,apiItem->str_lookup);
#        endif
      }
   }
#  endif

   if ( seLI_STRALLOC <= apiItem->flags )
   {
      /* these types need to be cleaned up when they're freed */
      #if SE_GETSTRING_SHORT_POOL!=0
      if ( seLI_STR_POOL <= apiItem->flags )
      {
         /* this pool item is free */
         SEASSERT( seLI_STR_POOL == seLI_GET_TYPE(apiItem->flags ) );
         SEASSERT( ((struct seStringShortPoolItem *)(apiItem->str_lookup))->used == 1 );
         ((struct seStringShortPoolItem *)(apiItem->str_lookup))->used = 0;
      }
      else
      #endif
      {
         /* free this allocated string immediately */
         SEASSERT( seLI_STRALLOC == seLI_GET_TYPE(apiItem->flags) );
         secoreFree(call,(void *)(apiItem->str_lookup));
      }
   }

   /* If prev is NULL, then someone is trying to free a special object like SE_ARGS. */
   SEASSERT( NULL != apiItem->prev );

   /* unlink in both directions */
   if ( NULL != (apiItem->prev->next = apiItem->next) )
      apiItem->next->prev = apiItem->prev;

#  ifndef SE_RELEASE_BUILD
      apiItem->flags = 0xFF;  /* force the seassert calls to fail if it is reused */
#  endif

   if( call->Global->seapi_temp_pool_count < SE_API_TEMP_POOL_SIZE )
   {
      call->Global->seapi_temp_pool[(call->Global->seapi_temp_pool_count)++] = apiItem;
   }
   else
   {
      secoreFree(call,apiItem);
   }
}
#endif /* #if JSE_EXECUTE_SEGMENT==1 */

#if JSE_UTIL_SEGMENT==1

   JSECALLSEQ( void )
#if JSE_TRACKVARS==1
seWeakLockObjectDbg(secontext se,seobject obj,sebool weak,seassert_filetype file,int line)
#else
seWeakLockObject(secontext se,seobject obj,sebool weak)
#endif
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   seassert_is_object(obj);

   /* nothing to do for stock objects */
   if( !IS_STOCK_OBJ(obj) )
   {
      if( 0 != (obj->flags & seLI_IS_TEMP) )
      {
         /* unlock it from the temps */
         if ( NULL != (obj->prev->next = obj->next) )
            obj->next->prev = obj->prev;

         /* relink it into the long-term ones */
         obj->next = call->Global->api_lock_items.next;
         obj->prev = &(call->Global->api_lock_items);
         if( obj->next ) obj->next->prev = obj;
         call->Global->api_lock_items.next = obj;
      }

      /* make it weak or not */
      obj->flags = (uword8)( weak ? (seLI_OBJECT|seLI_WEAK) : seLI_OBJECT );
      if ( weak )
      {
         /* Unset the hSavedScopeChain on a weak lock.  Why?
          * Because it gets awfully confusing in the garbage collector:
          * do we mark the savedScopeChain on a weak lock?  That is real
          * hard to answer.  Much easier is to unset the savedScopeChain
          * and not think about it.
          */
         obj->hSavedScopeChain = hSEObjectNull;
      }

#     if JSE_TRACKVARS==1
         obj->file = file;
         obj->line = line;
#     endif
   }

   END_TIMING(call);
   SE_API_RETURN_VOID(call);
}

   JSECALLSEQ( seobject )
#if JSE_TRACKVARS==1
seCloneObjectDbg(secontext se,seobject origobj,seassert_filetype file,int line)
#else
seCloneObject(secontext se,seobject origobj)
#endif
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   seobject ret;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   seassert_is_object(origobj);

   /* nothing to do for stock objects */
   if( IS_STOCK_OBJ(origobj) )
   {
      ret = origobj;
   }
   else
   {
      ret = seTempLockObject(call,origobj->data.obj,origobj->hSavedScopeChain  PASS_FILE_AND_LINE_PARMS );
      if ( SE_NOWHERE != ret )
      {
         SEASSERT( ret == call->Global->api_local_lock_items.next );
         ret->mark = origobj->mark;

         if ( 0 == ((ret->flags = origobj->flags) & seLI_IS_TEMP) )
         {
            struct seGlobal_ * global = call->Global;
            /* move new object out of the temporary list and on to the permanent list */
            if ( NULL != (global->api_local_lock_items.next = ret->next) )
               ret->next->prev = &(global->api_local_lock_items);

            if ( NULL != (ret->next = global->api_lock_items.next) )
               ret->next->prev = ret;
            ret->prev = &(global->api_lock_items);
            global->api_lock_items.next = ret;
         }
      }
   }

   END_TIMING(call);

   SE_API_RETURN(call,ret);
}

#endif /* #if JSE_UTIL_SEGMENT==1 */

/* string versions */

#if JSE_UTIL_SEGMENT==1
   JSECALLSEQ( void )
#if JSE_TRACKVARS==1
seLockStringDbg(secontext se,const void *data,seassert_filetype file,int line)
#else
seLockString(secontext se,const void *data)
#endif
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   seassert_is_string(call,data);

   if ( (secharptr)data != call->Global->null_TempString )
   {
      struct seapiLockItem *str = (struct seapiLockItem *)data;

      if( 0 != (str->flags & seLI_IS_TEMP) )
      {
         /* unlock it from the temps */
         if ( NULL != (str->prev->next = str->next) )
            str->next->prev = str->prev;

         /* relink it into the long-term ones */
         str->next = call->Global->api_lock_items.next;
         str->prev = &(call->Global->api_lock_items);
         if( str->next ) str->next->prev = str;
         call->Global->api_lock_items.next = str;

         str->flags = seLI_GET_TYPE(str->flags);
      }

#     if JSE_TRACKVARS==1
         str->file = file;
         str->line = line;
#     endif
   }

   END_TIMING(call);
   SE_API_RETURN_VOID(call)
}

   JSECALLSEQ( const void * )
#if JSE_TRACKVARS==1
seCloneStringDbg(secontext se,const void *data,seassert_filetype file,int line)
#else
seCloneString(secontext se,const void *data)
#endif
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   struct seGlobal_ * global;
   seconstcharptr ret;
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   seassert_is_string(call,data);

   if ( (secharptr)data == (global=call->Global)->null_TempString )
   {
      ret = data;
   }
   else
   {
      sememcount len;
      struct seapiLockItem *li = find_seTempLockString(call,data);
      struct seapiLockItem *new_li;
      uint type; /* this should be uword8, or even be attainable directly without needing this
                  * extra variable, but an apparent bug in linux/gcc/release compiler
                  * fails tests below if this is a wurd8 or grabbed directly.
                  */

      SEASSERT( NULL != li );

      type = seLI_GET_TYPE(li->flags);
      if ( seLI_STOCK <= type )
      {
#        if SE_GETSTRING_SHORT_POOL!=0
            SEASSERT( type==seLI_STOCK || type==seLI_STRALLOC || type==seLI_STR_POOL );
#        else
            SEASSERT( type==seLI_STOCK || type==seLI_STRALLOC );
#        endif
         len = li->data.len;
      }
#     if JSE_MEMEXT_STRINGS==0
      else if ( type == seLI_SESTR )
      {
         len = li->data.sestr->length;
      }
#     endif
      else
      {
         SEASSERT( type == seLI_HASHLIST );
         len = (sememcount)LenFromseHashList(li->data.name);
      }

      ret = seTempLockString(call,(const t_sememdata)(SE_POINTER_UINT)(li->str_lookup),\
                             seLOCKSTR__AS_STR,&len,False  PASS_FILE_AND_LINE_PARMS );

      new_li = global->api_local_lock_items.next;
      SEASSERT( new_li->str_lookup == ret );
      new_li->mark = li->mark;
      if ( 0 == (li->flags & seLI_IS_TEMP) )
      {
         /* move new li out of the temporary list and on to the permanent list */
         if ( NULL != (global->api_local_lock_items.next = new_li->next) )
            new_li->next->prev = &(global->api_local_lock_items);

         if ( NULL != (new_li->next = global->api_lock_items.next) )
            new_li->next->prev = new_li;
         new_li->prev = &(global->api_lock_items);
         global->api_lock_items.next = new_li;
         new_li->flags = (uword8)(new_li->flags & ~seLI_IS_TEMP);
      }
   }
   SE_API_RETURN(call,ret);
}
#endif /* #if JSE_UTIL_SEGMENT==1 */

/* ---------------------------------------------------------------------- */

/* Initialization routines */
#if JSE_MULTI_CORE==1
   typedef int (JSE_CFUNC FAR_CALL * jseInitTable)(struct seFuncTable_t *);
#  if JSE_COMPILER_SEGMENT==1 || JSE_EXECUTE_SEGMENT==1 || JSE_UTIL_SEGMENT==1
#     if defined(__JSE_PALMOS__)
         sebool __Startup__(struct seFuncTable_t *t);
         sebool __Startup__(struct seFuncTable_t *t)
#     else
         JSE_WIN32_DECL sebool JSE_CFUNC jseInitializeTable(struct seFuncTable_t *t);
         JSE_WIN32_DECL sebool JSE_CFUNC jseInitializeTable(struct seFuncTable_t *t)
#     endif
      {
#        if 0
#        if defined(__JSE_PALMOS__) && !defined(SE_RELEASE_BUILD)
#           if JSE_COMPILER_SEGMENT==1
               seconstcharptr segment_name = "COMPILER";
#           endif
#           if JSE_EXECUTE_SEGMENT==1
               seconstcharptr segment_name = "EXECUTE";
#           endif
#           if JSE_UTIL_SEGMENT==1
               seconstcharptr segment_name = "UTIL";
#           endif
            DebugPrintf("segment %s &__DummyStartup__ = %08lX\n",segment_name,(long)((long)(&DebugPrintf)-12));
#        endif
#        endif
         return InitSelinkTables(t);
      }
#  endif /* #if JSE_COMPILER_SEGMENT==1 || JSE_EXECUTE_SEGMENT==1 || JSE_UTIL_SEGMENT==1 */
#endif /* #if JSE_MULTI_CORE==1 && defined(__JSE_DLLRUN__) */

#if JSE_MULTI_CORE==0 \
 || (defined(__JSE_PALMOS__) && (JSE_UTIL_SEGMENT==0 && JSE_COMPILER_SEGMENT==0 && JSE_EXECUTE_SEGMENT==0)) \
 || (defined(JSE_PSEUDO_PALMOS) && JSE_UTIL_SEGMENT==1)
#  if JSE_MULTI_CORE==0
      JSECALLSEQ(uint) seInitialize()
#  else
#     if defined(__JSE_PALMOS__)
#        include "shlib.h"
         uint jseInitDLLRUN(UInt16 refNum,struct seFuncTable_t *t);
         uint jseInitDLLRUN(UInt16 refNum,struct seFuncTable_t *t)
#     else
         JSE_WIN32_DECL uint JSE_CFUNC jseInitDLLRUN(struct seFuncTable_t **pt)
#     endif
#  endif
{
#  if 0
#  if defined(__JSE_PALMOS__) && !defined(SE_RELEASE_BUILD)
      DebugPrintf("segment ISDKLib &__DummyStartup__ = %08lX\n",(long)((long)(&DebugPrintf)-12));
#  endif
#  endif
#  if defined(__JSE_DLLRUN__)
   {
      /* if the table size is not what we expect, or it is not version 501,
       * the table size is likely to be off if the engine and the application
       * are being built with different jseopt.h options, which may change
       * how many entries are in the tables
       */
      if ( t->TableSize != sizeof(*t) )
      {
         SEDBG(DebugPrintf(UNISTR("t->TableSize = %d, expected %d\n"),(int)(t->TableSize),(int)sizeof(*t)));
         return (uint)(-14);
      }
      if ( t->Version != JSEEXTERNALVER )
      {
         SEDBG(DebugPrintf(UNISTR("t->Version = %d, expected %d\n"),(int)(t->Version),(int)JSEEXTERNALVER));
         return (uint)(-1);
      }

#     ifdef JSE_STACK_CHECKER
         t->init_stack_pointer = (char *)(&t);
#     endif

      if ( !InitSelinkTables(t) )
      {
         SEDBG(DebugPrintf(UNISTR("!InitSelinkTables(t)\n")));
         return (uint)(-2);
      }
#     if defined(__JSE_PALMOS__)
         if ( !(t->gDB = BeginPalmDatabase()) )
         {
            SEDBG(DebugPrintf(UNISTR("!BeginPalmDatabase()\n")));
            return (uint)(-3);
         }
#     endif
#     if JSE_MULTI_CORE==1
#     if defined(__JSE_WIN32__) || defined(__JSE_CON32__)
      {
         jseInitTable funcptr;

         /* load in the other half of the engine */
         t->compile_module = LoadLibrary("compile.dll");
         SEASSERT( NULL != t->compile_module );
         t->execute_module = LoadLibrary("execute.dll");
         SEASSERT( NULL != t->execute_module );
         t->objlib_module = LoadLibrary("objlib.dll");
         SEASSERT( NULL != t->objlib_module );
         funcptr = (jseInitTable)GetProcAddress(t->compile_module,"jseInitializeTable");
         SEASSERT( NULL != funcptr );
         (*funcptr)(t);
         funcptr = (jseInitTable)GetProcAddress(t->execute_module,"jseInitializeTable");
         SEASSERT( NULL != funcptr );
         (*funcptr)(t);
         funcptr = (jseInitTable)GetProcAddress(t->objlib_module,"jseInitializeTable");
         SEASSERT( NULL != funcptr );
         (*funcptr)(t);
      }
#     endif /* if defined(__JSE_WIN32__) || defined(__JSE_CON32__) */

#     if defined(__JSE_PALMOS__)
      {
         jseInitTable funcptr;
         MemPtr module_P;

         SE_UNUSED_PARAMETER(refNum);

         if ( !(t->code_database = DmOpenDatabaseByTypeCreator(shLibTypeID,shLibCreatorID,dmModeReadOnly)) )
         {
            SEDBG(DebugPrintf(UNISTR("!DmOpenDatabaseByTypeCreator()\n")));
            return (uint)(-4);
         }

         /* initialize pointers in this segment */
         t->BeginFunctionListFunc = BeginFunctionList;
         t->AddToLibTableFunc = AddToLibTable;
         t->EndLibTableAndCompactFunc = EndLibTableAndCompact;

#        if JSE_FLOATING_POINT==1
         {
            Err error;
            error = SysLibFind(MathLibName, &(t->MathLibRef));
            if ( error )
               error = SysLibLoad(LibType, MathLibCreator, &(t->MathLibRef));
            if ( !error )
               MathLibOpen(t->MathLibRef, MathLibVersion);
            else
            {
               SEDBG(DebugPrintf(UNISTR("Unable to load MathLib\n")));
               return (uint)(-5);
            }
         }
#        endif

         t->util_module = DmGetResource(kCodeResourceType,kSEUtilResourceID);
         if( NULL != t->util_module )
         {
            module_P = MemHandleLock(t->util_module);
            funcptr = module_P;
            (*funcptr)(t);
         }
         else
         {
            SEDBG(DebugPrintf(UNISTR("Unable to load util module\n")));
            return (uint)(-6);
         }

         t->compile_module = DmGetResource(kCodeResourceType,kCompileResourceID);
         if( NULL != t->compile_module )
         {
            module_P = MemHandleLock(t->compile_module);
            funcptr = module_P;
            (*funcptr)(t);
         }
         else
         {
            SEDBG(DebugPrintf(UNISTR("Unable to load compile module\n")));
            return (uint)(-7);
         }

         t->execute_module = DmGetResource(kCodeResourceType,kExecuteResourceID);
         if( NULL != t->execute_module )
         {
            module_P = MemHandleLock(t->execute_module);
            funcptr = module_P;
            (*funcptr)(t);
         }
         else
         {
            SEDBG(DebugPrintf(UNISTR("Unable to load execute module\n")));
            return (uint)(-8);
         }
         t->objlib_module = DmGetResource(kCodeResourceType,kObjLibResourceID);
         if( NULL != t->objlib_module )
         {
            module_P = MemHandleLock(t->objlib_module);
            funcptr = module_P;
            (*funcptr)(t);
         }
         else
         {
            SEDBG(DebugPrintf(UNISTR("Unable to load objlib module\n")));
            return (uint)(-9);
         }
         t->seobjectlib_module = DmGetResource(kCodeResourceType,kSeObjectLibResourceID);
         if( NULL != t->seobjectlib_module )
         {
            module_P = MemHandleLock(t->seobjectlib_module);
            funcptr = module_P;
            (*funcptr)(t);
         }
         else
         {
            SEDBG(DebugPrintf(UNISTR("Unable to load seobjectlib module\n")));
            return (uint)(-10);
         }
         t->regexplib_module = DmGetResource(kCodeResourceType,kRegExpLibResourceID);
         if( NULL != t->regexplib_module )
         {
            module_P = MemHandleLock(t->regexplib_module);
            funcptr = module_P;
            (*funcptr)(t);
         }
         else
         {
            SEDBG(DebugPrintf(UNISTR("Unable to load regexplib module\n")));
            return (uint)(-11);
         }
         t->datelib_module = DmGetResource(kCodeResourceType,kDateLibResourceID);
         if( NULL != t->datelib_module )
         {
            module_P = MemHandleLock(t->datelib_module);
            funcptr = module_P;
            (*funcptr)(t);
         }
         else
         {
            SEDBG(DebugPrintf(UNISTR("Unable to load datelib module\n")));
            return (uint)(-12);
         }
      }
#     endif /* #if defined(__JSE_PALMOS__) */
#     if defined(__JSE_PALMOS__) || defined(JSE_PSEUDO_PALMOS)
         InitializeJSEStringTables(t);
         InitializeJSETextlibTables(t);
#     endif /* #if defined(__JSE_PALMOS__) || defined(JSE_PSEUDO_PALMOS) */
#     endif /* #if JSE_MULTI_CORE==1 */
   }
#  endif /* if defined(__JSE_DLLRUN__) */

#  if JSE_COMPILER_SEGMENT==1 && JSE_COMPILER==1
#     if !defined(SE_RELEASE_BUILD)
         validate_getTokOperator();
#     endif
#  endif

#  if JSE_MEM_DEBUG==1 && !defined(__JSE_PALMOS__)
      jseInitializeMallocDebugging();
#  endif

#  if JSE_FP_EMULATOR==1
      initialize_FP_constants();
#  endif

   if ( !InitializejseEngine() )
   {
#     if JSE_MEM_DEBUG==1 && !defined(__JSE_PALMOS__)
         jseTerminateMallocDebugging();
#     endif
#     if JSE_MEM_SABOTAGE==0
         /* sabotage is expected to fail. so son't print that here */
         SEDBG(DebugPrintf(UNISTR("!InitializejseEngine()\n")));
#     endif
      return (uint)(-13);
   }

   return SE_ENGINE_VERSION_ID;
}
#endif

#if (!defined(__JSE_PALMOS__) && JSE_UTIL_SEGMENT==1) \
 ||  (defined(__JSE_PALMOS__) && (JSE_UTIL_SEGMENT==0 && JSE_COMPILER_SEGMENT==0 && JSE_EXECUTE_SEGMENT==0))

#if JSE_MULTI_CORE==0
   JSECALLSEQ(void)
seTerminate()
#else
   JSECALLSEQ(void)
seTerminate(const struct seFuncTable_t *t)
#endif
{
#  if JSE_MEM_DEBUG==1 && !defined(__JSE_LIB__)  &&  !defined(__JSE_PALMOS__)
      if ( 1 == seEngineThreadCount )
         jseTerminateMallocDebugging();
#  endif

#  if JSE_ONE_STRING_TABLE==1
      if ( 1 == seEngineThreadCount )
         freeGlobalSEStringTable();
#  endif

#  if SE_SHARED_OBJECTS==1
      SEASSERT(NULL != se_so_hashTable);
      jseFree(NULL,se_so_hashTable);
#  endif

#  if ( ( JSE_MEM_DEBUG==1 && !defined(__JSE_LIB__) )  ||  JSE_ONE_STRING_TABLE==1) \
   && !defined(__JSE_PALMOS__)
      seEngineThreadCount--;
      SEASSERT( seEngineThreadCount >= 0 );
#  endif

#  if JSE_MEM_DEBUG==1  && !defined(__JSE_PALMOS__)
      jseTerminateMallocDebugging();
#  endif

#  if defined(__JSE_PALMOS__) || defined(JSE_PSEUDO_PALMOS)
      TerminateJSEStringTables(t);
#  endif
#  if defined(__JSE_PALMOS__)
      DmCloseDatabase( t->code_database );
#  endif
#  if JSE_MULTI_CORE==1
#  if defined(__JSE_WIN32__) || defined(__JSE_CON32__)
         FreeLibrary(t->objlib_module);
         FreeLibrary(t->execute_module);
         FreeLibrary(t->compile_module);
#     endif
#  endif
}
#endif


#if JSE_UTIL_SEGMENT==1
/*
 * Current method: userkey is stored in a static global variable.
 * link data is set and gotten using the stock seGetPointer()
 * routines. Global variable name is set using these routines.
 */
   JSECALLSEQ(secontext)
seCreateBlankContext(const struct seContextParams * const params,const char *userKey)
{
   struct seCall * call;
   secontext se;

   SEASSERT( params!=NULL );









   SE_UNUSED_PARAMETER(userKey);

   {
      if( params->sePrintErrorFunc==NULL )
      {
         SEDBG(DebugPrintf(UNISTR("Must have an sePrintErrorFunc.\n")));
         call = NULL;
      }
      else
      {
         call = callInitial(params);
      }
   }

   stack_depth()

   se = call?JSECONTEXT_FROM_CALL(call):NULL;

#  if SE_SHARED_OBJECTS==1
      if ( call )
      {
         se_context_count++;

         if( se_context_count==1 )
         {
            SEASSERT( SE_SHARED_GENERIC_DATA==NULL );
            SEASSERT( SE_SHARED_SERVICES_OBJECT==NULL );
            SEASSERT( se_first_context==NULL );

            se_first_context = call;
            SE_SHARED_SERVICES_OBJECT = seobj_new(call,0);
            if ( IS_OUT_OF_MEM_OBJ(call,SE_SHARED_SERVICES_OBJECT) )
            {
               seDestroyContext(se);
               se = NULL;
            }
         }
         else
         {
            SEASSERT( SE_SHARED_SERVICES_OBJECT!=NULL );
            SEASSERT( se_first_context!=NULL );
         }
      }
#  endif

   return se;
}



#if JSE_TASK_SCHEDULER==1
/* NYI: callInterpret, and this routine all do more or
 *      less the same code. Since it is a big block, make an internal core
 *      routine to do it and have them call it.
 */
   JSECALLSEQ( secontext )
seCreateFiber(secontext parentSE)
{
   struct seCall *parent = CALL_FROM_JSECONTEXT(parentSE);
   struct seCall *top_parent;
   struct _SEVar *newstack;
   TIMER_SAVE
   struct seCall *call;

   TIMING(parent,se);


   SEASSERT( parent!=NULL );
   while( parent->next!=NULL ) parent = parent->next;

   /* Allocate a structure for use.
    */
   if( (call = (struct seCall *)secoreAlloc(parent,NULL,sizeof(struct seCall),SE_DEFAULT))==NULL )
   {
      return NULL;
   }

   newstack = (struct _SEVar *)secoreAlloc(parent,NULL,SE_STACK_SIZE*sizeof(struct _SEVar),SE_DEFAULT);
   if( newstack==NULL )
   {
      secoreFree(parent,call);
      return NULL;
   }

   /* We still need to create this because the scope chain has to
    * be correct;it will be used later on and it is expected
    * to be fleshed out.
    */
   if( CALL_VAROBJ(parent)==hSEObjectNull )
      callCreateVariableObject(parent,NULL,0);

   memset( call, 0, sizeof(struct seCall));
#  if JSE_CACHE_GLOBAL_VARS==1
      se_init_cache_global_vars(call);
#  endif

#  ifndef SE_RELEASE_BUILD
      call->cookie = (uword8) jseContext_cookie;
#  endif

   /* chain it in */
   top_parent = parent->start;
   SEASSERT( top_parent->prev==NULL );
   if( top_parent->fiber_next ) top_parent->fiber_next->fiber_prev = call;
   call->fiber_next = top_parent->fiber_next;
   top_parent->fiber_next = call;
   call->fiber_prev = top_parent;

   call->Global = parent->Global;
   setCallEnds(call);
   call->start = call;
   HSEOBJECT_INIT_ASSIGN(CALL_GLOBAL(call),CALL_GLOBAL(parent));
   SEASSERT( !call->pastGlobals );

   /* The settings are:
    *
    * SE_NEW_GLOBAL     -> off, we share the same global
    * SE_NO_LIBRARIES   -> on,  we use the existing libraries in the existing global
    * SE_NEW_DEFINES    -> on,  any new defines are for this fiber only
    * SE_EXIT_LEVEL     -> on,  each fiber expected to do its at-exit function.
    * SE_NO_EXTLIBS     -> off, uses existing extlibs and shares them
    */
   call->CallSettings = SE_EXIT_LEVEL|SE_NEW_DEFINES|SE_NO_INHERIT|SE_NO_LIBRARIES;

   /* copy old session settings possibly to be overwritten */
   HSEOBJECT_INIT_ASSIGN(call->hDynamicDefault,parent->hDynamicDefault);

#  if SE_LOCK_PROTOTYPE_CACHE==1
      call->PrototypeCache = parent->PrototypeCache;
#  endif
   FLUSH_PROTOTYPE_CACHE(call);

#  if JSE_SECUREJSE==1
      call->currentSecurity = parent->currentSecurity;
#  endif
#  if JSE_DEFINE==1
      call->Definitions = parent->Definitions;
#  endif
   call->TheLibrary = parent->TheLibrary;
   HSEOBJECT_INIT_ASSIGN(call->atexit_functions,parent->atexit_functions);
#  if JSE_LINK==1
      call->ExtensionLib = parent->ExtensionLib;
#  endif

   SEASSERT( FRAME == NULL );
   STACKBASE = newstack;

   SEASSERT( 0 == call->sePutMemberDepth_check_hidden );

   call->stackptr = STACKBASE;
#  ifndef SE_RELEASE_BUILD
      memset(STACKBASE,0xFF,SE_STACK_SIZE*sizeof(struct _SEVar));
#  endif

   /* The first slot in the stack is not used and must be
    * valid for the collector. This is done because it allows
    * the stack index to never go to negatives, which makes
    * a lot of stuff easier. (Else, it would go to -1 when
    * the stack is empty.)
    */
   SEVAR_INIT_UNDEFINED(call->stackptr);

   SEASSERT( call->save.iptr == NULL );

#  if SE_ECMA_RETURNS==1
      SEVAR_INIT_UNDEFINED(&(call->last_expr));
#  endif

   SEASSERT( call->tries == NULL );
   HSEOBJECT_INIT_NULL(CALL_VAROBJ(call));
   call->state = StateNormal;
   SEASSERT( call->funcptr == NULL );
#  ifndef SE_RELEASE_BUILD
      call->continueCount = 0; /* this should never start as zero - catch when it is */
#  endif

#  if JSE_NAMED_PARAMS==1
      HSEOBJECT_INIT_NULL(call->save.wrapper_named);
#  endif

   /* GC may happen at any time; make return_var OK */
   SEVAR_INIT_UNDEFINED( &(call->return_var) );

   call->mustPrintError = True;
   SEASSERT( !call->errorPrinted );
   SEVAR_INIT_UNDEFINED(CALL_NEWSCOPE(call));

   HSEOBJECT_INIT_NULL(call->hScopeChain);     /* for if we collect trying to allocate one */
   HSEOBJECT_BRUTE_ASSIGN(call->hScopeChain,seobj_new(call,(sememcount)-1));

   SEASSERT( call->start_info == NULL );

   SEASSERT( CALL_IS_PRESERVE_RETURN(call) );

   if( !callNewSettings(call,call->CallSettings) )
   {
      if( call->fiber_next ) call->fiber_next->fiber_prev = call->fiber_prev;
      if( call->fiber_prev ) call->fiber_prev->fiber_next = call->fiber_next;
      secoreFree(parent,call);
      secoreFree(parent,newstack);
      return NULL;
   }

#  if JSE_CACHE_GLOBAL_VARS==1
      SEASSERT( JSE_GLOBAL_CACHE_SIZE>=2 );
      /* zero the cache */
#  endif

   END_TIMING(parent);

   return JSECONTEXT_FROM_CALL(call);
}
#endif /* #if JSE_TASK_SCHEDULER==1 */


   JSECALLSEQ( void )
seDestroyContext(secontext se)
{
   struct seCall *call;
   sebool again;

   do
   {
      call = CALL_FROM_JSECONTEXT(se);
      seassert_is_context( call )
      again = (call->prev)!=NULL;

#     if SE_SHARED_OBJECTS==1
      if( call==se_first_context  &&  1 < se_context_count )
      {
         SEDBG(DebugPrintf(UNISTR("With SE_SHARED_OBJECTS turned on, the first created\n") \
                           UNISTR("context must be the last deleted.\n")));
         return;
      }
#     endif

      callDelete(call);

#     if SE_SHARED_OBJECTS==1
      if( call==se_first_context )
      {
         se_first_context = NULL;
         SE_SHARED_SERVICES_OBJECT = NULL;
         SE_SHARED_GENERIC_DATA = NULL;
      }
#     endif
   } while( again );
}


   JSECALLSEQ( struct seContextParams * )
seGetContextParams(secontext se)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   seassert_is_context( call )

   return &(call->Global->Params);
}

/* ---------------------------------------------------------------------- */

/* The two basic operations, getting from, and putting to an
 * OBJECT/MEMBER pair. Here is the 'get' section.
 */


/* Several of these are virtual objects and can't be 'built'. In
 * the cases below that try to use them, for object member count,
 * have it have hardcoded for the ones it makes sense. In any case,
 * this routine should generate an error and return SE_NOWHERE.
 */
   hSEObject
seobjectTohSEObject(struct seCall * call,seobject origobj)
{
   hSEObject obj;

   HSEOBJECT_INIT_NULL(obj);

   seassert_is_object(origobj);

   if( IS_STOCK_OBJ(origobj) )
   {
      switch( STOCK_OBJ_NUM(origobj) )
      {
         default:
            SEASSERT( IS_STACK_INFO(origobj) );
            SEDBG(DebugPrintf(UNISTR("SE_STACK_INFO(X) is a virtual object.\n")));
            SEASSERT( obj == hSEObjectNull );
            break;

         case SE_SCOPE_NUM:
            SEDBG(DebugPrintf(UNISTR("SE_SCOPE is a virtual object.\n")));
            SEASSERT( obj == hSEObjectNull );
            break;

         case SE_GLOBAL_NUM:
            HSEOBJECT_BRUTE_ASSIGN(obj,CALL_GLOBAL(call));
            break;
         case SE_ARGS_NUM:
         {
#           if JSE_NAMED_PARAMS==1
            if( call->save.wrapper_named!=NULL )
            {
               HSEOBJECT_BRUTE_ASSIGN(obj,call->save.wrapper_named);
            }
            else
#           endif
            {
               wSEVar tmp = STACK_PUSH;
               SEVAR_INIT_UNORDERED_OBJECT(call,tmp,(sememcount)-1);

               HSEOBJECT_BRUTE_ASSIGN(obj,SEVAR_GET_OBJECT(tmp));

               if( CALL_INCALLBACK(call) )
               {
                  seobjNewMember(call,obj,SE_NO_VARNAME,CALL_CALLBACKPARAM(call),
                                 SE_DEFAULT,SE_NM_UPDATE);
               }
               else
               {
                  uint i;

                  for( i=0;i<CALL_TRUEARGS(call);i++ )
                  {
                     seobjNewMember(call,obj,PositiveSEStringTableEntry(i),CALL_PARAM(i),
                                    SE_DEFAULT,SE_NM_UPDATE);
                  }
               }
               STACK_POP; /* tmp */
            }
            break;
         }
         case SE_ACTIVATION_NUM:
            if( CALL_VAROBJ(call)==hSEObjectNull )
               callCreateVariableObject(call,NULL,0);

            HSEOBJECT_BRUTE_ASSIGN(obj,CALL_VAROBJ(call));
            if( obj==hSEObjectNull )
               HSEOBJECT_BRUTE_ASSIGN(obj,CALL_GLOBAL(call));

            /* prep as the variable object, defaults to the global
             * object if none, which is the ScriptEase rule (because
             * it makes the most sense ECMAScript-wise.)
             */
            break;


         /* ----------------------------------------------------------------------
          * The 'this' variable for the wrapper function.
          * ---------------------------------------------------------------------- */
         case SE_THIS_NUM:
            if ( CALL_INCALLBACK(call) )
               HSEOBJECT_BRUTE_ASSIGN(obj,CALL_CALLBACKTHIS(call));
            else if ( FRAME )
               HSEOBJECT_BRUTE_ASSIGN(obj,SEVAR_GET_OBJECT(CALL_THIS));
            else
               HSEOBJECT_BRUTE_ASSIGN(obj,CALL_GLOBAL(call));
            break;

         /* ----------------------------------------------------------------------
          * The currently executing function, or NULL=undefined
          * ---------------------------------------------------------------------- */
         case SE_SELF_NUM:
            SEASSERT( obj == hSEObjectNull );
            if ( FRAME )
               HSEOBJECT_BRUTE_ASSIGN(obj,SEVAR_GET_OBJECT(FUNCVAR));
            break;


         /* ----------------------------------------------------------------------
          * The global temp object, like SE_THIS and SE_GLOBAL, this is a real
          * object, so just point to it. Ditto for SE_WRAPPER_TEMP
          * ---------------------------------------------------------------------- */
         case SE_TEMP_NUM:
            HSEOBJECT_BRUTE_ASSIGN(obj,call->Global->global_temp);
            break;


         case SE_WRAPPER_TEMP_NUM:
            SEASSERT( obj == hSEObjectNull );
            HSEOBJECT_BRUTE_ASSIGN(obj,call->wrapper_temp);
            break;


         /* ----------------------------------------------------------------------
          * Defines is likewise a virtual object.
          * ---------------------------------------------------------------------- */
#        if JSE_DEFINE==1
            case SE_DEFINES_NUM:
               SEDBG(DebugPrintf(UNISTR("SE_DEFINES is a virtual object.\n")));
               SEASSERT( obj == hSEObjectNull );
               break;
#        endif

         /* ----------------------------------------------------------------------
          * SE_RETURN has only a few set slots.
          * ---------------------------------------------------------------------- */
         case SE_RETURN_NUM:
            SEDBG(DebugPrintf(UNISTR("SE_RETURN is a virtual object.\n")));
            SEASSERT( obj == hSEObjectNull );
            break;


         case SE_AT_EXIT_NUM:
            SEDBG(DebugPrintf(UNISTR("SE_AT_EXIT is a virtual object.\n")));
            SEASSERT( obj == hSEObjectNull );
            break;

#        if JSE_GETFILENAMELIST==1
         case SE_FILENAMES_NUM:
            SEDBG(DebugPrintf(UNISTR("SE_FILENAMES is a virtual object.\n")));
            SEASSERT( obj == hSEObjectNull );
            break;
#        endif

#        if SE_SHARED_OBJECTS==1
         case SE_SHARED_SERVICES_NUM:
            HSEOBJECT_BRUTE_ASSIGN(obj,SE_SHARED_SERVICES_OBJECT);
            break;
#        endif

         case SE_SERVICES_NUM:
            HSEOBJECT_BRUTE_ASSIGN(obj,call->Global->api_services);
            break;

         case SE_NOWHERE_NUM:
#           if defined(JSE_TRAP_NOWHERE) && JSE_TRAP_NOWHERE==1
               SEASSERT( False );
#           endif
            break;
      }
   }
   else
   {
      HSEOBJECT_BRUTE_ASSIGN(obj,origobj->data.obj);
   }

   return obj;
}

   static seVarName JSE_NEAR_CALL
to_sevarname(struct seCall *call,int type,t_sememdata memdata)
{
   if ( SE_STR_TYPE == type  ||  SE_STOCK_TYPE == type )
      return (seVarName)memdata;
   if ( SE_UNIMEM_TYPE == type )
      return CreateSEVarName(call,(seconstcharptr)memdata,CVN_USE_STRLEN,False);
   if ( SE_NUM_TYPE == type )
      return NumericSEStringTableEntry((sword32)(SE_POINTER_SINT)memdata);
   if ( SE_HIDDEN_TYPE == type )
      return CreateSEVarName(call,(seconstcharptr)memdata,CVN_USE_STRLEN,True);
   return (seVarName)NULL;
}

#define SEMEMCOUNT_FROM_MEMDATA(ptr) ((sememcount)(ptr))

   static void JSE_NEAR_CALL
se_scope_adjust(struct seCall *call,hSEObject *obj,int *type,t_sememdata *memdata)
{
   sebool remove_lock = (*type <= SE_HIDDEN_TYPE );
   seVarName name = to_sevarname(call,*type,*memdata);
   if ( (seVarName)NULL != name )
   {
      wSEVar tmp = STACK_PUSH;
      if ( NULL == secoreFindAnyVar(call,name,FAV_CREATE_REF) )
      {
         /* not found; use the SE_GLOBAL */
         HSEOBJECT_BRUTE_ASSIGN(*obj,CALL_GLOBAL(call));
      }
      else
      {
         /* have located variable to which this belongs - use it */
         SEASSERT( VReference==SEVAR_GET_TYPE(tmp) || VReferenceIndex==SEVAR_GET_TYPE(tmp) );
         HSEOBJECT_BRUTE_ASSIGN(*obj,tmp->data.ref_val.hBase);
         if ( VReferenceIndex==SEVAR_GET_TYPE(tmp) )
         {
            /* change type to be index */
            *type = SE_INDEX_TYPE;
            *memdata = (t_sememdata)(tmp->data.ref_val.reference);
         }
      }
      STACK_POP; /* tmp */
   }
   else
   {
      SEASSERT( *obj == hSEObjectNull );
      SEASSERT( False ); /* this type only valid with valid varnames */
   }
   if ( remove_lock )
      RemoveSEVarNameLock(name);
}

/* Type needed will be seTypeUndefined if whatever it is will
 * do. seTypeNull is illegal and asserted against.
 *
 * The boolean indicates if the member existed. If it is
 * False, the undefined value will always be set up in temp_get
 * Note that temp_get is initialized, from the start, so the
 * caller does not have to initialize temp_get.
 */
   static sebool JSE_NEAR_CALL
seGetMember(struct seCall *call,seobject origobj,int type,t_sememdata memdata,
            sedatatype type_needed,int flags,wSEVar temp_get)
{
   /* Any errors in both get and put should be trapped and
    * put in the error return. If the calling function returns,
    * it gets that error. It can junk the error by resetting
    * that error.
    */
   uword8 mustPrintError;
   sebool ret;
   hSEObject obj;
   wSEVar tmp;
   const struct seFunction *funcptr;
   seVarName name;
#  if SE_VAR_PARSE==1
      seobject parse_obj;     /* if seVarParse was used then this undoes the object lock before returning */
      sestring parse_string;
#  endif
   sebool byReference = ( 0 != (flags & GF_INTERNAL_REFERENCE) );
   void *data;
   struct seGlobal_ * global = call->Global;

   mustPrintError = call->mustPrintError;
   call->mustPrintError = FALSE;

   ret = False;
   HSEOBJECT_INIT_NULL(obj);       /* signal already gotten value; */

   SEVAR_INIT_UNDEFINED(temp_get);

   seassert_is_object(origobj);

   /* ----------------------------------------------------------------------
    * We do this in two parts. The first section translates the 'obj'
    * into a real object for a fallthru to the second section which
    * gets the member. If 'obj' is a virtual object, it instead does
    * the member lookup using the rules for that virtual object, and
    * sets 'obj' to NULL, indicating it has retrieved the value.
    * ----------------------------------------------------------------------
    */

   while( type == SE_STRUCT_TYPE )
   {
      type = ((struct seMemberDesc *)memdata)->type;
      memdata = ((struct seMemberDesc *)memdata)->memdata;
   }

#  if SE_VAR_PARSE==1
      if ( type == SE_COMPOUND_TYPE )
      {
         /* undo origobj and memdata (via seVarParse) into a new object and memdata */
         if ( !seVarParse(JSECONTEXT_FROM_CALL(call),origobj,(seconstcharptr)memdata,
                          &parse_obj,&parse_string,flags) )
         {
            SEASSERT( CALL_QUIT(call) );
            parse_obj = NULL;
            goto not_there;
         }
         origobj = parse_obj;
         type = SE_STR_TYPE;
         memdata = parse_string;
      }
      else
      {
         parse_obj = NULL;
      }
#  endif

   if( IS_STOCK_OBJ(origobj) )
   {
      if ( IS_STACK_INFO(origobj) )
      {
         /* NYI: would it be more efficient to just construct the
          * stack info object as an object? Cache it, then all of
          * these could be mapped to return the appropriate member
          * of the that object. We could also return ,SE_VALUE as
          * the object itself.
          */

         if( type==SE_INDEX_TYPE )
         {
            struct seCall *scall;
            rSEVar func;
            wSEVar fptr;
            hSEObject hvarobj;
            uword16 num_args;
            struct TryBlock *tries;
            hSEObject hfuncobj;
            hSEObject hCallScopeChain;
            hSEMembers mems;
            sememcount scope_chain_len;
            struct functionSave *save;
#           if JSE_MEMEXT_SECODES==1
               ulong iptr_offset;
#           else
               secode iptr;
#           endif
            uint depth,origdepth;

            /* NYI: For some reason on MSVC60, without the (long *) casts
             * the depth is always 0, I can't figure out why.
             */
            origdepth = depth = (uint)SESTACKINFO(origobj);
            SEASSERT( depth < SE_MAX_STACK_INFO_DEPTH );

            scall = call;

            callCreateVariableObject(call,NULL,depth);

         in_prev_call:
            save = &(scall->save);

#           define call scall
            func = FUNCVAR;
            fptr = FRAME;
#           undef call
            if( fptr==NULL )
            {
               if( scall->prev )
               {
                  scall = scall->prev;
                  goto in_prev_call;
               }

               /* Not found */
               goto not_there;
            }

            HSEOBJECT_BRUTE_ASSIGN(hvarobj,CALL_VAROBJ(scall));
            num_args = CALL_NUMARGS(scall);
            HSEOBJECT_BRUTE_ASSIGN(hCallScopeChain,scall->hScopeChain);
            scope_chain_len = SEOBJECT_GET(scall,hCallScopeChain,used);
#           if JSE_MEMEXT_SECODES==1
               iptr_offset = (ulong)(scall->save.iptr - scall->base);
#           else
               iptr = scall->save.iptr;
#           endif

            mems = SEOBJECT_GET(scall,hCallScopeChain,hsemembers);

            while( 0 < depth--  )
            {
               /* drop to the top of the next function scope chain, which is beyond the VNull for this one */
               do {
                  SEASSERT( scope_chain_len != 0 );
                  scope_chain_len--;
               } while ( VNull != SEVAR_GET_TYPE(SEMEMBERS_GET_sevar(scall,mems,scope_chain_len)) );

               save = save->prev;

#              if JSE_MEMEXT_SECODES==1
                  iptr_offset = (ulong)(save->iptr);
#              else
                  iptr = save->iptr;
#              endif

               num_args = save->num_args;
               HSEOBJECT_BRUTE_ASSIGN(hvarobj,save->hVariableObject);
               fptr = STACK_FROM_STACKPTR(save->frameptr);
               if( fptr==NULL )
               {
                  if( scall->prev==NULL )
                  {
                     goto not_there;
                  }
                  else
                  {
                     scall = scall->prev;
                     goto in_prev_call;
                  }
               }

               /* restore func from stack */
               func = fptr - (num_args + FUNC_OFFSET);
            }


            SEASSERT( SEVAR_GET_TYPE(func)==VObject );
            HSEOBJECT_BRUTE_ASSIGN(hfuncobj,SEVAR_GET_OBJECT(func));
            funcptr = SEOBJECT_GET_func(scall,hfuncobj);
            SEASSERT( funcptr!=NULL );

            switch( (uint)memdata )
            {
               case SE_SI_WRAPPER_INDEX:
                  SEVAR_INIT_BOOLEAN(temp_get,!FUNCTION_IS_LOCAL(funcptr));
                  break;

               case SE_SI_FUNCTION_INDEX:
                  SEVAR_COPY(temp_get,func);
                  break;

               case SE_SI_FUNCNAME_INDEX:
               {
                  SEVAR_INIT_STR(call,temp_get,
                                 sefunctionName(funcptr,call),SIS_CALC_SECHAR,SIS_CALC_SECHAR);
                  break;
               }

               case SE_SI_TRAPPED_INDEX:
                  if( !scall->mustPrintError )
                  {
                     SEVAR_INIT_BOOLEAN(temp_get,TRUE);
                  }
                  else
                  {
                     SEVAR_INIT_BOOLEAN(temp_get,FALSE);
                     for( tries = scall->tries; tries!=NULL; tries = tries->prev )
                     {
                        if ( !tries->incatch
                          && tries->Catch!=SERUN_ADDR_NONE
                          && ( global->call_func_mark==NULL || global->call_func_mark < tries->fptr )
                          && STACK_FROM_STACKPTR(tries->fptr) <= fptr )
                        {
                           /* found a trap */
                           SEVAR_INIT_BOOLEAN(temp_get,FALSE);
                           break;
                        }
                     }
                  }
                  break;

               case SE_SI_GLOBAL_INDEX:
#                 if JSE_MULTIPLE_GLOBAL==1
                     SEVAR_INIT_OBJECT(temp_get,
                                       funcptr->hglobal_object?funcptr->hglobal_object:
                                       CALL_GLOBAL(scall));
#                 else
                     SEVAR_INIT_OBJECT(temp_get,CALL_GLOBAL(scall));
#                 endif
                  break;

               case SE_SI_THIS_INDEX:
                  SEVAR_COPY(temp_get,(fptr-(THIS_OFFSET+num_args)));
                  break;

               case SE_SI_DATA_INDEX:
                  if( !FUNCTION_IS_LOCAL(funcptr) )
                  {
                     data = (Func_StaticLibrary & funcptr->flags)
                          ? (*(((struct LibraryFunction *)funcptr)->LibData.DataPtr))
                          : ((struct LibraryFunction *)funcptr)->LibData.Data;
                  }
                  else
                  {
                     data = NULL;
                  }
                  goto store_data_ptr;

               case SE_SI_FILENAME_INDEX:
                  if( FUNCTION_IS_LOCAL(funcptr) )
                  {
                     secode sptr;
                     secode base = LOCK_READ_SECODES(scall,(struct LocalFunction *)funcptr);
#                    if JSE_MEMEXT_SECODES==1
                        secode iptr = base + iptr_offset;
#                    else
                        SEASSERT( (iptr-((struct LocalFunction *)funcptr)->opcodes)>=0 );
                        SEASSERT( (uint)(iptr-((struct LocalFunction *)funcptr)->opcodes) \
                                < ((struct LocalFunction *)funcptr)->opcodesUsed );
#                    endif

                     for( sptr = base;sptr<iptr;sptr++ )
                     {
                        if ( seFilename == *sptr )
                        {
                            seconstcharptr filename =
                               GetSEStringTableEntry(call,SECODE_GET_ONLY(sptr+1,seVarName),NULL);
                            SEVAR_INIT_STR(call,temp_get,filename,SIS_CALC_SECHAR,SIS_CALC_SECHAR);
                        }
                        sptr += SECODESIZE_SECODEELEMS(global,*sptr);
                     }
                  }
                  break;

               case SE_SI_LINENUM_INDEX:
                  if( FUNCTION_IS_LOCAL(funcptr) )
                  {
                     secode sptr;
                     secode base = LOCK_READ_SECODES(scall,(struct LocalFunction *)funcptr);
#                    if JSE_MEMEXT_SECODES==1
                        secode iptr = base + iptr_offset;
#                    else
                        SEASSERT( (iptr-((struct LocalFunction *)funcptr)->opcodes)>=0 );
                        SEASSERT( (uint)(iptr-((struct LocalFunction *)funcptr)->opcodes) \
                                < ((struct LocalFunction *)funcptr)->opcodesUsed );
#                    endif

                     /* search from beginning for next line number, it must be there */
                     for( sptr = base;sptr<iptr;sptr++ )
                     {
                        if( /* seLineNumber == *sptr  || */ seContFunc == *sptr )
                        {
                           SEVAR_INIT_NUMBER(temp_get,
                                  JSE_FP_CAST_FROM_SLONG(SECODE_GET_ONLY(sptr+1,CONST_TYPE)));
                        }
                        sptr += SECODESIZE_SECODEELEMS(global,*sptr);
                     }
                  }
                  else
                  {
                     SEVAR_INIT_NUMBER(temp_get,jseZero);
                  }
                  break;
               case SE_SI_ACTIVATION_INDEX:
                  if( !FUNCTION_IS_LOCAL(funcptr) )
                  {
#                    if JSE_MULTIPLE_GLOBAL==1
                        SEVAR_INIT_OBJECT(temp_get,
                                          funcptr->hglobal_object?funcptr->hglobal_object:
                                          CALL_GLOBAL(scall));
#                    else
                        SEVAR_INIT_OBJECT(temp_get,CALL_GLOBAL(scall));
#                    endif
                  }
                  else
                  {
                     SEVAR_INIT_OBJECT(temp_get,hvarobj);
                  }
                  break;

               case SE_SI_SCOPECHAIN_INDEX:
                  if( FUNCTION_IS_LOCAL(funcptr) )
                  {
                     sememcount mem_index = 0;
                     hSEObject hTmp;

                     SEVAR_INIT_UNORDERED_OBJECT(call,temp_get,(sememcount)-1);
                     HSEOBJECT_BRUTE_ASSIGN(hTmp,SEVAR_GET_OBJECT(temp_get));

                     /* add objects on to the returned object with those items to be searched last placed
                      * as the first items in the returned object.
                      */
                     tmp = STACK_PUSH;
                     SEVAR_INIT_UNDEFINED(tmp);

                     SEASSERT( 0 < scope_chain_len );

                     /* the current global will be the last thing searched, and so add it first */
#                    if JSE_MULTIPLE_GLOBAL==1
                        SEVAR_INIT_OBJECT(tmp,
                                          funcptr->hglobal_object?funcptr->hglobal_object:
                                          CALL_GLOBAL(scall));
#                    else
                        SEVAR_INIT_OBJECT(tmp,CALL_GLOBAL(scall));
#                    endif
                     seobjCreateMemberCopy(scall,hTmp,PositiveSEStringTableEntry(mem_index),
                                           tmp,SE_DEFAULT);
                     mem_index++;

                     /* if the object function has a saved scope chain then add it next */
                     if( hSEObjectNull != func->data.object_val.hSavedScopeChain )
                     {
                        uint lookin;

                        mems = SEOBJECT_GET(scall,func->data.object_val.hSavedScopeChain,hsemembers);
                        for( lookin=0;lookin<SEOBJECT_GET(scall,func->data.object_val.hSavedScopeChain,used);lookin++ )
                        {
                           SEVAR_COPY(tmp,SEMEMBERS_GET_sevar(scall,mems,lookin));
                           seobjCreateMemberCopy(scall,hTmp,PositiveSEStringTableEntry(mem_index),
                                                 tmp,SE_DEFAULT);
                           mem_index++;
                        }
                     }

                     /* last (to be searched first) add the current items in the scope chain in the */
                     SEASSERT( 0 < scope_chain_len );
                     mems = SEOBJECT_GET(scall,hCallScopeChain,hsemembers);
                     {
                        sememcount func_scope_start;

                        for ( func_scope_start = scope_chain_len; ; func_scope_start-- )
                        {
                           SEASSERT( 0 < func_scope_start );
                           if ( VNull == SEVAR_GET_TYPE(SEMEMBERS_GET_sevar(scall,mems,func_scope_start-1)) )
                              break;
                        }
                        while ( func_scope_start++ < scope_chain_len )
                        {
                           mems = SEOBJECT_GET(scall,hCallScopeChain,hsemembers);
                           SEVAR_COPY(tmp,SEMEMBERS_GET_sevar(scall,mems,func_scope_start-1));
                           seobjCreateMemberCopy(scall,hTmp,PositiveSEStringTableEntry(mem_index),tmp,SE_DEFAULT);
                           mem_index++;
                        }
                     }
                     STACK_POP; /* tmp */
                  }
                  break;

                  case SE_SI_DEPTH_INDEX:
                  {
                     struct functionSave *save;


                     depth = 0;
                     save = &(call->save);
                     scall = call;

                     for( ; ; )
                     {
                        if( save->prev!=NULL )
                        {
                           save = save->prev;
                           depth++;
                           continue;
                        }
                        if( scall->prev!=NULL )
                        {
                           scall = scall->prev;
                           save = &(scall->save);
                           continue;
                        }
                        break;
                     }
                     SEVAR_INIT_NUMBER(temp_get,JSE_FP_CAST_FROM_SLONG(depth-origdepth));
                     break;
                  }
            } /* switch */
         }
         /* else all other members considered to be undefined */
      }
      else
      {
         switch( STOCK_OBJ_NUM(origobj) )
         {
            /* ----------------------------------------------------------------------
             * The global object, just replace it with the actual global object.
             * ---------------------------------------------------------------------- */
            case SE_GLOBAL_NUM:
               HSEOBJECT_BRUTE_ASSIGN(obj,CALL_GLOBAL(call));
               break;


            /* ----------------------------------------------------------------------
             * The arguments virtual object, translate the virtual reference into
             * the correct 'get'.
             * ---------------------------------------------------------------------- */
            case SE_ARGS_NUM:

#              if JSE_NAMED_PARAMS==1
               if( call->save.wrapper_named!=NULL )
               {
                  HSEOBJECT_BRUTE_ASSIGN(obj,call->save.wrapper_named);
               }
               else
#              endif
               {
                  /* It's necessary to allow references when passing variables
                   * by reference, so check for that as well.
                   */
                  if ( byReference
#                   if JSE_PASSBYREF==1
                    && ( CALL_INCALLBACK(call) || !FUNCTION_PASSBYREF(call->funcptr) )
#                   endif
                     )
                  {
                     SEDBG(DebugPrintf(UNISTR("SE_ARGS is a virtual object unless passing by reference.\n")));
                     SEASSERT( obj == hSEObjectNull );
                     break;
                  }

                  if( type==SE_INDEX_TYPE || type==SE_NUM_TYPE )
                  {
                     /* treat them the same, for arguments object,
                      * SE_ARGS,SE_INDEX(0)==SE_ARGS,SE_NUM(0)==the 0th argument.
                      */

                     if( CALL_INCALLBACK(call) )
                     {
                        if( 0 < SEMEMCOUNT_FROM_MEMDATA(memdata) )
                        {
                           SEASSERT( SE_TYPE_UNDEFINED == SEVAR_GET_TYPE(temp_get) );
                           /*SEVAR_INIT_UNDEFINED(temp_get);*/
                           ret = FALSE;
                        }
                        else
                        {
                           SEVAR_COPY(temp_get,CALL_CALLBACKPARAM(call));
                           ret = TRUE;
                        }
                     }
                     else
                     {
                        if( SEMEMCOUNT_FROM_MEMDATA(memdata) < CALL_TRUEARGS(call) )
                        {
                           SEVAR_COPY(temp_get,CALL_PARAM(SEMEMCOUNT_FROM_MEMDATA(memdata)));
                           ret = True;
                        }
                        else
                        {
                           SEASSERT( SE_TYPE_UNDEFINED == SEVAR_GET_TYPE(temp_get) );
                           /*SEVAR_INIT_UNDEFINED(temp_get);*/
                           ret = FALSE;
                        }
                     }
                  }
                  else if( type <= SE_STR_TYPE )
                  {
                     /* The default is undefined if this parameter does not exist.
                      * That can be because no parameters were passed by name, or
                      * because this one in particular wasn't. Since named params
                      * are handled above (if wrapper_named!=NULL), this always does
                      * undefined.
                      */
                     SEASSERT( SE_TYPE_UNDEFINED == SEVAR_GET_TYPE(temp_get) );
                     /*SEVAR_INIT_UNDEFINED(temp_get);*/
                  }
                  else
                  {
                     /* virtual object, cannot get it so return the already-setup
                      * undefined value. Assert for debug purposes. */

                     SEASSERT( False );
                  }
               }
               break;


            /* ----------------------------------------------------------------------
             * The activation object for the caller. As a NYI:, don't actually
             * build the object, just get its member, unless referring to the
             * object itself. For now low priority, since getting the activation
             * object is rarely done.
             * ---------------------------------------------------------------------- */
            case SE_ACTIVATION_NUM:
               if( byReference )
               {
                  SEDBG(DebugPrintf(UNISTR("SE_ACTIVATION is a virtual object.\n")));
                  SEASSERT( obj == hSEObjectNull );
                  break;
               }

               if( CALL_VAROBJ(call)==hSEObjectNull )
                  callCreateVariableObject(call,NULL,0);

               HSEOBJECT_BRUTE_ASSIGN(obj,CALL_VAROBJ(call));
               if( obj==hSEObjectNull )
                  HSEOBJECT_BRUTE_ASSIGN(obj,CALL_GLOBAL(call));

               /* prep as the variable object, defaults to the global
                * object if none, which is the ScriptEase rule (because
                * it makes the most sense ECMAScript-wise.)
                */
               break;


            /* ----------------------------------------------------------------------
             * The 'this' variable for the wrapper function.
             * ---------------------------------------------------------------------- */
            case SE_THIS_NUM:
               if ( CALL_INCALLBACK(call) )
                  HSEOBJECT_BRUTE_ASSIGN(obj,CALL_CALLBACKTHIS(call));
               else if ( FRAME )
                  HSEOBJECT_BRUTE_ASSIGN(obj,SEVAR_GET_OBJECT(CALL_THIS));
               else
                  HSEOBJECT_BRUTE_ASSIGN(obj,CALL_GLOBAL(call));
               break;


            /* ----------------------------------------------------------------------
             * The currently executing function, or NULL=undefined
             * ---------------------------------------------------------------------- */
            case SE_SELF_NUM:
               SEASSERT( obj == hSEObjectNull );
               if ( FRAME )
                  HSEOBJECT_BRUTE_ASSIGN(obj,SEVAR_GET_OBJECT(FUNCVAR));
               break;


            /* ----------------------------------------------------------------------
             * locate in the scope chain
             * ---------------------------------------------------------------------- */
            case SE_SCOPE_NUM:
               se_scope_adjust(call,&obj,&type,&memdata);
               break;

            /* ----------------------------------------------------------------------
             * The global temp object, like SE_THIS and SE_GLOBAL, this is a real
             * object, so just point to it. Ditto for SE_WRAPPER_TEMP
             * ---------------------------------------------------------------------- */
            case SE_TEMP_NUM:
               HSEOBJECT_BRUTE_ASSIGN(obj,global->global_temp);
               break;


            case SE_WRAPPER_TEMP_NUM:
               /* We only build such an object if someone is using it.
                * For most wrappers, which never use it, nothing is
                * built. Since it is not built, nothing has been put to
                * it, so any reads return the undefined value, and leave
                * ret as 'False'==didn't exist.
                */
               SEASSERT( obj == hSEObjectNull );
               HSEOBJECT_BRUTE_ASSIGN(obj,call->wrapper_temp);

               break;


            /* ----------------------------------------------------------------------
             * Defines is likewise a virtual object.
             * ---------------------------------------------------------------------- */
#           if JSE_DEFINE==1
            case SE_DEFINES_NUM:
            {
               secharptr define;

               if( byReference )
               {
                  SEDBG(DebugPrintf(UNISTR("SE_DEFINES is a virtual object.\n")));
                  SEASSERT( obj == hSEObjectNull );
                  break;
               }

               SEASSERT( obj == hSEObjectNull );       /* in any case, virtual object, found the value */
               if( type==SE_INDEX_TYPE )
               {
                  sememcount num = SEMEMCOUNT_FROM_MEMDATA(memdata);

                  /* find the num'th define */
                  if( num<call->Definitions->linksUsed )
                  {
                     ret = True;
                     define = call->Definitions->links[num].Replace;
                     SEVAR_INIT_STR(call,temp_get,define,SIS_CALC_SECHAR,SIS_CALC_SECHAR);
                  }
                  /* else that numbered slot does not exist */
               }
               else if( type!=SE_VALUE_TYPE )
               {
                  seconstcharptr name_txt;
                  name = to_sevarname(call,type,memdata);
                  name_txt = GetSEStringTableEntry(call,name,NULL);

                  if( (define = (secharptr)defineFindReplacement(call->Definitions,name_txt))!=NULL )
                  {
                     ret = True;
                     SEVAR_INIT_STR(call,temp_get,define,SIS_CALC_SECHAR,SIS_CALC_SECHAR);
                  }

                  DONE_SEVARNAME(call,type,name);
               }
               /* else SE_VALUE or SE_OBJECT_DATA, no real object, so leave it undefined */
               break;
            }
#           endif /* JSE_DEFINE==1 */


            /* ----------------------------------------------------------------------
             * SE_RETURN has only a few set slots.
             * ---------------------------------------------------------------------- */
            case SE_RETURN_NUM:
               if( byReference )
               {
                  SEDBG(DebugPrintf(UNISTR("SE_RETURN is a virtual object.\n")));
                  SEASSERT( obj == hSEObjectNull );
                  break;
               }

               if( type==SE_VALUE_TYPE )
               {
                  SEVAR_COPY(temp_get,&(call->return_var));
                  ret = True;
               }
               else if( type==SE_INDEX_TYPE )
               {
                  switch( (int)(SE_POINTER_SINT)memdata )
                  {
                     case SE_ERROR_INDEX:
                        ret = True;
                        SEVAR_INIT_BOOLEAN(temp_get,call->state==StateError);
                        break;
                     case SE_EXIT_INDEX:
                        ret = True;
                        SEVAR_INIT_BOOLEAN(temp_get,call->state==StateExit);
                        break;
                     case SE_YIELD_INDEX:
                        ret = True;
                        SEVAR_INIT_BOOLEAN(temp_get,(call->state & StateYield));
                        break;
                     case SE_SUSPEND_INDEX:
                        ret = True;
                        SEVAR_INIT_BOOLEAN(temp_get,0 != (call->state & StateSuspend));
                        break;
                  }
               }
               break;


            case SE_AT_EXIT_NUM:
               HSEOBJECT_BRUTE_ASSIGN(obj,call->atexit_functions);
               break;


#           if JSE_GETFILENAMELIST==1
            case SE_FILENAMES_NUM:
               if( byReference )
               {
                  SEDBG(DebugPrintf(UNISTR("SE_FILENAMES is a virtual object.\n")));
                  SEASSERT( obj == hSEObjectNull );
                  break;
               }

               /* Can only put by name. */
               if( type==SE_INDEX_TYPE || type==SE_NUM_TYPE )
               {
                  sememcount index = SEMEMCOUNT_FROM_MEMDATA(memdata);


                  if( global->FileNames.count>index )
                  {
                     SEVAR_INIT_STR(call,temp_get,global->FileNames.list[index],\
                                    SIS_CALC_SECHAR,SIS_CALC_SECHAR);
                  }
                  /* else return the default undefined */
               }

               break;
#           endif

#           if SE_SHARED_OBJECTS==1
            case SE_SHARED_SERVICES_NUM:
#           endif
            case SE_SERVICES_NUM:
               if( type==SE_VALUE_TYPE )
               {
                  data =
#                 if SE_SHARED_OBJECTS==1
                     STOCK_OBJ_NUM(origobj) == SE_SHARED_SERVICES_NUM ? SE_SHARED_GENERIC_DATA :
#                 endif
                     global->GenericData;
                  if ( type_needed == VStorage )
                  {
                     SEVAR_INIT_STORAGE_PTR(temp_get,data);
                  }
                  else
                  {
                     /* must preserve 32 bits even on min-mem systems */
                     SEVAR_INIT_SLONG(temp_get,(SE_POINTER_UINT)data);
                  }
               }
               else
               {
                  hSEObject *obj_ptr =
#                 if SE_SHARED_OBJECTS==1
                     STOCK_OBJ_NUM(origobj)==SE_SHARED_SERVICES_NUM ?  &SE_SHARED_SERVICES_OBJECT :
#                 endif
                     &(global->api_services);
                  if( *obj_ptr == hSEObjectNull )
                  {
                     HSEOBJECT_BRUTE_ASSIGN(*obj_ptr,seobj_new(call,0));
                  }
                  HSEOBJECT_BRUTE_ASSIGN(obj,*obj_ptr);
               }

               break;

            case SE_NOWHERE_NUM:
#              if defined(JSE_TRAP_NOWHERE) && JSE_TRAP_NOWHERE==1
                  SEASSERT( False );
#              endif
               break;
         }
      }
   }
   else
   {
      HSEOBJECT_BRUTE_ASSIGN(obj,origobj->data.obj);
   }

   not_there:
   if( obj != hSEObjectNull )
   {
      switch( type )
      {
         case SE_UNIMEM_TYPE:
         case SE_HIDDEN_TYPE:
         case SE_NUM_TYPE:
         case SE_STR_TYPE:
         case SE_STOCK_TYPE:
         {
            name = to_sevarname(call,type,memdata);

            if( byReference )
            {
               /* following calldyna would have caused a GC */
               ALWAYS_COLLECT(call)
               SEVAR_INIT_REFERENCE(temp_get,obj,name);
               ret = TRUE;
            }
            else
            {
               wSEVar tmpobj = STACK_PUSH;

#              if JSE_DYNAMIC_CALLBACKS==1
               ret = TRUE;
               SEVAR_INIT_UNDEFINED(tmpobj);
               /* If the object says it does not have the property,
                * believe it. Return FALSE with the undefined value.
                */
               if( (flags&SE_GF_NOCALLBACKS)==0
                && SEOBJ_IS_DYNAMIC_PROP(call,obj,hasProp)
                && !IS_HIDDEN_PROP(name) )
               {
                  if( seobjCallDynamicProperty(call,obj,SE_HASPROP_CALLBACK,name,NULL,tmpobj) )
                  {
                     SEASSERT( VNumber == SEVAR_GET_TYPE(tmpobj) );
                     if ( HP_HASNOT == SEVAR_GET_SLONG(tmpobj) )
                     {
                        ret = FALSE;
                        SEVAR_INIT_UNDEFINED(temp_get);
                     }
                     else
                     {
                        SEASSERT( HP_HAS == SEVAR_GET_SLONG(tmpobj) );
                     }
                  }
                  else
                  {
                     if ( VNumber == SEVAR_GET_TYPE(tmpobj) )
                     {
                        if ( HP_DIRECTCHECK == SEVAR_GET_SLONG(tmpobj) )
                        {
                           flags |= SE_GF_NOCALLBACKS;
                        }
                        else
                        {
                           SEASSERT( HP_CHECK == SEVAR_GET_SLONG(tmpobj) );
                        }
                     }
                  }
               }
               ELSE_ALWAYS_COLLECT(call)

               if( ret )
#              else
                  /* above calldyna would have caused GC */
                  ALWAYS_COLLECT(call)
#              endif
               {
                  SEVAR_INIT_OBJECT(tmpobj,obj);
                  ret = sevarGetValue(call,tmpobj,name,temp_get,flags);
               }

               STACK_POP;
            }

            DONE_SEVARNAME(call,type,name);
            break;
         }

         case SE_INDEX_TYPE:
         {
            sememcount index = SEMEMCOUNT_FROM_MEMDATA(memdata);

#           if JSE_DYNAMIC_CALLBACKS!=0
            sebool dynamic = FALSE;

            if( !byReference  &&  SEOBJ_IS_DYNAMIC_PROP(call,obj,getByIndex) )
            {
               wSEVar w_lhs = STACK_PUSH;
               SEVAR_INIT_UNDEFINED(w_lhs);
               if( seobjCallDynamicProperty(call,obj,
                                            SE_GETBYINDEX_CALLBACK,
                                            (seVarName)(sememcount)index,NULL,
                                            w_lhs) )
               {
                  dynamic = TRUE;
                  SEVAR_COPY(temp_get,w_lhs);
               }
               STACK_POP;
            }
            ELSE_ALWAYS_COLLECT(call)

            if( !dynamic )
#           else
               /* above calldyna would have caused GC */
               ALWAYS_COLLECT(call)
#           endif
            {
               if( SEOBJECT_GET(call,obj,used)<=index )
               {
                  ret = FALSE;
               }
               else
               {
                  if( byReference )
                  {
                     hSEMembers mems = SEOBJECT_GET(call,obj,hsemembers);
                     name = SEMEMBERS_GET(call,mems,index,name);

                     SEVAR_INIT_REFERENCE(temp_get,obj,name);
                  }
                  else
                  {
                     seobjGetIndexMember(call,obj,index,temp_get);
                  }
                  ret = TRUE;
               }
            }
            break;
         }

         case SE_VALUE_TYPE:
            if( byReference )
            {
               SEDBG(DebugPrintf(UNISTR("Cannot generate reference to an object, only object members.\n")));
               ret = FALSE;
            }
            else
            {
               SEVAR_INIT_OBJECT(temp_get,obj);
            }
            break;

#        if JSE_SAVE_FUNCTION_TEXT==1
         case SE_FUNCTIONTEXT_TYPE:
         {
            const struct seFunction *func;

            SEVAR_INIT_OBJECT(temp_get,obj);
            func = sevarGetFunction(call,temp_get);
            if( func )
            {
               sefunctionTextAsVariable(func,call,0);
               SEVAR_COPY(temp_get,STACK0);
               STACK_POP;
            }
            else
            {
               SEVAR_INIT_UNDEFINED(temp_get);
            }
            break;
         }
#        endif

#        if JSE_MULTIPLE_GLOBAL==1
         case SE_FUNCTIONGLOBAL_TYPE:
         {
            const struct seFunction *func;

            SEVAR_INIT_OBJECT(temp_get,obj);
            func = sevarGetFunction(call,temp_get);
            if( NULL == func  ||  hSEObjectNull == func->hglobal_object )
            {
               SEVAR_INIT_NULL(temp_get);
            }
            else
            {
               SEVAR_INIT_OBJECT(temp_get,func->hglobal_object);
            }
            break;
         }
#        endif

         case SE_LIBDATA_TYPE:
            funcptr = SEOBJECT_GET_func(call,obj);
            if( NULL!=funcptr && !FUNCTION_IS_LOCAL(funcptr) )
            {
               const struct LibraryFunction *func = (const struct LibraryFunction *)funcptr;

               data = (Func_StaticLibrary & func->function.flags)
                  ? *(func->LibData.DataPtr)
                  : func->LibData.Data;
            }
            else
            {
               data = NULL;
            }
            store_data_ptr:
            if ( type_needed == VStorage )
            {
               SEVAR_INIT_STORAGE_PTR(temp_get,data);
            }
            else
            {
               SEVAR_INIT_NUMBER(temp_get,JSE_FP_CAST_FROM_SLONG((uword32)(SE_POINTER_UINT)data));
            }
            break;

         default:
            SEASSERT( False );
      }
   }
   /* else was a 'special' object and we did the fetch above. */

   if( !byReference )
   {
      SEVAR_DEREFERENCE(call,temp_get);
   }
   else
   {
      SEASSERT( SEVAR_GET_TYPE(temp_get)==VUndefined || SEVAR_GET_TYPE(temp_get)>=VReference );
   }

   /* Now, convert the value if necessary. */
   if( !byReference  &&  type_needed!=VUndefined )
   {
      jseVarType type_got = SEVAR_GET_TYPE(temp_get);
      if ( type_got == VShortString ) type_got = VString;
      if ( type_needed != type_got )
      {
         switch( type_needed )
         {
            case SE_TYPE_BOOLEAN:
               sevarConvert(call,temp_get,SE_TOBOOLEAN);
               break;
            case SE_TYPE_NUMBER:
               sevarConvert(call,temp_get,SE_TONUMBER);
               break;
            case SE_TYPE_STRING:
               sevarConvert(call,temp_get,SE_TOSTRING);
               break;
            case SE_TYPE_OBJECT:
               /* NYI: not sure. I think we want the error
                * so that SE_NOWHERE is returned and an
                * error is set up in the context.
                */
               if ( (0 != (flags & SE_GF_UNDEF_OBJ_OK))
                 && ( SEVAR_GET_TYPE(temp_get)==VUndefined || SEVAR_GET_TYPE(temp_get)==VNull ) )
               {
                  /* flag says not to return error; so just leave it as undefined or NULL  */
               }
               else
               {
                  sevarConvert(call,temp_get,SE_TOOBJECT);
               }
               break;
            case VStorage:
               /* any type that is not already a pointer is converted to NULL, because conversion
                * from non-pointer to pointer would be too dangerous.
                */
               SEVAR_INIT_STORAGE_PTR(temp_get,NULL);
               break;
            default:
               SEASSERT( False );
         }

         SEASSERT( SEVAR_GET_TYPE(temp_get)==type_needed \
              || (SEVAR_GET_TYPE(temp_get)==VShortString && type_needed==VString)
              || (0 != (flags & SE_GF_UNDEF_OBJ_OK))
              || !CALL_NORMAL(call) );
      }
   }

#  if SE_VAR_PARSE==1
      if ( NULL != parse_obj )
      {
         seFreeObject(JSECONTEXT_FROM_CALL(call),parse_obj);
         seFreeInternalString(JSECONTEXT_FROM_CALL(call),parse_string);
      }
#  endif

   call->mustPrintError = mustPrintError;

   return ret;
}


/* Return 'True' if new member created.
 *
 * Put the value in temp_put into the given object/member.
 */
   static sebool JSE_NEAR_CALL
sePutMember(struct seCall *call,seobject origobj,int type,t_sememdata memdata,int flags,rSEVar temp_put)
{
   /* Any errors in both get and put should be trapped and
    * put in the error return. If the calling function returns,
    * it gets that error. It can junk the error by resetting
    * that error.
    */
   uword8 mustPrintError;
   sebool ret;
   hSEObject obj;
   wSEVar tmp;
   seVarName name;
#  if SE_VAR_PARSE==1
      seobject parse_obj;     /* if seVarParse was used then this undoes the object lock before returning */
      sestring parse_string;
#  endif
   struct seGlobal_ * global = call->Global;

   mustPrintError = call->mustPrintError;
   call->mustPrintError = FALSE;

   ret = False;
   HSEOBJECT_INIT_NULL(obj);
   tmp = STACK_PUSH;

   /* Move it because many places in this code can convert, and we
    * may not want to convert the original
    */
   SEVAR_COPY(tmp,temp_put);

   seassert_is_object(origobj);

   /* ----------------------------------------------------------------------
    * We do this in two parts. The first section translates the 'obj'
    * into a real object for a fallthru to the second section which
    * puts the member. If 'obj' is a virtual object, it instead does
    * the member assignment using the rules for that virtual object, and
    * sets 'obj' to NULL, indicating it has put the value.
    * ----------------------------------------------------------------------
    */

   while( type == SE_STRUCT_TYPE )
   {
      type = ((struct seMemberDesc *)memdata)->type;
      memdata = ((struct seMemberDesc *)memdata)->memdata;
   }

#  if SE_VAR_PARSE==1
      if ( type == SE_COMPOUND_TYPE )
      {
         /* undo origobj and memdata (via seVarParse) into a new object and memdata */
         if ( !seVarParse(JSECONTEXT_FROM_CALL(call),origobj,(seconstcharptr)memdata,
                          &parse_obj,&parse_string,flags) )
         {
            SEASSERT( CALL_QUIT(call) );
            STACK_POP; /* tmp */
            call->mustPrintError = mustPrintError;
            return False;
         }
         origobj = parse_obj;
         type = SE_STR_TYPE;
         memdata = parse_string;
      }
      else
      {
         parse_obj = NULL;
      }
#  endif

   call->sePutMemberDepth_check_hidden++;

   if( IS_STOCK_OBJ(origobj) )
   {
      switch( STOCK_OBJ_NUM(origobj) )
      {
         default:
            SEASSERT( IS_STACK_INFO(origobj) );
            SEDBG(DebugPrintf(UNISTR("SE_STACK_INFO() is read-only.\n")));
            break;

         /* ----------------------------------------------------------------------
          * The global object, just replace it with the actual global object.
          * ---------------------------------------------------------------------- */
         case SE_GLOBAL_NUM:
            if( type==SE_VALUE_TYPE )
            {
               sevarConvert(call,tmp,SE_TOOBJECT);
               if( SEVAR_GET_TYPE(tmp)==SE_TYPE_OBJECT )
               {
                  if ( CALL_VAROBJ(call) == CALL_GLOBAL(call) )
                     HSEOBJECT_ASSIGN(CALL_VAROBJ(call),SEVAR_GET_OBJECT(tmp));
                  HSEOBJECT_ASSIGN(CALL_GLOBAL(call),SEVAR_GET_OBJECT(tmp));
               }
               FLUSH_PROTOTYPE_CACHE(call);
            }
            else
            {
               HSEOBJECT_ASSIGN(obj,CALL_GLOBAL(call));
            }
            break;


         /* ----------------------------------------------------------------------
          * The arguments virtual object, translate the virtual reference into
          * the correct 'get'.
          * ---------------------------------------------------------------------- */
         case SE_ARGS_NUM:
#           if JSE_NAMED_PARAMS==1
            if( call->save.wrapper_named!=NULL )
            {
               HSEOBJECT_BRUTE_ASSIGN(obj,call->save.wrapper_named);
            }
            else
#           endif
            if( type==SE_INDEX_TYPE || type==SE_NUM_TYPE )
            {
               /* treat them the same, for arguments object,
                * SE_ARGS,SE_INDEX(0)==SE_ARGS,SE_NUM(0)==the 0th argument.
                */

               /* We can't just use SEVAR_COPY, because if we are passing
                * by reference then we need to modify the original.
                */
               SEVAR_DO_PUT(call,CALL_PARAM(SEMEMCOUNT_FROM_MEMDATA(memdata)),tmp);
            }
            else if( type==SE_VALUE_TYPE )
            {
               /* virtual object, cannot put to it so return the already-setup
                * undefined value. Assert for debug purposes. */
               SEASSERT( False );
            }
            break;


         /* ----------------------------------------------------------------------
          * The activation object for the caller. As a NYI:, don't actually
          * build the object, just get its member, unless referring to the
          * object itself. For now low priority, since getting the activation
          * object is rarely done.
          * ---------------------------------------------------------------------- */
         case SE_ACTIVATION_NUM:
            if( CALL_VAROBJ(call)==hSEObjectNull )
               callCreateVariableObject(call,NULL,0);

            HSEOBJECT_BRUTE_ASSIGN(obj,CALL_VAROBJ(call));
            if( obj==hSEObjectNull )
               HSEOBJECT_BRUTE_ASSIGN(obj,CALL_GLOBAL(call));

            /* prep as the variable object, defaults to the global
             * object if none, which is the ScriptEase rule (because
             * it makes the most sense ECMAScript-wise.)
             */
            break;


         /* ----------------------------------------------------------------------
          * The 'this' variable for the wrapper function.
          * ---------------------------------------------------------------------- */
         case SE_THIS_NUM:
            if ( CALL_INCALLBACK(call) )
               HSEOBJECT_BRUTE_ASSIGN(obj,CALL_CALLBACKTHIS(call));
            else if ( FRAME )
               HSEOBJECT_BRUTE_ASSIGN(obj,SEVAR_GET_OBJECT(CALL_THIS));
            else
               HSEOBJECT_BRUTE_ASSIGN(obj,CALL_GLOBAL(call));
            break;


         case SE_SELF_NUM:
            if( type==SE_VALUE_TYPE )
            {
               /* Currently executing function is read-only, so ignore attempts
                * to write to the object itself.
                */
               SEDBG(DebugPrintf(UNISTR("SE_SELF is read-only.\n")));
            }
            else
            {
               if ( FRAME )
                  HSEOBJECT_BRUTE_ASSIGN(obj,SEVAR_GET_OBJECT(FUNCVAR));
            }
            break;

         /* ----------------------------------------------------------------------
          * locate in the scope chain
          * ---------------------------------------------------------------------- */
         case SE_SCOPE_NUM:
            se_scope_adjust(call,&obj,&type,&memdata);
            break;

         /* ----------------------------------------------------------------------
          * The global temp object, like SE_THIS and SE_GLOBAL, this is a real
          * object, so just point to it. Ditto for SE_WRAPPER_TEMP
          * ---------------------------------------------------------------------- */
         case SE_TEMP_NUM:
            HSEOBJECT_BRUTE_ASSIGN(obj,global->global_temp);
            break;


         case SE_WRAPPER_TEMP_NUM:
            /* We only build such an object if someone is using it.
             * For most wrappers, which never use it, nothing is
             * built.
             *
             * It is ordered so temps can be by name and found
             * quickly.
             */
            if( call->wrapper_temp==hSEObjectNull )
               HSEOBJECT_BRUTE_ASSIGN(call->wrapper_temp,seobj_new(call,0));

            HSEOBJECT_BRUTE_ASSIGN(obj,call->wrapper_temp);
            break;


         /* ----------------------------------------------------------------------
          * Defines is likewise a virtual object.
          * ---------------------------------------------------------------------- */
#        if JSE_DEFINE==1
         case SE_DEFINES_NUM:
         {
            seconstcharptr Data;
            sememcount Len, byteLen;

            sevarConvert(call,tmp,SE_TOSTRING);
            Data = sevarGetStr(call,tmp,&Len,&byteLen);

            if( type==SE_INDEX_TYPE )
            {
               sememcount num = SEMEMCOUNT_FROM_MEMDATA(memdata);

               /* find the num'th define */
               if( num<call->Definitions->linksUsed )
               {
                  secharptr newstr;

                  newstr = secoreStrndup(call,Data,Len);
                  if( newstr!=NULL )
                  {
                     secoreFree(call,call->Definitions->links[num].Replace);
                     call->Definitions->links[num].Replace = newstr;
                  }
               }
               /* else that numbered slot does not exist */
            }
            else if( type!=SE_VALUE_TYPE )
            {
               uint defnum;
               struct Define *defs;
               seconstcharptr name_txt;
               sestringLenType name_txt_len;

               name = to_sevarname(call,type,memdata);
               name_txt = GetSEStringTableEntry(call,name,&name_txt_len);

               defs = call->Definitions;
               if( (defnum = defineFindReplacementNumber(&defs,name_txt))!=-1 )
               {
                  secharptr newstr;

                  newstr = secoreStrndup(call,Data,Len);
                  if( newstr!=NULL )
                  {
                     secoreFree(call,defs->links[defnum].Replace);
                     defs->links[defnum].Replace = newstr;
                  }
               }
               else
               {
                  /* creating new name */
                  ret = True;
                  defineAddLen(call,call->Definitions,name_txt,name_txt_len,Data,Len);
               }

               DONE_SEVARNAME(call,type,name);
            }
            /* else SE_VALUE, no real object, so leave it undefined */
            break;
         }
#        endif /* JSE_DEFINE==1 */

         /* ----------------------------------------------------------------------
          * SE_RETURN has only a few set slots.
          * ---------------------------------------------------------------------- */
         case SE_RETURN_NUM:
            if( type==SE_VALUE_TYPE )
            {
               /* Only write the value if currently a normal state.
                * Once the state transitions to some non-normal
                * state (i.e. an error), the error-lock-in which
                * is described in the manual kicks in.  The exception
                * is if we're in a suspend or yield then this is how the
                * return value is set for when the suspend is released.
                */
               if ( 0 == (call->state & ~(StateSuspend|StateYield|StateSorYInWrapper)) )
               {
                  SEVAR_COPY(&(call->return_var),tmp);
               }
            }
            else
            {
               uint their_flag = (uint)(SE_POINTER_SINT)memdata;
               if ( their_flag < 4 )
               {
                  uword8 state = (uword8)(1 << their_flag);
#                 ifndef SE_RELEASE_BUILD
                     switch( their_flag )
                     {
                        case SE_ERROR_INDEX:    SEASSERT( state == StateError );       break;
                        case SE_EXIT_INDEX:     SEASSERT( state == StateExit );        break;
                        case SE_YIELD_INDEX:    SEASSERT( state == StateYield );       break;
                        case SE_SUSPEND_INDEX:  SEASSERT( state == StateSuspend );     break;
                        default:                SEASSERT( False );                     break;
                     }
#                 endif
                  sevarConvert(call,tmp,SE_TOBOOLEAN);
                  SEASSERT( SEVAR_GET_TYPE(tmp)==VBoolean );
                  if ( tmp->data.bool_val )
                  {
                     if ( 0 != ((call->state = state) & (StateSuspend|StateYield)) )
                     {
                        /* if code is in a wrapper function then also set StateSorYInWrapper */
                        if ( call->funcptr
                          && !FUNCTION_IS_LOCAL(call->funcptr)
                          && !CALL_INCALLBACK(call) )
                        {
                           call->suspend_restore_loc = FRAME-(1+call->save.num_args);
                           /* also set flag to know we were in a wrapper function */
                           call->state |= StateSorYInWrapper;
                        }

                     }
                  }
                  else
                  {
                     if( (call->state & ~StateSorYInWrapper) == state )
                     {
                        if ( 0 != (call->state & StateSorYInWrapper) )
                        {
                           SEASSERT( call->suspend_restore_loc != NULL );

                           /* Copy the return var to the place on the stack where
                            * the suspending wrapper function put its return value.
                            * This lets the API user change the return value before
                            * un-suspending the context
                            */
                           SEVAR_COPY(call->suspend_restore_loc,&(call->return_var));
                        }
                        call->state = StateNormal;
                        if ( state == StateError )
                           call->errorPrinted = False;
                     }
                  }
               }
            }
            break;


         case SE_AT_EXIT_NUM:
            HSEOBJECT_BRUTE_ASSIGN(obj,call->atexit_functions);
            break;

#        if JSE_GETFILENAMELIST==1
         case SE_FILENAMES_NUM:
            /* Not allowed to 'put' to filenames; these are only
             * added to by referring to them in a script, e.g.
             * #include "foo.jsh".
             */
            SEDBG(DebugPrintf(UNISTR("SE_FILENAMES is read-only.\n")));
            break;
#        endif

#        if SE_SHARED_OBJECTS==1
         case SE_SHARED_SERVICES_NUM:
#        endif
         case SE_SERVICES_NUM:
         {
            if( type==SE_VALUE_TYPE )
            {
               void **data_ptr =
#              if SE_SHARED_OBJECTS==1
                  STOCK_OBJ_NUM(origobj)==SE_SHARED_SERVICES_NUM ?  &SE_SHARED_GENERIC_DATA :
#              endif
                  &(global->GenericData);
               if ( SEVAR_GET_TYPE(tmp) == VStorage )
               {
                  *data_ptr = tmp->data.ptr_value;
               }
               else
               {
                  sevarConvert(call,tmp,SE_TOUINT32);
                  SEASSERT( SEVAR_GET_TYPE(tmp)==VNumber );

                  /* don't cast to sememcount, on min-mem that is less than pointer size */
                  *data_ptr = (void *)SEVAR_GET_SLONG(tmp);
               }
            }
            else
            {
               hSEObject *obj_ptr =
#              if SE_SHARED_OBJECTS==1
                  STOCK_OBJ_NUM(origobj)==SE_SHARED_SERVICES_NUM ?  &SE_SHARED_SERVICES_OBJECT :
#              endif
                  &(global->api_services);
               if( *obj_ptr == hSEObjectNull )
                  HSEOBJECT_BRUTE_ASSIGN(*obj_ptr,seobj_new(call,0));
               HSEOBJECT_BRUTE_ASSIGN(obj,*obj_ptr);
            }

         }  break;

         case SE_NOWHERE_NUM:
#           if defined(JSE_TRAP_NOWHERE) && JSE_TRAP_NOWHERE==1
               SEASSERT( False );
#           endif
            break;
      }
   }
   else
   {
      HSEOBJECT_BRUTE_ASSIGN(obj,origobj->data.obj);
   }

   if( obj!=hSEObjectNull )
   {
      switch( type )
      {
         case SE_UNIMEM_TYPE:
         case SE_HIDDEN_TYPE:
         case SE_NUM_TYPE:
         case SE_STR_TYPE:
         case SE_STOCK_TYPE:
            {
               name = to_sevarname(call,type,memdata);
               if ( !CALL_QUIT(call) )
               {
                  wSEVar tmpobj;
                  seAttributes attr;
                  sebool restore_readonly;

                  attr = seobjGetAttributes(call,obj,name);

                  tmpobj = STACK_PUSH;
                  SEVAR_INIT_OBJECT(tmpobj,obj);

                  restore_readonly = ( 0 != (flags & SE_GF_MUST) )
                                  && ( 0 != (attr & SE_READONLY) );
                  if ( restore_readonly )
                  {
                     seobjSetAttributes(call,obj,name,(seAttributes)(attr & ~SE_READONLY));
                  }

                  /* Return if created new member, which is true if the current
                   * object does not have the member. Note that dynamic puts do
                   * not return if anything is created. I could do a dynamic get
                   * to see if it has the member, but a Put is not supposed to be
                   * doing a get, it would mess things up. So, we determine this
                   * information based on the object's internal storage, in my
                   * opinion the right compromise.
                   *
                   * Because of caching, this will not be a big time sink.
                   * If the member is found, the next put will have the member
                   * in its cache and find it right away. If it is not found,
                   * it will be in the not-found cache and likewise save time.
                   * So it is not really adding an extra search of the object.
                   */
                  ret = (seobjGetMemberSlot(call,obj,name)==sememcount_NOT_FOUND);

                  if( flags & (SE_GF_NOCALLBACKS) )
                  {
                     /* Put the member directly, bypass dynamic calls */

                     if ( (flags & SE_GF_MUST)!=0
                      ||  (attr & SE_READONLY)==0 )
                     {
                        seobjNewMember(call,obj,name,tmp,
                                       attr,SE_NM_UPDATE);
                     }
                  }
                  else
                  {
                     if ( !sevarPutValueEx(call,tmpobj,name,tmp,FALSE) )
                        ret = False;
                  }

                  if ( restore_readonly )
                  {
                     seobjSetAttributes(call,obj,name, \
                                        (seAttributes)(SE_READONLY | seobjGetAttributes(call,obj,name)) );
                  }

                  STACK_POP; /* tmpobj */
               }

               DONE_SEVARNAME(call,type,name);
            }
            break;

         case SE_INDEX_TYPE:
         {
            wSEVar tmpobj = STACK_PUSH;
            hSEMembers mems;
            seAttributes attrib SE_UNUSED_INITIALIZER(0);


            SEVAR_INIT_OBJECT(tmpobj,obj);

            mems = SEOBJECT_GET(call,obj,hsemembers);

            if( SEMEMCOUNT_FROM_MEMDATA(memdata) < SEOBJECT_GET(call,obj,used) )
            {
               name = SEMEMBERS_GET(call,mems,SEMEMCOUNT_FROM_MEMDATA(memdata),name);
               attrib = seobjGetAttributes(call,obj,name);
            }
            else
            {
               /* if it is a stack, make a new member at the end */
               flags &= ~SE_GF_MUST;

               if( SEOBJECT_GET(call,obj,flag) & SEOBJ_DONT_SORT )
               {
                  ret = TRUE;   /* making new member */
                  name = PositiveSEStringTableEntry(SEMEMCOUNT_FROM_MEMDATA(memdata));
               }
               else
               {
                  SEASSERT( !ret );
                  STACK_POP;
                  break;
               }
            }

            if( flags & SE_GF_MUST )
               seobjSetAttributes(call,obj,name,(seAttributes)(attrib & ~SE_READONLY));


            if( flags & SE_GF_NOCALLBACKS )
            {
               /* Put the member directly, bypass dynamic calls */

               if( (flags & SE_GF_MUST)!=0 ||
                   (attrib & SE_READONLY)==0 )
               {
                  seobjNewMember(call,obj,name,tmp,
                                 attrib,SE_NM_UPDATE);
               }
            }
            else
            {
               if ( !sevarPutValueEx(call,tmpobj,name,tmp,FALSE) )
                  ret = False;
            }

            if( flags & SE_GF_MUST )
               seobjSetAttributes(call,obj,name,attrib);

            STACK_POP;
         }
         break;

         case SE_VALUE_TYPE:
         {
            wSEVar lhs,rhs;

            lhs = STACK_PUSH;
            rhs = STACK_PUSH;

            SEVAR_COPY(rhs,tmp);
            SEVAR_INIT_OBJECT(lhs,obj);

            IF_OPERATOR_NOT_OVERLOADED(call,lhs,rhs,SE_OP_ASSIGN)
            {
               /* Only thing to do is overload if there */
            }

            STACK_POPX(2);

            break;
         }

         case SE_LIBDATA_TYPE:
            SEDBG(DebugPrintf(UNISTR("Library data is read-only.\n")));
            break;

#        if JSE_SAVE_FUNCTION_TEXT==1
         case SE_FUNCTIONTEXT_TYPE:
            SEDBG(DebugPrintf(UNISTR("Function text is read-only.\n")));
            break;
#        endif

         default:

            SEASSERT( False );
      }
      /* if we just put any member on the global, then the prototype cache may possibly have
       * changed, and so invalidate it just in case.
       */
      if ( obj == CALL_GLOBAL(call) )
      {
         FLUSH_PROTOTYPE_CACHE(call);
      }
   }
   /* else was a 'special' object and we did the put above. */

#  if SE_VAR_PARSE==1
      if ( NULL != parse_obj )
      {
         seFreeObject(JSECONTEXT_FROM_CALL(call),parse_obj);
         seFreeInternalString(JSECONTEXT_FROM_CALL(call),parse_string);
      }
#  endif

   STACK_POP; /* tmp */

   call->mustPrintError = mustPrintError;
   call->sePutMemberDepth_check_hidden--;

   return ret;
}

/* ---------------------------------------------------------------------- */

#if SE_VAR_PARSE==1
/* Parse the varname, advance the pointer, return
 * the varname. Return SE_NO_VARNAME on error
 */
/* end condition may be any of the following */
#define END_SEVARPARSE_NONDIGIT     0  /* end if there is not a digit */
#define END_SEVARPARSE_ILLEGALCHAR  1  /* end on a character that would be an illegal varname */
/* else it is one of the quote characters, and will end on the final quote character */
   static sestring JSE_NEAR_CALL
parse_sevarname(struct seCall *call,seconstcharptr *string,sechar why_end)
{
   secharptr Name;
   sememcount NameLen, NameAllocLen;
   sechar shortName[30];   /* usually the name is short enough to fit in here so allocation not needed */
   sestring ret;
   secharptr put;
   sechar c;

   NameAllocLen = sizeof(shortName)/sizeof(shortName[0]);
   NameLen = 0;
   put = Name = shortName;

   while ( 0 != (c = SECHARPTR_GETC((*string))) )
   {
      if ( END_SEVARPARSE_NONDIGIT == why_end )
      {
         if ( !isdigit_sechar(c) )
            break;
      }
      else if ( END_SEVARPARSE_ILLEGALCHAR == why_end )
      {
         if ( !testLegalVariableChar(c) )
            break;
         if ( 0 == NameLen  &&  isdigit_sechar(c) )
            /* first character of a valid name cannot be a digit */
            break;
      }
      else
      {
         SEASSERT( why_end=='\"' || why_end=='\'' || why_end=='`' );
         if ( why_end == c )
            break;
      }

      if ( NameAllocLen < ++NameLen )
      {
         /* allocate more room to hold this name */
         secharptr newName, oldName;
         NameAllocLen += 30;
         if ( (oldName=Name) == shortName )
            oldName = NULL;
         newName = secoreAllocEx(call,oldName,NameAllocLen,sizeof(sechar),NULL,SE_DEFAULT);
         if ( NULL == newName )
         {
            NameLen = 0;
            break;
         }
         if ( NULL == oldName )
            memcpy(newName,Name,sizeof(shortName));
         Name = newName;
         put = SECHARPTR_OFFSET(Name,NameLen-1);
      }

      SECHARPTR_PUTC(put,c);
      SECHARPTR_INC(put);
      SECHARPTR_INC(*string);
   }

   /* if name was too short or too long, then invalid */
   if( 0==NameLen  ||  ( (sestringLenType)NameLen != NameLen ) )
   {
      ret = SE_NO_VARNAME;
   }
   else
   {
      ret = CreateSEVarName(call,Name,(sestringLenType)NameLen,False);
   }
   if ( Name != shortName )
   {
      secoreFree(call,Name);
   }
   return ret;
}


/* Var parse accepts the following (call it <varparse>):
 *
 * <varparse> ->
 *    <varname>
 *    <varparse>[<number>]
 *    <varparse>["string"]
 *    <varparse>.<varname>
 *
 *
 * This routine is going to be slow, so I've decided to
 * implement it in terms of other routines. This may
 * be changed later, but I don't expect it to be used
 * often.
 */
   JSECALLSEQ( sebool )
#if JSE_TRACKVARS==1
seVarParseDbg(secontext se,seobject orig_obj,seconstcharptr string,seobject *object,sestring *member,int flags,\
                 seassert_filetype file,int line)
#else
seVarParse(secontext se,seobject orig_obj,seconstcharptr string,seobject *object,sestring *member,int flags)
#endif
{
   sedatatype type;
   sechar c;
   seobject obj = NULL, newobj;
   sestring mem = SE_NO_VARNAME, newmem;
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   SE_API_ENTER(call)

   while( 0 != (c = SECHARPTR_GETC(string)) )
   {
      /* Three possibilities:
       *
       *   Varname - only valid if mem==NULL
       *   .Varname - only valid if mem!=NULL
       *   [string/num] - only valid if mem!=NULL
       *
       * For the second two, the existing obj/mem
       * is the object to look in. Look up that object
       * using the stock things. Convert to an object
       * if the flag is set, else if it is not an
       * object, error.
       *
       * For the first, if USE_CALLER_VARS, instead
       * of just setting mem = that new member (i.e.
       * in the SE_GLOBAL, which obj starts at),
       * use callFindAnyVariable + get reference to
       * find the starting object/member.
       */
      if( c=='.' )
      {
         if( SE_NO_VARNAME == mem )
            goto error;

         SECHARPTR_INC(string);
         if ( SE_NO_VARNAME == (newmem = parse_sevarname(call,&string,END_SEVARPARSE_ILLEGALCHAR)) )
            goto error;

      got_name:
         if( SE_TYPE_OBJECT != (type = seGetTypeEx(se,obj,SE_STR(mem),flags)) )
         {
            if ( 0 != (flags & SE_GF_UNDEF_OBJ_OK) )
            {
               /* no matter that it's not defined - use SE_NOWHERE */
               seFreeObject(se,obj);
               obj = SE_NOWHERE;
            }
            else if ( 0 != (flags & SE_GF_COMPOUND_CREATE) )
            {
               if( SE_TYPE_UNDEFINED == type )
               {
                  seobject tmpobj = seMakeObject(se);
                  sePutObject(se,obj,SE_STR(mem),tmpobj);
                  seFreeObject(se,tmpobj);
               }
               else
               {
                  seConvert(se,obj,SE_STR(mem),SE_TOOBJECT);
               }
            }
            else
            {
               goto error;
            }
         }

#        if JSE_TRACKVARS==1
            newobj = seGetObjectExDbg(se,obj,SE_STR_TYPE,(t_sememdata)(mem),\
                                         flags & SE_GF_UNDEF_OBJ_OK,file,line);
#        else
            newobj = seGetObjectEx(se,obj,SE_STR(mem),\
                                   flags & SE_GF_UNDEF_OBJ_OK);
#        endif

         seFreeObject(se,obj);
         obj = newobj;

         seFreeInternalString(se,mem);
         mem = newmem;
      }
      else if( c=='[' )
      {
         /* between [ and ] is either all characters or a string in quotes */
         SECHARPTR_INC(string);

         c = SECHARPTR_GETC(string);

         if( '\"' == c || '\'' == c || '`' == c )
         {
            SECHARPTR_INC(string);
            newmem = parse_sevarname(call,&string,c);
            if ( c != SECHARPTR_GETC(string) )
               goto error;
            SECHARPTR_INC(string);
         }
         else if( isdigit_sechar(c) )
         {
            newmem = parse_sevarname(call,&string,END_SEVARPARSE_NONDIGIT);
         }
         else
         {
            goto error;
         }
         if ( ']' != SECHARPTR_GETC(string) )
            goto error;
         SECHARPTR_INC(string);
         if( SE_NO_VARNAME == newmem )
            goto error;
         goto got_name;
      }
      else if ( testLegalVariableChar(c) )
      {
         if( SE_NO_VARNAME != mem )
            /* this only valid at the beginning -- as the top-level name */
            goto error;

         if ( SE_NO_VARNAME == (newmem = parse_sevarname(call,&string,END_SEVARPARSE_ILLEGALCHAR)) )
            goto error;

         obj = seCloneObject(se,orig_obj);
         mem = newmem;
      }
      else
      {
         goto error;
      }
   }

   if( mem==SE_NO_VARNAME && obj!=SE_NOWHERE )
   {
      SEDBG(DebugPrintf(UNISTR("Empty variable name.\n")));
      goto error;
   }

#  if 0
      /* Create if not exists and the create flags is on. */
      if( !seExists(se,obj,SE_STR(mem)) )
      {
         if ( 0 != (flags & SE_GF_COMPOUND_CREATE) )
         {
            sePutUndefined(se,obj,SE_STR(mem));
         }
         else
         {
            goto error;
         }
      }
#  endif

   if( object )
      *object = obj;
   else
      seFreeObject(se,obj);
   if( member )
      *member = mem;
   else
      RemoveSEVarNameLock(mem);

   SE_API_RETURN(call,TRUE)

error:
   SEASSERT( NULL != obj );
   seFreeObject(se,obj);
   if( object ) *object = SE_NOWHERE;
   if( mem!=SE_NO_VARNAME ) RemoveSEVarNameLock(mem);
   if( member ) *member = SE_NO_VARNAME;
   callQuit(call,textcoreVAR_PARSE_ERROR,string);
   SE_API_RETURN(call,FALSE)
}
#endif /* #if SE_VAR_PARSE==1 */

/* ---------------------------------------------------------------------- */

/* retrieve functions, these all just do a 'get' */

   JSECALLSEQ( sebool )
seGetBoolEx(secontext se,seobject obj,int type,t_sememdata memdata,int flags)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   wSEVar temp_get;
   sebool ret;
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   temp_get = STACK_PUSH;
   seGetMember(call,obj,type,memdata,VBoolean,flags,temp_get);
   SEASSERT( SEVAR_GET_TYPE(temp_get)==VBoolean );
   ret = temp_get->data.bool_val;
   STACK_POP;

   END_TIMING(call);

   SE_API_RETURN(call,ret);
}


   JSECALLSEQ( senumber )
seGetNumberEx(secontext se,seobject obj,int type,t_sememdata memdata,int flags)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   wSEVar temp_get;
   senumber ret;
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   temp_get = STACK_PUSH;
   seGetMember(call,obj,type,memdata,VNumber,flags,temp_get);
   SEASSERT( SEVAR_GET_TYPE(temp_get)==VNumber );
   ret = temp_get->data.num_val;
   STACK_POP;

   END_TIMING(call);

   SE_API_RETURN(call,ret);
}


   JSECALLSEQ( void * )
seGetPointerEx(secontext se,seobject obj,int type,t_sememdata memdata,int flags)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   wSEVar temp_get;
   void *ret;
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   temp_get = STACK_PUSH;
   seGetMember(call,obj,type,memdata,VStorage,flags,temp_get);
   SEASSERT( SEVAR_GET_TYPE(temp_get)==VStorage );
   ret = temp_get->data.ptr_value;
   STACK_POP;

   END_TIMING(call);

   SE_API_RETURN(call,ret)
}

   JSECALLSEQ( seobject )
#if JSE_TRACKVARS==1
seGetObjectExDbg(secontext se,seobject obj,int type,t_sememdata memdata,int flags,seassert_filetype file,int line)
#else
seGetObjectEx(secontext se,seobject obj,int type,t_sememdata memdata,int flags)
#endif
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   wSEVar temp_get;
   seobject ret;
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   temp_get = STACK_PUSH;
   seGetMember(call,obj,type,memdata,VObject,flags,temp_get);

   /* the only way !VObject can happen is with the SE_GF_UNDEF_OBJ_OK flag on */
   SEASSERT( CALL_QUIT(call) \
          || SEVAR_GET_TYPE(temp_get)==VObject \
          || 0!=(flags&SE_GF_UNDEF_OBJ_OK) );

   END_TIMING(call);

   /* seGetMember will always return an object (unless safe not to convert null or undefined), so the
    * old check is wrong. Instead, on error we return SE_NOWHERE.
    */
   if( CALL_QUIT(call) || (VObject!=SEVAR_GET_TYPE(temp_get)) )
   {
      STACK_POP;
      SE_API_RETURN(call,SE_NOWHERE)
   }
   ret = seTempLockObject(call,temp_get->data.object_val.hobj,temp_get->data.object_val.hSavedScopeChain  PASS_FILE_AND_LINE_PARMS );
   STACK_POP;
#  if JSE_TRACKVARS==1
      SE_API_RETURN(call,ret)
#  else
      SE_API_RETURN(call,ret)
#  endif
}

#if SE_GET_NAME==1
   JSECALLSEQ( seconstcharptr )
#if JSE_TRACKVARS==1
seGetNameDbg(secontext se,seobject obj,int type,t_sememdata memdata,sememcount *len,seassert_filetype file,int line)
#else
seGetName(secontext se,seobject obj,int type,t_sememdata memdata,sememcount *len)
#endif
{
   seconstcharptr ret SE_UNUSED_INITIALIZER(NULL);
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   sememcount len_tmp;
#  if JSE_DYNAMIC_CALLBACKS!=0
      wSEVar w_lhs;
      sebool dynamic = FALSE;
#  endif
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   if ( !len ) len = &len_tmp;

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

#  if JSE_DYNAMIC_CALLBACKS==1
   {
      hSEObject the_obj;

      HSEOBJECT_BRUTE_ASSIGN(the_obj,seobjectTohSEObject(call,obj));
      if( the_obj!=hSEObjectNull
       && type==SE_INDEX_TYPE
       && SEOBJ_IS_DYNAMIC_PROP(call,the_obj,getNameByIndex) )
      {
         w_lhs = STACK_PUSH;
         SEVAR_INIT_UNDEFINED(w_lhs);
         if( seobjCallDynamicProperty(call,the_obj,
                                      SE_GETNAMEBYINDEX_CALLBACK,
                                      (seVarName)SEMEMCOUNT_FROM_MEMDATA(memdata),NULL,
                                      w_lhs) )
         {
            if( SEVAR_GET_TYPE(w_lhs)==VUndefined )
            {
               *len = 0;
               ret = seTempLockString(call,(const t_sememdata)NULL,seLOCKSTR__AS_STR,len,False  PASS_FILE_AND_LINE_PARMS );
            }
            else
            {
               ret = seTempLockString(call,(const t_sememdata)(SE_POINTER_UINT)w_lhs,\
                                      seLOCKSTR__AS_VAR,len,True  PASS_FILE_AND_LINE_PARMS );
            }
            dynamic = TRUE;
         }

         STACK_POP;
      }
      ELSE_ALWAYS_COLLECT(call)
   }

   if( !dynamic )
#  else
      /* above calldyna would have caused GC */
      ALWAYS_COLLECT(call)
#  endif
   {
      sebool success;
      secharptr buf;
      wSEVar temp_get = STACK_PUSH;
      seGetMember(call,obj,type,memdata,VUndefined,GF_INTERNAL_REFERENCE,temp_get);

      SEASSERT( SEVAR_GET_TYPE(temp_get)==VReference );

      /* We want to leave it as a reference, because that makes
       * it MUCH easier to give it a name, in fact in many cases,
       * it makes it possible to do so.
       */
      buf = secoreAlloc(call,NULL,256*sizeof(sechar),SE_DEFAULT);
      success = ( NULL == buf )
              ? False
              : secoreFindNames(call,temp_get,buf,256,NULL_SEVARNAME) ;
      if( success )
      {
         *len = (sememcount)strlen_sechar(buf);
         ret = seTempLockString(call,(const t_sememdata)(SE_POINTER_UINT)buf,\
                                seLOCKSTR__AS_STR,len,False  PASS_FILE_AND_LINE_PARMS );
      }
      else
      {
         *len = 0;
         ret = seTempLockString(call,(const t_sememdata)NULL,seLOCKSTR__AS_STR,len,False  PASS_FILE_AND_LINE_PARMS );
      }
      if ( NULL != buf )
         secoreFree(call,buf);

      STACK_POP; /* temp_get */
   }

   END_TIMING(call);

   SE_API_RETURN(call,ret)
}
#endif /* #if SE_GET_NAME==1 */

   JSECALLSEQ( seconstcharptr )
#if JSE_TRACKVARS==1
seObjectMemberNameDbg(secontext se,seobject obj,int type,t_sememdata memdata,sememcount *len,\
                      seassert_filetype file,int line)
#else
seObjectMemberName(secontext se,seobject obj,int type,t_sememdata memdata,sememcount *len)
#endif
{
   seconstcharptr ret = NULL;
#  if JSE_DYNAMIC_CALLBACKS==1
      sebool dynamic = FALSE;
#  endif
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   wSEVar temp_get;
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   temp_get = STACK_PUSH;

#  if JSE_DYNAMIC_CALLBACKS==1
   {
      hSEObject the_obj;

      SEVAR_INIT_UNDEFINED(temp_get);

      HSEOBJECT_BRUTE_ASSIGN(the_obj,seobjectTohSEObject(call,obj));
      if( the_obj!=hSEObjectNull
       && type==SE_INDEX_TYPE
       && SEOBJ_IS_DYNAMIC_PROP(call,the_obj,getNameByIndex) )
      {
         wSEVar w_lhs = STACK_PUSH;
         SEVAR_INIT_UNDEFINED(w_lhs);
         if( seobjCallDynamicProperty(call,the_obj,
                                      SE_GETNAMEBYINDEX_CALLBACK,
                                      (seVarName)SEMEMCOUNT_FROM_MEMDATA(memdata),NULL,
                                      w_lhs) )
         {
            if( SEVAR_GET_TYPE(w_lhs)!=VUndefined )
            {
               sevarConvert(call,w_lhs,SE_TOSTRING);
               SEVAR_COPY(temp_get,w_lhs);
               ret = seTempLockString(call,(const t_sememdata)(SE_POINTER_UINT)temp_get,\
                                      seLOCKSTR__AS_VAR,len,True  PASS_FILE_AND_LINE_PARMS );
            }
            dynamic = TRUE;
         }
         ELSE_ALWAYS_COLLECT(call)

         STACK_POP;
      }
   }
   if( !dynamic )
#  else
      /* above secalldyn could hv GCed */
      ALWAYS_COLLECT(call)
#  endif
   {
      ret = NULL;

      if( seGetMember(call,obj,type,memdata,VUndefined,GF_INTERNAL_REFERENCE,temp_get) )
      {
         sememcount slot;

         END_TIMING(call);
         SEASSERT( SEVAR_GET_TYPE(temp_get)==VReference );

         slot = seobjGetMemberSlot(call,temp_get->data.ref_val.hBase,temp_get->data.ref_val.reference);

         if( slot != sememcount_NOT_FOUND )
         {
            hSEMembers mems = SEOBJECT_GET(call,temp_get->data.ref_val.hBase,hsemembers);
            seVarName name = SEMEMBERS_GET(call,mems,slot,name);

            ret = seTempLockString(call,name,seLOCKSTR__AS_NAME,len,True  PASS_FILE_AND_LINE_PARMS );
         }
      }
   }

   if ( NULL == ret )
   {
      callQuit(call,textcoreMEMBER_DOES_NOT_EXIST);
      if ( len ) *len = 0;
      ret = call->Global->null_TempString;
   }

   STACK_POP; /* temp_get */

   END_TIMING(call);

   SE_API_RETURN(call,ret)
}


   JSECALLSEQ( seAttributes )
seGetAttribsEx(secontext se,seobject obj,int type,t_sememdata memdata,int flags)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   seAttributes ret = 0;
   struct seFunction *func;
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   if( type==SE_VALUE_TYPE )
   {
      hSEObject hobj;
      HSEOBJECT_BRUTE_ASSIGN (hobj,seobjectTohSEObject(call,obj));
      if ( hobj != hSEObjectNull )
      {
         if( (func=SEOBJECT_GET_func(call,hobj)) != NULL )
         {
            ret = func->attributes;
         }
         else
         {
            ret = SE_DEFAULT;

#           if JSE_DYNAMIC_CALLBACKS==1
               if( SEOBJECT_GET(call,hobj,flag)&SEOBJ_DYNAMIC_UNDEFINED )
                  ret |= SE_DYNA_UNDEF;
#           endif
         }
      }
   }
   else
   {
      wSEVar temp_get = STACK_PUSH;
      if(seGetMember(call,obj,type,memdata,VUndefined,flags|GF_INTERNAL_REFERENCE,temp_get))
      {
         sememcount slot;

         if( SEVAR_GET_TYPE(temp_get)==VReference )
         {
            slot = seobjGetMemberSlot(call,temp_get->data.ref_val.hBase,temp_get->data.ref_val.reference);
         }
         else
         {
            SEASSERT( SEVAR_GET_TYPE(temp_get)==VReferenceIndex );
            slot = (sememcount)(temp_get->data.ref_val.reference);
         }

         if( slot != sememcount_NOT_FOUND )
         {
            hSEMembers mems = SEOBJECT_GET(call,temp_get->data.ref_val.hBase,hsemembers);
            ret = SEMEMBERS_GET(call,mems,slot,attributes);
         }
      }
      STACK_POP; /* temp_get */
   }
   END_TIMING(call);
   SE_API_RETURN(call,ret)
}

   static void JSE_NEAR_CALL
setAttribsOnObject(struct seCall *call,hSEObject hobj,seAttributes attributes)
{
   struct seFunction *func;
#  if JSE_MEMEXT_OBJECTS==0
      SE_UNUSED_PARAMETER(call);
#  endif
   SEASSERT( hobj != hSEObjectNull );
   if( (func=SEOBJECT_GET_func(call,hobj)) != NULL )
      func->attributes = attributes;

#  if JSE_DYNAMIC_CALLBACKS==1
      if( attributes & SE_DYNA_UNDEF )
      {
         SEOBJ_MAKE_DYNAMIC_UNDEFINED(call,hobj);
      }
#  endif
}

   JSECALLSEQ( void )
seSetAttribsEx(secontext se,seobject obj,int type,t_sememdata memdata,seAttributes attributes,int flags)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   /* can only set certain attributes; in particular cannot set HIDDEN */
#  if JSE_DYNAMIC_CALLBACKS==1
      attributes &= (SE_DONTENUM|SE_DONTDELETE|SE_READONLY|SE_IMPLICIT_THIS|SE_IMPLICIT_PARENTS|SE_DYNA_UNDEF);
#  else
      attributes &= (SE_DONTENUM|SE_DONTDELETE|SE_READONLY|SE_IMPLICIT_THIS|SE_IMPLICIT_PARENTS);
#  endif

   if( type==SE_VALUE_TYPE )
   {
      hSEObject hobj;
      HSEOBJECT_BRUTE_ASSIGN(hobj,seobjectTohSEObject(call,obj));
      if ( hobj != hSEObjectNull )
         setAttribsOnObject(call,hobj,attributes);
   }
   else
   {
      wSEVar temp_get = STACK_PUSH;
      if( seGetMember(call,obj,type,memdata,VUndefined,flags|GF_INTERNAL_REFERENCE,temp_get) )
      {
         rSEVar mem;
         sememcount slot;
         hSEMembers mems;

         SEASSERT( SEVAR_GET_TYPE(temp_get)==VReference );

         mems = SEOBJECT_GET(call,temp_get->data.ref_val.hBase,hsemembers);
         slot = seobjGetMemberSlot(call,temp_get->data.ref_val.hBase,
                                   temp_get->data.ref_val.reference);

         if( slot != sememcount_NOT_FOUND )
         {
            mem = SEMEMBERS_GET_sevar(call,mems,slot);
            if( SEVAR_GET_TYPE(mem) == VObject )
            {
               setAttribsOnObject(call,SEVAR_GET_OBJECT(mem),attributes);
            }
            /* in case the member is already hidden, we're not allowed to make it un-hidden. so if it is
             * already hidden then force hidden and dontenum on it
             */
            if ( 0 != (SEMEMBERS_GET(call,mems,slot,attributes) & SE_HIDDEN_PROP) )
            {
               attributes |= (SE_HIDDEN_PROP|SE_DONTENUM);
            }
            SEMEMBERS_PUT(call,mems,slot,attributes,attributes);
         }
      }
      STACK_POP; /* temp_get */
   }
   END_TIMING(call);
   SE_API_RETURN_VOID(call)
}



   JSECALLSEQ( sebool )
seSetArray(secontext se,seobject seobj,sememcount length)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   wSEVar tmp;
   hSEObject the_obj;

   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   seassert_is_object( seobj );

   HSEOBJECT_BRUTE_ASSIGN(the_obj,seobjectTohSEObject(call,seobj));
   if ( hSEObjectNull != the_obj )
   {
      seobjMakeEcmaArray(call,the_obj);

      tmp = STACK_PUSH;
      SEVAR_INIT_OBJECT(tmp,the_obj);

      SEASSERT( SEVAR_GET_TYPE(tmp)==VObject );
      {
         hSEObject hobj;
         hSEMembers mems;
         uint x;

         HSEOBJECT_BRUTE_ASSIGN(hobj,SEVAR_GET_OBJECT(tmp));
         for( x=0;x<SEOBJECT_GET(call,hobj,used);x++ )
         {
            seVarName entry;

            mems = SEOBJECT_GET(call,hobj,hsemembers);
            entry = SEMEMBERS_GET(call,mems,x,name);
            if( IsNumericSEStringTableEntry(entry) )
            {
               SE_POINTER_SINDEX value = (SE_POINTER_SINDEX)GetNumericSEStringTableEntry(entry);

               if( value >= (SE_POINTER_SINDEX)length )
               {
                  /* deletemember amy realloc rmembers */
                  seobjDeleteMember(call,hobj,entry,False);
                  /* decrement 'x' to do this slot over again since its former
                   * occupant is gone, and the next entry has slid into its place
                   */
                  x--;
               }
            }
         }
      }
      STACK_POP; /* tmp */
   }

   END_TIMING(call);

   /* NYI: ok, it should return FALSE if the object
    *      was already an array AND its number of
    *      members stayed the same (i.e. no elements
    *      were changed.)
    */
   SE_API_RETURN(call,TRUE)
}


#if JSE_DYNAMIC_CALLBACKS==1
   JSECALLSEQ( sebool )
seSetCallbacks(secontext se,seobject obj,int type,t_sememdata memdata,
               const struct seObjectCallbacks *cbs)
{
   sebool ret;
   hSEObject hobj;
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   wSEVar temp_get;
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   temp_get = STACK_PUSH;
   seGetMember(call,obj,type,memdata,VObject,SE_GF_DEFAULT,temp_get);
   SEASSERT( SEVAR_GET_TYPE(temp_get)==VObject );

   HSEOBJECT_BRUTE_ASSIGN(hobj,SEVAR_GET_OBJECT(temp_get));

   if ( hobj == CALL_GLOBAL(call)  &&  cbs != NULL )
   {
      FLUSH_PROTOTYPE_CACHE(call);
   }

   if ( IS_OUT_OF_MEM_OBJ(call,hobj) )
   {
      ret = False;
   }
   else
   {
#     if JSE_MIN_OBJ_SIZE==1
         ret = SEOBJECT_PUT_callbacks(call,hobj,cbs) ;
#     else
         ret = True;
         SEOBJECT_PUT_callbacks(call,hobj,cbs);
         if( cbs == NULL )
            /* In this case we want to turn off the dynamic flag */
            SEOBJECT_PUT(call,hobj,flag,(objflag)(SEOBJECT_GET(call,hobj,flag)&~OBJ_IS_DYNAMIC));
         else
            SEOBJ_MAKE_DYNAMIC(call,hobj);
#     endif
   }

   STACK_POP; /* temp_get */

   END_TIMING(call);
   SE_API_RETURN(call,ret)
}
   JSECALLSEQ( const struct seObjectCallbacks * )
seGetCallbacks(secontext se,seobject obj,int type,t_sememdata memdata)
{
   hSEObject hobj;
   const struct seObjectCallbacks *cbs;
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   wSEVar temp_get;
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   temp_get = STACK_PUSH;
   seGetMember(call,obj,type,memdata,VObject,SE_GF_DEFAULT,temp_get);
   SEASSERT( SEVAR_GET_TYPE(temp_get)==VObject );

   HSEOBJECT_BRUTE_ASSIGN(hobj,SEVAR_GET_OBJECT(temp_get));

   cbs = SEOBJECT_GET_callbacks(call,hobj);

   STACK_POP; /* temp_get */

   END_TIMING(call);
   SE_API_RETURN(call,cbs)
}
#endif /* #if JSE_DYNAMIC_CALLBACKS==1 */

#if JSE_ENABLE_DYNAMETH==1
#define EnableDynMeth_Failed  ((struct dynacallRecurse *)(-1))
   JSECALLSEQ( restoreDynamicMethodState )
seEnableDynamicMethod(secontext se,seobject obj,int type,t_sememdata memdata,
#                     if defined(JSE_ENABLE_DYNABYPROP) && 0!=JSE_ENABLE_DYNABYPROP
                         sestring whichProperty, /* SE_NO_VARNAME for all properties */
#                     endif
                      enum whichDynamicCallback whichCallback,sebool enable,
                      restoreDynamicMethodState restore_state)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   struct dynacallRecurse *dCallRecurse = (struct dynacallRecurse *)restore_state;
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   if ( dCallRecurse != NULL )
   {
      if ( dCallRecurse != call->Global->dynacallRecurseList )
      {
         /* the only valid reason for this not to be true is the rare rare rare rare
          * case of the previous call having failed due to malloc failure.  Any other
          * reason for this is misuse of the SE API by the application.
          */
         SEASSERT( dCallRecurse == EnableDynMeth_Failed );
      }
      else
      {
         /* was previously set, so undo it here.  This MUST be the top value in the recurse
          * list or the user is doing it wrong.
          */
         SEASSERT( enable != dCallRecurse->enabled );
         SEASSERT( whichCallback == dCallRecurse->whichCall );
#        if defined(JSE_ENABLE_DYNABYPROP) && 0!=JSE_ENABLE_DYNABYPROP
            SEASSERT( dCallRecurse->whichProperty == whichProperty );
#        endif
         call->Global->dynacallRecurseList = dCallRecurse->prev;
         secoreFree(call,dCallRecurse);
      }
      /* following code could have caused GC, so force it here */
      ALWAYS_COLLECT(call)
   }
   else
   {
      dCallRecurse = (struct dynacallRecurse *)
         secoreAlloc(call,NULL,sizeof(struct dynacallRecurse),SE_DEFAULT);

      if ( dCallRecurse == NULL )
      {
         /* return special value so on return we know this one failed */
         dCallRecurse = EnableDynMeth_Failed;
      }
      else
      {
         hSEObject hobj;
         wSEVar temp_get = STACK_PUSH;

         seGetMember(call,obj,type,memdata,VObject,SE_GF_DEFAULT,temp_get);
         SEASSERT( SEVAR_GET_TYPE(temp_get)==VObject );

         HSEOBJECT_BRUTE_ASSIGN(hobj,SEVAR_GET_OBJECT(temp_get));

         dCallRecurse->whichCall = whichCallback;
         dCallRecurse->whichObject = hobj;
#        if defined(JSE_ENABLE_DYNABYPROP) && 0!=JSE_ENABLE_DYNABYPROP
            dCallRecurse->whichProperty = whichProperty;
#        endif
         dCallRecurse->enabled = enable;
         dCallRecurse->prev = call->Global->dynacallRecurseList;
         call->Global->dynacallRecurseList = dCallRecurse;

         STACK_POP; /* temp_get */
      }
   }
   END_TIMING(call);
   SE_API_RETURN(call,dCallRecurse)
}
#endif


   JSECALLSEQ( seconstcharptr )
#if JSE_TRACKVARS==1
seGetStringExDbg(secontext se,seobject obj,int type,t_sememdata memdata,sememcount *len,int flags,\
                    seassert_filetype file,int line)
#else
seGetStringEx(secontext se,seobject obj,int type,t_sememdata memdata,sememcount *len,int flags)
#endif
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   seconstcharptr ret;
   wSEVar temp_get;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   temp_get = STACK_PUSH;
   seGetMember(call,obj,type,memdata,VString,flags,temp_get);
   SEASSERT( SEVAR_GET_TYPE(temp_get)==VString  ||  SEVAR_GET_TYPE(temp_get)==VShortString );

   ret = seTempLockString(call,(const t_sememdata)(SE_POINTER_UINT)temp_get,\
                          seLOCKSTR__AS_VAR,len,True  PASS_FILE_AND_LINE_PARMS );

   STACK_POP; /* temp_get */

   END_TIMING(call);
   SE_API_RETURN(call,ret)
}

   JSECALLSEQ( sedatatype )
seGetTypeEx(secontext se,seobject obj,int type,t_sememdata memdata,int flags)
{
   sedatatype vtype;
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   wSEVar temp_get;
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   temp_get = STACK_PUSH;
   seGetMember(call,obj,type,memdata,VUndefined,flags,temp_get);

   vtype = SEVAR_GET_TYPE(temp_get);

   STACK_POP;

   END_TIMING(call);

   SE_API_RETURN(call,((sedatatype)((vtype==VShortString) ? VString : vtype)))
}

   JSECALLSEQ( sebool )
seIsArray(secontext se,seobject object,int type,t_sememdata memdata,
                       sememcount *length)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   sebool ret;
   wSEVar temp_get;
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   seassert_is_object( object );

   temp_get = STACK_PUSH;
   seGetMember(call,object,type,memdata,VUndefined,SE_DEFAULT,temp_get);

   if( SEVAR_GET_TYPE(temp_get)==VObject )
   {
      hSEObject hobj;
      wSEVar tmp = STACK_PUSH;
      SEVAR_COPY(tmp,temp_get);

      HSEOBJECT_BRUTE_ASSIGN(hobj,SEVAR_GET_OBJECT(tmp));

      if ( length )
      {
         sememcount x, used = SEOBJECT_GET(call,hobj,used);
         hSEMembers mems = SEOBJECT_GET(call,hobj,hsemembers);

         *length = 0;
         for( x=0; x<used; x++ )
         {
            seVarName entry = SEMEMBERS_GET(call,mems,x,name);
            if( IsNumericSEStringTableEntry(entry) )
            {
               SE_POINTER_UINDEX Idx =
                  (SE_POINTER_UINDEX)GetNumericSEStringTableEntry(entry);
               if ( (*length) <= Idx )
                  *length = (sememcount)(Idx + 1);
            }
         }
      }

      ret = (SEOBJECT_GET(call,hobj,flag)&SEOBJ_IS_ARRAY)!=0;

      STACK_POP;
   }
   else
   {
      ret = FALSE;
   }

   STACK_POP; /* temp_get */

   END_TIMING(call);

   SE_API_RETURN(call,ret)
}


   JSECALLSEQ( sebool )
seExistsEx(secontext se,seobject obj,int type,t_sememdata memdata,int flags)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   wSEVar temp_get;
   TIMER_SAVE
   sebool ret;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   temp_get = STACK_PUSH;
   ret = seGetMember(call,obj,type,memdata,VUndefined,flags|SE_GF_UNDEF_OBJ_OK,temp_get);
   STACK_POP;

   END_TIMING(call);

   SE_API_RETURN(call,ret)
}


/* Unfortunately, our previous comparison routine did not match well to
 * Javascript. Javascript expects to know what you are looking for. One
 * can use one 'less' comparison to do any relational comparison but you
 * have to know which comparison (less than, greater than, etc) you want in
 * advance to determine if you need to swap the operands. We cannot do that,
 * hence we need to do the comparison twice. Yuck.
 */
   static sebool JSE_NEAR_CALL
sevarCompare(struct seCall *call,wSEVar vx,wSEVar vy,slong *CompareResult)
{
   /* Unfortunately, ECMA only compares based on less-than. To simulate gathering
    * all three possibilities, we must call this routine twice. This routine
    * will mimic the translation done by the less-than so that the values are
    * not translated more than once.
    *
    * Less than can give you any information you need (by swapping the order
    * of the comparison if necessary) but you need to know which information
    * you are searching for.
    */

   int less_than,greater_than;


   SEASSERT( sevarIsValid(call,vx) );
   SEASSERT( sevarIsValid(call,vy) );

   /* Do the conversion of the operands before calling these so not
    * done twice.
    */
   /* This doesn't really matter.  The only place that this function is called
    * is in jseCompare, and only when using the old-style comparison.  The
    * overhead of converting the variables twice doesn't matter, since this
    * function is virtually unused.
    */
   less_than = sevarECMACompareLess(call,vx,vy);
   greater_than = sevarECMACompareLess(call,vy,vx);

   if( less_than==-1 || greater_than==-1 )
   {
      /* if one of the operands is NaN, it should show up both ways */
      SEASSERT( less_than==-1 && greater_than==-1 );
      *CompareResult = 0;
      /* it means that any test ought to fail. We can't give a relationship
       * between them, ALL relationships are untrue (i.e. it is not less than,
       * not greater than, not less than or equal, etc.) So, the comparison
       * 'fails'.
       */
      return False;
   }

   /* it can't be both, but it can be neither */
   SEASSERT( less_than==0 || greater_than==0 );
   if( less_than==1 )
      *CompareResult = -1;
   else if( greater_than==1 )
      *CompareResult = 1;
   else
      *CompareResult = 0;
   return True;
}

   JSECALLSEQ(sebool)
seCompare(secontext se,seobject lhsObj,int lhsType,t_sememdata lhsData,
          seobject rhsObj,int rhsType,t_sememdata rhsData,slong *result)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   sebool ret;
   wSEVar tmp1,tmp2;
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(lhsType) );
   seassert_is_object( lhsObj );
   SEASSERT( seIsValidMemType(rhsType) );
   seassert_is_object( rhsObj );

   tmp1 = STACK_PUSH;
   seGetMember(call,lhsObj,lhsType,lhsData,VUndefined,SE_DEFAULT,tmp1);
   tmp2 = STACK_PUSH;
   seGetMember(call,rhsObj,rhsType,rhsData,VUndefined,SE_DEFAULT,tmp2);

   if( result==SE_COMP_LESS )
   {
      ret = (sevarECMACompareLess(call,tmp1,tmp2)==1);
   }
   else if( result==SE_COMP_EQUAL )
   {
      ret = sevarECMACompareEquality(call,tmp1,tmp2,False);
   }
   else
   {
      slong tmp_res;

      /* Needed because sevarCompare cannot take a NULL result param */
      if( result==NULL )
         result = &tmp_res;

      sevarCompare(call,tmp1,tmp2,result);
      ret = (result==0);
   }

   END_TIMING(call);

   STACK_POPX(2);

   SE_API_RETURN(call,ret)
}

/* freeing the data stored with those gets */

   JSECALLSEQ( void )
seFreeString(secontext se,seconstcharptr string)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   seassert_is_string(call,string);

   if ( string != call->Global->null_TempString )
   {
      seTempFreeItem(call,find_seTempLockString(call,string));
   }

   END_TIMING(call);
   SE_API_RETURN_VOID(call)
}

   JSECALLSEQ( void )
seFreeObject(secontext se,seobject obj)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   seassert_is_object( obj );

   /* nothing to do for stock objects */
   if( !IS_STOCK_OBJ(obj) )
   {
      seTempFreeItem(call,obj);
   }

   END_TIMING(call);
   SE_API_RETURN_VOID(call)
}


/* ---------------------------------------------------------------------- */

   JSECALLSEQ( SE_POINTER_UINT )
seGetObjectID(secontext se,seobject obj)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   return (SE_POINTER_UINT)seobjectTohSEObject(call,obj);
}



/* object manipulation routines */
   JSECALLSEQ( sememcount )
seObjectMemberCountEx(secontext se,seobject tmpobj,sebool direct)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   hSEObject hobj;
   sememcount ret = 0;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   seassert_is_object( tmpobj );

   /* NYI: special case code for several virtual objects
    *      for those that you might want to know the count of
    */
   HSEOBJECT_BRUTE_ASSIGN(hobj,seobjectTohSEObject(call,tmpobj));
   if( hobj != hSEObjectNull )
   {
#     if JSE_DYNAMIC_CALLBACKS==1
      sebool dynamic = FALSE;
      if ( !direct )
      {
         if( SEOBJ_IS_DYNAMIC_PROP(call,hobj,getMaxIndex) )
         {
            wSEVar w_lhs = STACK_PUSH;
            SEVAR_INIT_UNDEFINED(w_lhs);
            if( seobjCallDynamicProperty(call,hobj,
                                         SE_GETMAXINDEX_CALLBACK,
                                         SE_NO_VARNAME,NULL,
                                         w_lhs) )
            {
               SEASSERT( SEVAR_GET_TYPE(w_lhs)==VNumber );
               /* object member count = max index + 1 */
               ret = (sememcount)(SEVAR_GET_SLONG(w_lhs)+1);
               dynamic = TRUE;
            }
            STACK_POP;
         }
         ELSE_ALWAYS_COLLECT(call)
      }
      if( !dynamic )
#     else
         /* above seobcjcalldyna may have caused GC */
         ALWAYS_COLLECT(call)
#     endif
      {
         ret = SEOBJECT_GET(call,hobj,used);
      }
   }

   END_TIMING(call);

   SE_API_RETURN(call,ret)
}

   JSECALLSEQ( sebool )
seIsFuncEx(secontext se,seobject object,int type,t_sememdata memdata,
           sebool *script,int flags)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   wSEVar temp_get;
   TIMER_SAVE
   hSEObject hobj;
   sebool ret;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   seassert_is_object( object );

   temp_get = STACK_PUSH;
   seGetMember(call,object,type,memdata,VUndefined,flags,temp_get);
   if ( SEVAR_GET_TYPE(temp_get)==VObject )
      HSEOBJECT_BRUTE_ASSIGN(hobj,SEVAR_GET_OBJECT(temp_get));
   else
      HSEOBJECT_INIT_NULL(hobj);
   if( hobj )
   {
      struct seFunction *func;

      SEASSERT( !IS_OUT_OF_MEM_OBJ(call,hobj) );
      func = SEOBJECT_GET_func(call,hobj);
      ret = ( func != NULL );
      if( script!=NULL )
      {
         *script = ret?FUNCTION_IS_LOCAL(func):FALSE;
      }
   }
   else
   {
      ret = FALSE;
      if( script!=NULL ) *script = FALSE;
   }

   STACK_POP; /* temp_get */

   END_TIMING(call);

   SE_API_RETURN(call,ret)
}


/* ---------------------------------------------------------------------- */



   JSECALLSEQ( sebool )
seDelete( secontext se,seobject obj,int type,t_sememdata memdata)
{
   sebool ret;
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );


   /* NYI: Probably hardcode any cases that won't work right doing it
    * this, i.e. for special objects
    */

   /* I've added just the SE_ACTIVATION case to get rid of an annoying
    * debug output when doing function constructors (we add "anonymous"
    * to the activation object and then delete it later).
    */
   if( obj == SE_ACTIVATION )
   {
      /* For the activation object, we want the user to be able to delete
       * members that he or she has added, but not any local vars or
       * parameters.
       *
       * Basically, we rely on the fact that all the members of the variable
       * object are created initially with SE_DONTDELETE.  Since there's no
       * way to change the attributes of variable object members (through the
       * API), we can rely on this behaving appropriately.
       */
      hSEObject hobj;

      ret = False;

      if( CALL_VAROBJ(call) == hSEObjectNull )
         callCreateVariableObject(call,NULL,0);

      HSEOBJECT_BRUTE_ASSIGN(hobj,CALL_VAROBJ(call));
      if( hobj == hSEObjectNull )
         HSEOBJECT_BRUTE_ASSIGN(hobj,CALL_GLOBAL(call));

      if( type <= SE_NUM_TYPE  ||  type == SE_STOCK_TYPE )
      {
         seVarName name = to_sevarname(call,type,memdata);
         ret = seobjDeleteMember(call,hobj,name,True);
         DONE_SEVARNAME(call,type,name);
      }
   }
   else
   {
      wSEVar temp_get = STACK_PUSH;
      if( seGetMember(call,obj,type,memdata,VUndefined,GF_INTERNAL_REFERENCE,temp_get) )
      {
         SEASSERT( SEVAR_GET_TYPE(temp_get)==VReference );
         ret = seobjDeleteMember(call,temp_get->data.ref_val.hBase,
                                 temp_get->data.ref_val.reference,
                                 FALSE);
      }
      else
      {
         ret = FALSE;
      }
      STACK_POP; /* temp_get */
   }
   END_TIMING(call);

   SE_API_RETURN(call,ret)
}

/* creation routines */

   JSECALLSEQ( seobject )
#if JSE_TRACKVARS==1
seMakeObjectDbg(secontext se,seassert_filetype file,int line)
#else
seMakeObject(secontext se)
#endif
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   hSEObject obj;
   seobject ret;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )

   HSEOBJECT_BRUTE_ASSIGN(obj,seobj_new(call,0));
   ret = seTempLockObject(call,obj,hSEObjectNull  PASS_FILE_AND_LINE_PARMS );

   END_TIMING(call);

   SE_API_RETURN(call,ret)
}

   JSECALLSEQ( seobject )
#if JSE_TRACKVARS==1
seMakeStackDbg(secontext se,seassert_filetype file,int line)
#else
seMakeStack(secontext se)
#endif
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   hSEObject obj;
   seobject ret;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )

   HSEOBJECT_BRUTE_ASSIGN(obj,seobj_new(call,(sememcount)-1));
   ret = seTempLockObject(call,obj,hSEObjectNull   PASS_FILE_AND_LINE_PARMS );

   END_TIMING(call);

   SE_API_RETURN(call,ret)
}

/* ---------------------------------------------------------------------- */


/* The put routines */

   JSECALLSEQ( sebool )
sePutBoolEx(secontext se,seobject obj,int type,t_sememdata memdata,int flags,sebool val)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   wSEVar temp_put;
   TIMER_SAVE
   sebool ret;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   temp_put = STACK_PUSH;
   SEVAR_INIT_BOOLEAN(temp_put,(val==False)?False:True);
   ret = sePutMember(call,obj,type,memdata,flags,temp_put);
   STACK_POP;

   END_TIMING(call);

   SE_API_RETURN(call,ret)
}


   JSECALLSEQ( sebool )
sePutNumberEx(secontext se,seobject obj,int type,t_sememdata memdata,int flags,senumber val)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   wSEVar temp_put;
   TIMER_SAVE
   sebool ret;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

#  if JSE_FLOATING_POINT==1
      /* there may be a whole range of NaN values, but internally we only want to represent
       * them as one bit pattern.
       */
      if ( jseIsAnyNaN(val) )
         val = jseNaN;
#  endif
   temp_put = STACK_PUSH;
   SEVAR_INIT_NUMBER(temp_put,val);
   ret = sePutMember(call,obj,type,memdata,flags,temp_put);
   STACK_POP;

   END_TIMING(call);

   SE_API_RETURN(call,ret)
}


   JSECALLSEQ( sebool )
sePutPointerEx(secontext se,seobject obj,int type,t_sememdata memdata,int flags,void *data)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   wSEVar temp_put;
   TIMER_SAVE
   sebool ret;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

#  ifndef SE_RELEASE_BUILD
   {
      /* It is only safe to putpointer in special cricumstances - NOT where a script
       * can get directly at the value.  So assure here that a script cannot get
       * at this value.
       */
      sebool nice_to_point = False;
      int pt_type = type;
      t_sememdata pt_memdata = memdata;
      while( pt_type == SE_STRUCT_TYPE )
      {
         pt_type = ((struct seMemberDesc *)pt_memdata)->type;
         pt_memdata = ((struct seMemberDesc *)pt_memdata)->memdata;
      }
      if ( pt_type == SE_HIDDEN_TYPE )
         nice_to_point = True;
      else if ( pt_type == SE_STR_TYPE  &&  IS_HIDDEN_PROP(memdata) )
         nice_to_point = True;
      else if ( obj == SE_SERVICES )
         nice_to_point = True;
#     if SE_SHARED_OBJECTS==1
      else if ( obj == SE_SHARED_SERVICES )
         nice_to_point = True;
#     endif
      SEASSERT( nice_to_point );
   }
#  endif

   temp_put = STACK_PUSH;
   SEVAR_INIT_STORAGE_PTR(temp_put,data);
   ret = sePutMember(call,obj,type,memdata,flags,temp_put);
   STACK_POP;

   END_TIMING(call);

   SE_API_RETURN(call,ret)
}

   JSECALLSEQ( sebool )
sePutObjectEx(secontext se,seobject obj,int type,t_sememdata memdata,int flags,seobject obj_to_put)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   wSEVar temp_put;
   sebool ret = False;
   hSEObject hobj;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   HSEOBJECT_BRUTE_ASSIGN(hobj,seobjectTohSEObject(call,obj_to_put));

#  if JSE_MULTIPLE_GLOBAL==1
   if ( SE_FUNCTIONGLOBAL_TYPE == type )
   {
      /* putting null as the function global */
      struct seFunction *func;
      temp_put = STACK_PUSH;
      SEVAR_INIT_OBJECT(temp_put,seobjectTohSEObject(call,obj));
      SEASSERT( hSEObjectNull != SEVAR_GET_OBJECT(temp_put) );

      func = sevarGetFunction(call,temp_put);
      if( NULL != func )
      {
         HSEOBJECT_ASSIGN(func->hglobal_object,hobj);
         ret = True;
      }
      STACK_POP;
   }
   else
#  endif
   {
      if ( hobj != hSEObjectNull )
      {
         hSEObject ssc;
         HSEOBJECT_INIT_NULL(ssc);

         if ( !IS_STOCK_OBJ(obj_to_put) )
         {
            HSEOBJECT_BRUTE_ASSIGN(ssc,obj_to_put->hSavedScopeChain);
         }
         
         temp_put = STACK_PUSH;
         SEVAR_INIT_OBJECT(temp_put,hobj);
         HSEOBJECT_INIT_ASSIGN(temp_put->data.object_val.hSavedScopeChain,ssc);
         ret = sePutMember(call,obj,type,memdata,flags,temp_put);
         STACK_POP;
      }
   }

   END_TIMING(call);

   SE_API_RETURN(call,ret)
}


   JSECALLSEQ( sebool )
sePutWrapperEx(secontext se,seobject obj,int type, t_sememdata memdata,
               seconstcharptr name,
               seWrapper wrapper_func,
               int minArgs,int maxArgs,
               uword32 funcFlags,
               uword32 varFlags,
               void *data,
               int flags)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   struct LibraryFunction *libfunc;
   wSEVar temp_put;
   TIMER_SAVE
   sebool ret = False;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   temp_put = STACK_PUSH;
   SEVAR_INIT_BLANK_OBJECT(call,temp_put);
   libfunc = libfuncNewWrapper(call,
                               name,
                               wrapper_func,
                               (sword8)minArgs,(sword8)maxArgs,
                               (seVarAttributes)varFlags,
                               (seFuncAttributes)funcFlags,
                               data,
                               temp_put);

   if ( NULL != libfunc )
   {
      if ( seobjSetFunction(call,SEVAR_GET_OBJECT(temp_put),(struct seFunction *)libfunc) )
      {
         /* NYI: Why would the return value be the result of sePutMember?
          * sePutMember returns true if a new member is created.  But I
          * may want to do sePutWrapper(SE_RETURN,SE_VALUE), which would
          * return False from sePutMember, but is still a valid place to
          * put a wrapper function.
          */
         /* if new member is created then put any non-default attributes, else
          * if one already exists then overwrite whatever attrib is being set.
          */
         if (!sePutMember(call,obj,type,memdata,flags,temp_put)
             || SE_DEFAULT != varFlags )
         {
            if ( !IS_STOCK_OBJ(obj) )
               seSetAttribsEx(se,obj,type,memdata,(seAttributes)varFlags,flags);
         }
         ret = True;
      }
   }
   else
   {
      SEASSERT( !CALL_NORMAL(call) );
   }

   STACK_POP; /* temp_put */

   END_TIMING(call);
   SE_API_RETURN(call,ret)
}

   JSECALLSEQ( sebool )
sePutStringEx(secontext se,seobject obj,int type,t_sememdata memdata,int flags,
                           seconstcharptr str,sememcount len)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   wSEVar temp_put;
   TIMER_SAVE
   sebool ret;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   if ( len == SE_PS_STRLEN )
   {
      len = (sememcount) (str ? strlen_sechar(str) : 0);
   }

   temp_put = STACK_PUSH;

   if( flags & (SE_PS_USEPOINTER|SE_PS_BORROWPOINTER) )
   {
      sevarInitString(call,temp_put,str,len,
                      #if JSE_MBCS==1
                      SIS_CALC_SECHAR,
                      #endif
                      (flags&SE_PS_BORROWPOINTER)==0 ? sevarIS_should_free : 0 );

      flags &= ~(SE_PS_USEPOINTER|SE_PS_BORROWPOINTER);
   }
   else
   {
      SEVAR_INIT_STR(call,temp_put,str,len,SIS_CALC_SECHAR);
   }

   ret = sePutMember(call,obj,type,memdata,flags,temp_put);

   STACK_POP;

   END_TIMING(call);

   SE_API_RETURN(call,ret)
}


   JSECALLSEQ( sebool )
sePutUndefinedEx(secontext se,seobject obj,int type,t_sememdata memdata,int flags)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   wSEVar temp_put;
   TIMER_SAVE
   sebool ret;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   temp_put = STACK_PUSH;
   SEVAR_INIT_UNDEFINED(temp_put);
   ret = sePutMember(call,obj,type,memdata,flags,temp_put);
   STACK_POP;

   END_TIMING(call);

   SE_API_RETURN(call,ret)
}

   JSECALLSEQ( sebool )
sePutNullEx(secontext se,seobject obj,int type,t_sememdata memdata,int flags)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   wSEVar temp_put;
   TIMER_SAVE
   sebool ret;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   temp_put = STACK_PUSH;
   SEVAR_INIT_NULL(temp_put);
   ret = sePutMember(call,obj,type,memdata,flags,temp_put);
   STACK_POP;

   END_TIMING(call);

   SE_API_RETURN(call,ret)
}

   JSECALLSEQ( sebool )
seAssignEx(secontext se,
           seobject destObj,int desttype,t_sememdata destdata,
           seobject srcObj,int srctype,t_sememdata srcdata,
           int flags)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   wSEVar temp_get;
   TIMER_SAVE
   sebool ret;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(desttype) );
   SEASSERT( seIsValidMemType(srctype) );
   seassert_is_object( srcObj );
   seassert_is_object( destObj );

   temp_get = STACK_PUSH;
   /* Just get it, don't care about its current type */
   seGetMember(call,srcObj,srctype,srcdata,VUndefined,flags,temp_get);
   /* and put it to the dest */
   ret = sePutMember(call,destObj,desttype,destdata,flags,temp_get);
   STACK_POP;

   END_TIMING(call);

   SE_API_RETURN(call,ret)
}


/* A get-then-put routine */
   JSECALLSEQ( void )
seConvert(secontext se,seobject obj,int type,t_sememdata memdata,
                       seConversionTarget dest_type)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   wSEVar temp_get;
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( seIsValidMemType(type) );
   seassert_is_object( obj );

   temp_get = STACK_PUSH;
   seGetMember(call,obj,type,memdata,VUndefined,SE_GF_DEFAULT,temp_get);

   sevarConvert(call,temp_get,dest_type);

   sePutMember(call,obj,type,memdata,SE_GF_DEFAULT,temp_get);

   STACK_POP; /* temp_get */

   END_TIMING(call);
   SE_API_RETURN_VOID(call)
}

/* ---------------------------------------------------------------------- */
#endif /* #if JSE_UTIL_SEGMENT==1 */

#if JSE_COMPILER_SEGMENT==1

/* libtable entries */

   JSECALLSEQ( sebool )
seAddLibTable(secontext se,
#             if defined(__JSE_PALMOS__) || defined(JSE_PSEUDO_PALMOS)
                 MemHandle (*table_func)(secontext),
#             else
                 const struct seLibraryTableEntry *table,
#             endif /* if defined(__JSE_PALMOS__) || defined(JSE_PSEUDO_PALMOS) */
              void *data)
{
#  if defined(__JSE_PALMOS__) || defined(JSE_PSEUDO_PALMOS)
      const struct seLibraryTableEntry *table;
#  endif
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   wSEVar place;
   sebool init_success;

   /* workspace */
   wSEVar tmp,tmp2,tmp3;

   /* stack stuff */
   int pushes = 0;

   /* library dest */
   struct secoreLibrary *lib;
   SE_API_ENTER(call)

   TIMING(call,se);

   lib = (struct secoreLibrary *)secoreAlloc(call,NULL,sizeof(struct secoreLibrary),SE_DEFAULT);
   if( lib==NULL )
   {
      END_TIMING(call);
      SE_API_RETURN(call,FALSE)
   }

#  if defined(__JSE_PALMOS__)
      lib->dbHandle = (*table_func)(JSECONTEXT_FROM_CALL(call));
      table = (const struct seLibraryTableEntry *)
              ((SE_POINTER_UINT)MemHandleLock(lib->dbHandle)+FuncListOffset);
#  elif defined(JSE_PSEUDO_PALMOS)
      table = (const struct seLibraryTableEntry *)
              ((SE_POINTER_UINT)((*table_func)(JSECONTEXT_FROM_CALL(call)))+FuncListOffset);
#  endif
#  if defined(__JSE_PALMOS__) || defined(JSE_PSEUDO_PALMOS)
      lib->DbHandleFunc = table_func;
#  endif

   place = STACK_PUSH;
   SEVAR_INIT_OBJECT(place,CALL_GLOBAL(call));

   /* create library structure and store it in call */
   lib->table = table;
   lib->initf = NULL;
   lib->termf = NULL;
   lib->userdata = data;
   lib->libdata = NULL;
#  if JSE_COMPACT_LIBFUNCS==1 && JSE_MULTIPLE_GLOBAL==1
      HSEOBJECT_ASSIGN(lib->global,CALL_GLOBAL(call));
      lib->compacted_global_users = 1; /* pretend there is one extra, so intermediates do not remove it */
#  endif

   lib->next = call->TheLibrary->next;
   call->TheLibrary->next = lib;

   tmp = STACK_PUSH;
   SEVAR_INIT_UNDEFINED(tmp);
   tmp2 = STACK_PUSH;
   SEVAR_INIT_UNDEFINED(tmp2);

   for ( ; ; )
   {
      seconstcharptr str_value;
      seconstcharptr str_name;

      if( table->type==SE_END_TABLE_TYPE ) break;

      switch( table->type )
      {
         case SE_INITFUNC_TYPE:
            /* you are not supposed to declare two init functions */
            SEASSERT( lib->initf==NULL );
            lib->initf = (seLibraryInitFunc)(table->value);
            break;

         case SE_TERMFUNC_TYPE:
            /* you are not supposed to declare two term functions */
            SEASSERT( lib->termf==NULL );
            lib->termf = (seLibraryTermFunc)(table->value);
            break;

         case SE_INTEGER_TYPE:
            SEVAR_COPY(tmp,place);
            str_name = PALMTABLE_STR_DEREF(table->name);
            GetDotNamedVar(call,tmp,str_name,SE_DEFAULT);
            SEVAR_INIT_NUMBER(tmp2,JSE_FP_CAST_FROM_SLONG((slong)table->value));
            /* We must turn off flags for this variable so put succeeds */
            SEASSERT( SEVAR_GET_TYPE(tmp)==VReference );
            seobjSetAttributes(call,tmp->data.ref_val.hBase,
                               tmp->data.ref_val.reference,0);
            SEVAR_DO_PUT(call,tmp,tmp2);
            /* Now restore flags with the user-supplied var attribs */
            seobjSetAttributes(call,tmp->data.ref_val.hBase,
                               tmp->data.ref_val.reference,
                               table->varFlags);
            break;

         case SE_NUMLITERAL_TYPE:
            SEVAR_COPY(tmp,place);
            str_name = PALMTABLE_STR_DEREF(table->name);
            GetDotNamedVar(call,tmp,str_name,SE_DEFAULT);
            str_value = PALMTABLE_STR_DEREF(table->value);
            SEVAR_INIT_NUMBER(tmp2,convertStringToNumber(call,str_value,strlen_sechar(str_value)));
            /* We must turn off flags for this variable so put succeeds */
            SEASSERT( SEVAR_GET_TYPE(tmp)==VReference );
            seobjSetAttributes(call,tmp->data.ref_val.hBase,
                               tmp->data.ref_val.reference,0);
            SEVAR_DO_PUT(call,tmp,tmp2);
            /* Now restore flags with the user-supplied var attribs */
            seobjSetAttributes(call,tmp->data.ref_val.hBase,
                               tmp->data.ref_val.reference,
                               table->varFlags);

         case SE_STRING_TYPE:
            SEVAR_COPY(tmp,place);
            str_name = PALMTABLE_STR_DEREF(table->name);
            GetDotNamedVar(call,tmp,str_name,SE_DEFAULT);
            str_value = PALMTABLE_STR_DEREF(table->value);
            SEVAR_INIT_STR(call,tmp2,str_value,SIS_CALC_SECHAR,SIS_CALC_SECHAR);
            /* We must turn off flags for this variable so put succeeds */
            SEASSERT( SEVAR_GET_TYPE(tmp)==VReference );
            seobjSetAttributes(call,tmp->data.ref_val.hBase,
                               tmp->data.ref_val.reference,0);
            SEVAR_DO_PUT(call,tmp,tmp2);
            /* Now restore flags with the user-supplied var attribs */
            seobjSetAttributes(call,tmp->data.ref_val.hBase,
                               tmp->data.ref_val.reference,
                               table->varFlags);
            SEVAR_DO_PUT(call,tmp,tmp2);
            break;

         case SE_INOBJECT_TYPE:
            tmp3 = STACK_PUSH;
            pushes++;
            SEVAR_COPY(tmp3,place);
            str_name = PALMTABLE_STR_DEREF(table->name);
            GetDotNamedVar(call,place,str_name,GDNV_MUST_BE_OBJECT);

            SEVAR_COPY(tmp,tmp3);
            GetDotNamedVar(call,tmp,str_name,SE_DEFAULT);
            seobjSetAttributes(call,tmp->data.ref_val.hBase,
                                    tmp->data.ref_val.reference,
                                    table->varFlags);
            break;

         case SE_END_PROTO_TYPE:
         case SE_END_OBJECT_TYPE:
         case SE_END_CLASS_TYPE:
            SEVAR_COPY(place,STACK0);
            STACK_POP;
            pushes--;
            break;

         case SE_FUNCTION_TYPE:
         case SE_CLASS_TYPE:
            SEVAR_COPY(tmp,place);
            SEVAR_DEREFERENCE(call,tmp);
            if ( VObject != tmp->type )
            {
               SEASSERT( !CALL_NORMAL(call) );
               if( table->type==SE_CLASS_TYPE )
               {
                  tmp3 = STACK_PUSH;
                  SEVAR_INIT_UNDEFINED(tmp3);
               }
            }
            else
            {
#              if JSE_COMPACT_LIBFUNCS==1
                  libfuncNewCompact(call,SEVAR_GET_OBJECT(tmp),table,lib);
#              else
                  libfuncNew(call,SEVAR_GET_OBJECT(tmp),table,&(lib->libdata));
#              endif

               SEVAR_COPY(tmp,place);
               str_name = PALMTABLE_STR_DEREF(table->name);
               GetDotNamedVar(call,tmp,str_name,SE_DEFAULT);
               seobjSetAttributes(call,tmp->data.ref_val.hBase,
                                       tmp->data.ref_val.reference,
                                       table->varFlags);

               if( table->type==SE_CLASS_TYPE )
               {
                  wSEVar subtmp,subtmp1,subtmp2;

                  /* new stuff should be added to the object's prototype */
                  tmp3 = STACK_PUSH;
                  pushes++;
                  SEVAR_COPY(tmp3,place);

                  /* We are supposed to move into the new class */
                  GetDotNamedVar(call,place,str_name,GDNV_MUST_BE_OBJECT);

                  /* Here are some standard class rules that all
                   * ECMAScript standard classes get and that we
                   * apply to anything using the SE_CLASS
                   * creation method.
                   */

                  /* Add to the class variable a .prototype. Make the
                   * prototype SE_STOCK_ATTRIBS
                   */
                  subtmp = STACK_PUSH;
                  subtmp1 = STACK_PUSH;
                  subtmp2 = STACK_PUSH;

                  SEVAR_INIT_UNDEFINED(subtmp);
                  SEVAR_INIT_UNDEFINED(subtmp1);
                  SEVAR_INIT_UNDEFINED(subtmp2);


                  SEVAR_COPY(subtmp,place);
                  GetDotNamedVar(call,subtmp,JseStr(call,prototype),GDNV_MUST_BE_OBJECT);
                  SEASSERT( SEVAR_GET_TYPE(subtmp)==VReference );
                  seobjSetAttributes(call,subtmp->data.ref_val.hBase,
                                          subtmp->data.ref_val.reference,
                                          SE_STOCK_ATTRIBS);

                  /* Add to the prototype a ._class equal to 'table->name'
                   */
                  SEVAR_COPY(subtmp1,subtmp);
                  GetDotNamedVar(call,subtmp1,JseStr(call,_class),SE_DEFAULT);
                  SEVAR_INIT_STR(call,subtmp2,str_name,SIS_CALC_SECHAR,SIS_CALC_SECHAR);
                  SEVAR_DO_PUT(call,subtmp1,subtmp2);
                  SEASSERT( SEVAR_GET_TYPE(subtmp1)==VReference );
                  seobjSetAttributes(call,subtmp1->data.ref_val.hBase,
                                          subtmp1->data.ref_val.reference,
                                          SE_STOCK_ATTRIBS);

                  /* Add to the prototype a .constructor equal to the
                   * class object.
                   */

                  SEVAR_COPY(subtmp1,subtmp);
                  GetDotNamedVar(call,subtmp1,JseStr(call,constructor),SE_DEFAULT);
                  SEVAR_COPY(subtmp2,place);
                  SEVAR_DEREFERENCE(call,subtmp2);
                  SEVAR_DO_PUT(call,subtmp1,subtmp2);
                  SEASSERT( SEVAR_GET_TYPE(subtmp1)==VReference );
                  seobjSetAttributes(call,subtmp1->data.ref_val.hBase,
                                          subtmp1->data.ref_val.reference,
                                          SE_DONTENUM);

                  STACK_POPX(3);
               }
            }
            break;

         case SE_PROTO_TYPE:
            /* Move into the prototype */
            tmp3 = STACK_PUSH;
            pushes++;
            SEVAR_COPY(tmp3,place);
            GetDotNamedVar(call,place,JseStr(call,prototype),GDNV_MUST_BE_OBJECT);
            break;

         case SE_COPY_TYPE:
            SEVAR_COPY(tmp,place);
            str_name = PALMTABLE_STR_DEREF(table->name);
            GetDotNamedVar(call,tmp,str_name,SE_DEFAULT);
            SEVAR_COPY(tmp2,place);
            str_value = PALMTABLE_STR_DEREF(table->value);
            GetDotNamedVar(call,tmp2,str_value,SE_DEFAULT);
            SEVAR_DEREFERENCE(call,tmp2);
            SEVAR_DO_PUT(call,tmp,tmp2);
            seobjSetAttributes(call,tmp->data.ref_val.hBase,
                                    tmp->data.ref_val.reference,
                                    table->varFlags);
            break;

         case SE_ATTRIB_TYPE:
            SEVAR_COPY(tmp,place);
            str_name = PALMTABLE_STR_DEREF(table->name);
            GetDotNamedVar(call,tmp,str_name,SE_DEFAULT);
            SEASSERT( SEVAR_GET_TYPE(tmp)==VReference );
            seobjSetAttributes(call,tmp->data.ref_val.hBase,
                                    tmp->data.ref_val.reference,
                                    table->varFlags);
            break;

         /* To avoid compiler warning */
         default:
            SEASSERT( FALSE );
            break;
      }

      table++;
   }

   init_success = CALL_NORMAL(call);

   if( lib->initf && init_success )
   {
#     if (defined(__JSE_WIN16__) || defined(__JSE_DOS16__)) \
         && (defined(__JSE_DLLLOAD__) || defined(__JSE_DLLRUN__))
         (void _FAR_ *)DispatchToClient(call->Global->ExternalDataSegment,
                                        (ClientFunction)initf,
                                        (void *)JSECONTEXT_FROM_CALL(call),data)
#     else
         lib->libdata = (*lib->initf)(JSECONTEXT_FROM_CALL(call),data);
#     endif
      init_success = CALL_NORMAL(call);
      if ( lib->termf && !init_success )
      {
#        if (defined(__JSE_WIN16__) || defined(__JSE_DOS16__)) \
            && (defined(__JSE_DLLLOAD__) || defined(__JSE_DLLRUN__))
            (void _FAR_ *)DispatchToClient(call->Global->ExternalDataSegment,
                                           (ClientFunction)termf,
                                           (void *)JSECONTEXT_FROM_CALL(call),libdata)
#        else
            (*lib->termf)(JSECONTEXT_FROM_CALL(call),lib->libdata);
#        endif
      }
   }

   if ( !init_success )
   {
      call->TheLibrary->next = lib->next;
      secoreFree(call,lib);
   }
#  if JSE_COMPACT_LIBFUNCS==1 && JSE_MULTIPLE_GLOBAL==1
   else
   {
      SEASSERT( 0 != lib->compacted_global_users );
      if ( --(lib->compacted_global_users) == 0 )
      {
         HSEOBJECT_ASSIGN_NULL(lib->global);
      }
   }
#  endif

   /* else you do not properly have the END_XXX versions of each of
    * your object entries.
    */
   SEASSERT( pushes==0 );

   STACK_POPX((uint)3+pushes);

   /* this addition may have changed the libraries */
   FLUSH_PROTOTYPE_CACHE(call);

   END_TIMING(call);
   SE_API_RETURN(call,init_success)
}

/* Note that security is associated with a function when it is
 * created. Calling a function ALWAYS invokes the security for
 * that function. Since calling a function does not interpret
 * new code, there is no security to be added to that new code.
 */
   static sebool JSE_NEAR_CALL
seEvalFunc(struct seCall *call,seobject func_obj,hSEObject args,
           uword32 flags,struct seEvalParams *params)
{
   /* Note that the timing wrapper code, and the conversion
    * from context->call are all handled by seEval, which
    * calls this routine.
    */
   STACKPTR call_func_mark_save;
   uword8 old_mpe = call->mustPrintError;
   wSEVar func_var,this_var;
   const struct seFunction *func;
   uint depth,origdepth = 0;
   sebool ret;
   wSEVar tmp = NULL;
   uint pushes = 0;
   hSEObject realobj;
   struct seCallFunctionScopes scopes;
   hSEObject ssc;

   HSEOBJECT_INIT_NULL(ssc);
   HSEOBJECT_BRUTE_ASSIGN(realobj,seobjectTohSEObject(call,func_obj));

   if ( !IS_STOCK_OBJ(func_obj) )
   {
      HSEOBJECT_BRUTE_ASSIGN(ssc,func_obj->hSavedScopeChain);
   }

   if ( realobj == hSEObjectNull )
      return False;

   if( params!=NULL && params->global!=NULL )
   {
      tmp = STACK_PUSH;
      pushes++;
      SEVAR_INIT_OBJECT(tmp,CALL_GLOBAL(call));
      seassert_is_object(params->global);
      HSEOBJECT_ASSIGN(CALL_GLOBAL(call),seobjectTohSEObject(call,params->global));
   }

   /* The this & function to call must be on the stack first when
    * using callFunction(). Set that up and initialize it
    * as undefined, so garbage collections during its
    * setup do not have junk on the stack.
    */
   this_var = STACK_PUSH;
   SEVAR_INIT_UNDEFINED(this_var);
   func_var = STACK_PUSH;
   SEVAR_INIT_OBJECT(func_var,realobj);
   HSEOBJECT_INIT_ASSIGN(func_var->data.object_val.hSavedScopeChain,ssc);
   pushes += 2;

   if( flags & SE_CONSTRUCTOR )
   {
      wSEVar tmp;

      if( params!=NULL && params->default_this!=NULL )
      {
         seassert_is_object(params->default_this);
         SEVAR_INIT_OBJECT(this_var,seobjectTohSEObject(call,params->default_this));
      }
      else
      {
         sevarInitNewObject(call,this_var,func_var);
      }

      /* Get to temp location to not overwrite 'func_var' in
       * middle of the call.
       */
      tmp = STACK_PUSH;
      SEVAR_INIT_UNDEFINED(tmp);
      seobjGetFuncVar(call,func_var,JseStockString(_construct),tmp);

      SEVAR_COPY(func_var,tmp);
      STACK_POP;
      func = sevarGetFunction(call,func_var);
   }
   else
   {
      if( params!=NULL && params->default_this!=NULL )
      {
         seassert_is_object(params->default_this);
         SEVAR_INIT_OBJECT(this_var,seobjectTohSEObject(call,params->default_this));
      }
      else
      {
         SEVAR_INIT_OBJECT(this_var,CALL_GLOBAL(call));
      }
      func = sevarGetFunction(call,func_var);
   }

   if( NULL == func )
   {
      callQuit(call,textcoreNOT_FUNCTION_VARIABLE,UNISTR(""));
      goto fail;
   }


   /* Transfer the arguments to the stack. In the case of
    * by-ref args, put a reference to the args obj
    * member for them.
    */
   if( args!=hSEObjectNull )
   {
#     if JSE_NAMED_PARAMS==1
      if( (flags & SE_NAMED_PARAMS)==0 )
#     endif
      {
         hSEMembers mems = SEOBJECT_GET(call,args,hsemembers);
         origdepth = SEOBJECT_GET(call,args,used);


         for( depth=0;depth<origdepth;depth++ )
         {
            wSEVar onstack;
            rSEVar param;

#           if JSE_PASSBYREF==1
            uword8 passByRef;
            if ( FUNCTION_IS_LOCAL(func)
              && depth < ((struct LocalFunction*)func)->localItems.InputParameterCount)
            {
               passByRef = ((struct LocalFunction*)func)->localItems.items[depth].passByRef;
               SEASSERT(passByRef == 0 || passByRef == 1);
            }
            else
               passByRef = 0;
#           endif

            param = SEMEMBERS_GET_sevar(call,mems,depth);

            onstack = STACK_PUSH;
            pushes++;
#           if JSE_PASSBYREF==1
            if ( 0!=passByRef || FUNCTION_PASSBYREF(func) )
            {
               /* Pass by reference */

               if( SEVAR_GET_TYPE(param)<VReference )
               {
                  SEVAR_INIT_REFERENCE_INDEX(onstack,args,depth);
               }
               else
               {
                  SEVAR_COPY(onstack,param);
               }
            }
            else
#           endif
            {
               SEVAR_COPY(onstack,param);
            }
         }
      }
#     if JSE_NAMED_PARAMS==1
      else
      {
         wSEVar onstack;


         hSEMembers mems = SEOBJECT_GET(call,args,hsemembers);
         origdepth = SEOBJECT_GET(call,args,used);


         /* Check that all parameters have a name */
         for( depth=0;depth<origdepth;depth++ )
         {
            seVarName name = SEMEMBERS_GET(call,mems,depth,name);

            if( name==SE_NO_VARNAME )
            {
               SEDBG(DebugPrintf(UNISTR("Named parameters must all have a name.\n")));
               goto fail;
            }
         }

         /* Push the arguments */

         onstack = STACK_PUSH;
         pushes++;
         SEVAR_INIT_OBJECT(onstack,args);
      }
#     endif
   }

   call_func_mark_save = call->Global->call_func_mark;
   call->Global->call_func_mark = FRAME;
   if( (flags&SE_REPORT_ERRORS)==0 )
      call->mustPrintError = FALSE;

   HSEOBJECT_INIT_ASSIGN( scopes.start, \
                          (hSEObject)( (params && params->scopestart) \
                                     ? seobjectTohSEObject(call,params->scopestart) \
                                     : hSEObjectNull ) );
   HSEOBJECT_INIT_ASSIGN( scopes.end, \
                          (hSEObject)( (params && params->scopeend) \
                                     ? seobjectTohSEObject(call,params->scopeend) \
                                     : hSEObjectNull ) );


   call->resetContinueCount = ( (flags & JSE_INTERPRET_INFREQUENT_CONT) != 0 )
                            ? (uword32)JSE_INFREQUENT_COUNT : 1 ;
   if( flags&SE_START )
   {
      struct evalFuncStart *start_info;

      start_info = (struct evalFuncStart *)secoreAlloc(call,NULL,sizeof(struct evalFuncStart),SE_DEFAULT);
      if( start_info==NULL )
      {
         call->Global->call_func_mark = call_func_mark_save;

         call->mustPrintError = old_mpe;

         goto fail;
      }


      /* fill in the structure and call function */


      start_info->next = call->start_info;
      call->start_info = start_info;

      start_info->call_func_mark_save = call_func_mark_save;
      start_info->old_mpe = old_mpe;
      start_info->flags = flags;
      start_info->params = params;
      start_info->tmp = tmp;
      start_info->oldResetContinueCount = call->resetContinueCount;

      call->continueCount = call->resetContinueCount;

      start_info->done_with_func = FRAME;

      callFunction(call,
#                  if JSE_NAMED_PARAMS==1
                     (uword16)((flags & SE_NAMED_PARAMS)?(uword16)(-1):(uword16)origdepth),
#                  else
                     (uword16)origdepth,
#                  endif
                   (flags&SE_CONSTRUCTOR)!=0,
                   &scopes
                   );

      /* In this case, all pushes are parameters to the 'callFunction'.
       * the first push to save the global is hanging around to be
       * popped when seExec() sees this being completed.
       */
      return TRUE;
   }
   else
   {
      /* previous code could have caused GC, so force it here */
      ALWAYS_COLLECT(call)
      call->continueCount = call->resetContinueCount;
      callFunctionFully(call,
#        if JSE_NAMED_PARAMS==1
            (uword16)((flags & SE_NAMED_PARAMS)?(uword16)(-1):(uword16)origdepth),
#        else
            (uword16)origdepth,
#        endif
         (flags & SE_CONSTRUCTOR) != 0,
         &scopes
         );
      /* don't use the return, discard it */
      STACK_POP;

      call->Global->call_func_mark = call_func_mark_save;

      /* Unlike SE440, by-ref args need no special 'copy-back', the
       * arguments object will be properly updated.
       */

      ret = !CALL_ERROR(call);

      /* Report error if one and asked to
       */
      if( !ret && (flags & SE_REPORT_ERRORS)!=0 )
      {
         /* error deliberately trapped above, else we will get confused
          * by the stuff that has called on us, when we shouldn't -
          * if we are inside a try/catch block, that is irrelevent because
          * we are called by an API who gets to specify whether or not
          * trapping should occur.
          *
          * In this case, we must print the error.
          */
         call->mustPrintError = True;
         callPrintError(call);
         CALL_SET_NORMAL(call);
      }

      call->mustPrintError = old_mpe;

      /* All other pushes eaten as parameters to the function call
       */
      if( params!=NULL && params->global!=NULL )
      {
         HSEOBJECT_ASSIGN(CALL_GLOBAL(call),SEVAR_GET_OBJECT(tmp));
         STACK_POP;
      }

      return ret;
   }

 fail:

   if( params!=NULL && params->global!=NULL )
   {
      SEASSERT( pushes>=1 );
      HSEOBJECT_ASSIGN(CALL_GLOBAL(call),SEVAR_GET_OBJECT(tmp));
   }

   STACK_POPX(pushes);
   return FALSE;
}

#if JSE_MAIN_ARGC_ARGV!=0
   static void JSE_NEAR_CALL
ParseSourceTextIntoArgv(struct seCall *call,
                        seconstcharptr rSourceText,
                        uint *_argc, secharptr **_argv)
{
   uint argc = *_argc;
   secharptr *argv = *_argv;
   secharptr endcp; secharptr cp;
   secharptr TooFar;
   sechar tmpChar;
   secharptr SourceText = secoreStrdup(call,rSourceText);


   if( SourceText==NULL )
   {
      *_argv = NULL;
      return;
   }

   RemoveWhitespaceFromHeadAndTail(SourceText);
   cp = SourceText;
   TooFar = (secharptr)((char *)cp + bytestrlen_sechar(cp));
   if ( '\0' != SECHARPTR_GETC(cp) )
   {
      SEASSERT( !IS_SAMELINE_WHITESPACE(SECHARPTR_GETC(cp)) );
      while ( TooFar != cp )
      {
         size_t len;
         secharptr *new_argv;

         new_argv = (secharptr *)secoreAllocEx(call,argv,(++argc),sizeof(secharptr),NULL,SE_DEFAULT);

         if( new_argv!=NULL )
         {
            argv = new_argv;
         }
         else
         {
            secoreFree(call,argv);
            *_argv = NULL;
            return;
         }

         /* cp is start of argument, move endcp to the end, including any
          * quotes along the way
          */
         SEASSERT( cp < TooFar  &&  SECHARPTR_GETC(cp)  &&  !IS_SAMELINE_WHITESPACE(SECHARPTR_GETC(cp)) );
         for ( endcp = cp;
               endcp != TooFar && !IS_SAMELINE_WHITESPACE(tmpChar=SECHARPTR_GETC(endcp));
             )
         {
            if ( '\"' == tmpChar )
            {
               int quoteLen;
               SEASSERT( sizeof_sechar('\"') == sizeof(secharptrdatum) );
               quoteLen = sizeof(secharptrdatum);
               /* eat-up this quote, then find matching quote */
               TooFar = (secharptr)((char *)TooFar - quoteLen);
               memmove(endcp,(char *)endcp+quoteLen,
                       (size_t)((char *)TooFar - (char *)endcp));
               SECHARPTR_PUTC(TooFar,'\0');
               if ( NULL == (endcp = strchr_sechar(endcp,'\"'))  ||  TooFar < endcp )
               {
                  endcp = TooFar;
               }
               else
               {
                  /* remove ending quote */
                  TooFar = (secharptr)((char *)TooFar - quoteLen);
                  memmove(endcp,(char *)endcp+quoteLen,
                          (size_t)((char *)TooFar - (char *)endcp));
                  SECHARPTR_PUTC(TooFar,'\0');
               }
            }
            else
            {
               SECHARPTR_INC(endcp);
            } /* endif */
         } /* endfor */
         /* len is used number of bytes, not number of characters */
         len = (size_t)((char *)endcp-(char *)cp);
         SEASSERT( sizeof_sechar('\0') == sizeof(secharptrdatum) );
         argv[argc-1] = (secharptr)secoreAllocEx(call,NULL,len+sizeof(secharptrdatum),1,NULL,SE_DEFAULT);

         if( argv[argc-1]==NULL )
         {
            uint i;

            for( i=0;i<argc-1;i++ )
               secoreFree(call,argv[i]);
            secoreFree(call,argv);

            *argv = NULL;
            return;
         }

         memcpy(argv[argc-1],cp,len+sizeof(secharptrdatum));
         SECHARPTR_PUTC((secharptr)(((char *)(argv[argc-1]))+len),'\0');
         cp = endcp;
         SEASSERT( cp <= TooFar );
         if ( cp != TooFar )
         {
            if ( '\"' == SECHARPTR_GETC(cp) )
               SECHARPTR_INC(cp);
            while( cp != TooFar  &&  IS_SAMELINE_WHITESPACE(SECHARPTR_GETC(cp)) )
               SECHARPTR_INC(cp);
         } /* endif */
         SEASSERT( cp <= TooFar );
      } /* end while */
   } /* endif */
   *_argc = argc;
   *_argv = argv;
   secoreFree(call,SourceText);
}
#endif /* #if JSE_MAIN_ARGC_ARGV!=0 */

   static void JSE_NEAR_CALL
FreeArgv(struct seCall *call,uint argc,secharptr argv[])
{
   uint i;

   SE_UNUSED_PARAMETER(call); /* in some allocations schemes it is used, but not most */
   /* free all the argv fields and argv itself */
   for ( i = 0; i < argc; i++ ) {
      SEASSERT( NULL != argv[i] );
      secoreFree(call,argv[i]);
   }
   secoreFree(call,argv);
}


/* the stack space is found through experimentaion plus additional buffer is added for safety */
#define APPROX_STACKSPACE_PER_SEEVAL  2000

   JSECALLSEQ( sebool )
seEval(secontext se,const void *to_interpret,int interp_type,
       seconstcharptr text_args,
       seobject stack_args,
       uword32 flags,
       struct seEvalParams *params)
{
   sememcount used, i;
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   struct seCallFunctionScopes scopes;
   TIMER_SAVE
   /* We need the object referred to by the stack in order
    * to ensure it is locked from collection.
    */
   uint items_pushed = 0;
   wSEVar stackvar;
   sebool ret;
   SE_API_ENTER(call)

   stack_depth()

   seassert_is_context( call )

   if( CALL_QUIT(call) )
   {
      SE_API_RETURN(call,False)
   }

#  if JSE_STACKCHK==1
   {
#     if SE_STACK_DIRECTION == -1
      if ( (SE_POINTER_UINT)(&call)
         < ((SE_POINTER_UINT)(call->Global->Params.stack_limit) + APPROX_STACKSPACE_PER_SEEVAL) )
#     else
      if ( ((SE_POINTER_UINT)(call->Global->Params.stack_limit) - APPROX_STACKSPACE_PER_SEEVAL)
         < (SE_POINTER_UINT)(&call) )
#     endif
      {
         callQuit(call,textcoreSTACK_OVERFLOW);
         SE_API_RETURN(call,False)
      }
   }
#  endif

   TIMING(call,se);

   HSEOBJECT_INIT_ASSIGN( scopes.start, \
                          (hSEObject)( (params && params->scopestart) \
                                     ? seobjectTohSEObject(call,params->scopestart) \
                                     : hSEObjectNull ) );
   HSEOBJECT_INIT_ASSIGN( scopes.end, \
                          (hSEObject)( (params && params->scopeend) \
                                     ? seobjectTohSEObject(call,params->scopeend) \
                                     : hSEObjectNull ) );

   /* Error check that the objects are themselves a list
    * of objects.
    */
   if( hSEObjectNull != scopes.start )
   {
      used = SEOBJECT_GET(call,scopes.start,used);

      for( i=0;i<used;i++ )
      {
         wSEVar tmp = STACK_PUSH;
         sebool bad = FALSE;

         seobjGetIndexMember(call,scopes.start,i,tmp);
         if( SEVAR_GET_TYPE(tmp)!=VObject )
            bad = TRUE;
         STACK_POP;

         if( bad )
         {
            SE_API_RETURN(call,FALSE)
         }
      }
   }
   if( hSEObjectNull != scopes.end )
   {
      used = SEOBJECT_GET(call,scopes.end,used);

      for( i=0;i<used;i++ )
      {
         wSEVar tmp = STACK_PUSH;
         sebool bad = FALSE;

         seobjGetIndexMember(call,scopes.end,i,tmp);
         if( SEVAR_GET_TYPE(tmp)!=VObject )
            bad = TRUE;
         STACK_POP;

         if( bad )
         {
            SE_API_RETURN(call,FALSE)
         }
      }
   }


   /* First parse the arguments and provide them to the
    * called 'thing' as a stack.
    */
   stackvar = STACK_PUSH;  items_pushed++;
   SEVAR_INIT_UNDEFINED(stackvar);
   if( stack_args==NULL )
   {
      SEVAR_INIT_UNORDERED_OBJECT(call,stackvar,(sememcount)-1);

      if( text_args!=NULL )
      {
         uint argc;
         secharptr *argv;
         hSEObject args;
         wSEVar tmp;

         /* determine all the argv and argc parameter for source
          * (always at least 1)
          */
         argv = (secharptr *)secoreAlloc(call,NULL,sizeof(secharptr),SE_DEFAULT);

         if( argv==NULL )
         {
            SEASSERT( items_pushed == 1 );
            STACK_POP;
            SE_API_RETURN(call,FALSE)
         }

         argc = 0;

#        if JSE_MAIN_ARGC_ARGV==1
            ParseSourceTextIntoArgv(call,text_args,&argc,&argv);
            if( argv==NULL )
            {
               SEASSERT( items_pushed == 1 );
               STACK_POP;
               SE_API_RETURN(call,FALSE)
            }
#        endif
         HSEOBJECT_BRUTE_ASSIGN(args,SEVAR_GET_OBJECT(stackvar));
         tmp = STACK_PUSH;
         SEVAR_INIT_UNDEFINED(tmp);
         for( i=0;i<(sememcount)argc;i++ )
         {
            SEVAR_INIT_STR(call,tmp,argv[i],SIS_CALC_SECHAR,SIS_CALC_SECHAR);
            seobjCreateMemberCopy(call,args,SE_NO_VARNAME,tmp,SE_GF_DEFAULT);
         }
         STACK_POP;
         FreeArgv(call,argc,argv);
      }
      ELSE_ALWAYS_COLLECT(call)
   }
   else
   {
      seassert_is_object(stack_args);
      SEVAR_INIT_OBJECT(stackvar,seobjectTohSEObject(call,stack_args));
   }

   /* Calling a function versus doing a text/bytecode
    * interpret is somewhat different, each in their own
    * section.
    */
   if( interp_type==SE_FUNC )
   {
      CALL_UNSET_PRESERVE_RETURN(call); /* will want func to change return_var */
      ret = seEvalFunc(call,(seobject)to_interpret,
                       SEVAR_GET_OBJECT(stackvar),
                       flags,
                       params);
   }
   else
   {
      seconstcharptr OriginalSourceFile = NULL;
      seconstcharptr OriginalSourceText = NULL;
      const void *PreTokenizedSource = NULL;
      seEvalSettings settings = SE_DEFAULT;
      int HowToInterpret = 0;
      struct seCall *newc;
      wSEVar tmp = NULL;


      if( interp_type==SE_PRECOMP )
      {
#        if JSE_TOKENDST==1
            PreTokenizedSource = (void *)to_interpret;
#        else
            /* NYI: resource-ify this */
            seThrow(se,UNISTR("You cannot use precompiled tokens without defining JSE_TOKENDST"));
            SEASSERT( items_pushed == 1 );
            STACK_POP;
            SE_API_RETURN(call,FALSE)
#        endif
      }
      else if( interp_type==SE_FILE )
      {
         OriginalSourceFile = (secharptr)to_interpret;
      }
      else
      {
         SEASSERT( interp_type==SE_TEXT );
         OriginalSourceText = (secharptr)to_interpret;
      }


      /* figure out the two settings from the params
       * and flags
       */
      if( flags&SE_NO_INHERIT )
      {
         settings = (SE_ALL_NEW & ~(SE_EXIT_LEVEL|SE_NEW_DEFINES))|SE_NO_INHERIT;
         HowToInterpret |= JSE_INTERPRET_NO_INHERIT;
      }
      if( (flags&SE_NO_LIBRARIES) && (flags&SE_NO_INHERIT) )
      {
         settings |= SE_NO_LIBRARIES;
      }
      if( flags&SE_NEW_GLOBALS )
      {
         settings |= SE_NEW_GLOBALS;
      }
      if( flags&SE_CALL_MAIN )
      {
         HowToInterpret |= JSE_INTERPRET_CALL_MAIN;
      }
      if( flags&SE_EXIT_LEVEL )
      {
         settings |= SE_EXIT_LEVEL;
      }
      if( flags&SE_NEW_DEFINES )
      {
         settings |= SE_NEW_DEFINES;
      }
      if( flags&SE_NO_OLD_DEFINES )
      {
         settings |= SE_NO_OLD_DEFINES|SE_NEW_DEFINES;
      }
      if( (flags&SE_REPORT_ERRORS)==0 )
      {
         HowToInterpret |= JSE_INTERPRET_TRAP_ERRORS;
      }
      if( flags & SE_INFREQUENT_CONT )
      {
         HowToInterpret |= JSE_INTERPRET_INFREQUENT_CONT;
      }
      if( flags & SE_FUNCS_ONLY )
      {
         HowToInterpret |= JSE_INTERPRET_FUNCS_ONLY;
      }
      if ( flags & SE_INIT_IMPLICIT_THIS )
      {
         HowToInterpret |= JSE_INTERPRET_IMPLICIT_THIS;
      }
      if ( flags & SE_INIT_IMPLICIT_PARENTS )
      {
         HowToInterpret |= JSE_INTERPRET_IMPLICIT_PARENTS;
      }

      if( params!=NULL && params->global!=NULL )
      {
         /* Don't make it create a new global object; we are setting it. */
         settings &= (seEvalSettings)~SE_NEW_GLOBALS;
         tmp = STACK_PUSH;   items_pushed++;
         SEVAR_INIT_OBJECT(tmp,CALL_GLOBAL(call));
         seassert_is_object(params->global);
         HSEOBJECT_ASSIGN(CALL_GLOBAL(call),seobjectTohSEObject(call,params->global));
      }


#     if JSE_SECUREJSE==1
         /* Security is read and initialized when the interpret
          * is started. Therefore, we don't have to remember
          * the old values and replace them.
          */
         if ( params )
         {
            memcpy(call->Global->security,&(params->security_object),sizeof(call->Global->security));
            /* verify that orders of structures or alignments are not off */
            SEASSERT( call->Global->security[SECURITY_OBJ_VARIABLE] == params->security_object );
            SEASSERT( call->Global->security[SECURITY_OBJ_GUARD] == params->security_guard );
            SEASSERT( call->Global->security[SECURITY_OBJ_INIT] == params->security_init );
            SEASSERT( call->Global->security[SECURITY_OBJ_TERM] == params->security_term );
         }
         else
         {
            memset(call->Global->security,0,sizeof(call->Global->security));
#           ifndef SE_RELEASE_BUILD
            {
               uint j;
               for ( j = 0; j < SECURITY_OBJ_COUNT; j++ )
               {
                  SEASSERT( call->Global->security[j] == NULL );
               }
            }
#        endif
      }
#     endif

      CALL_SET_NORMAL(call);

      SEASSERT( SEVAR_GET_TYPE(stackvar)==VObject );


      newc = interpretInit(call,OriginalSourceFile,OriginalSourceText,
               PreTokenizedSource,settings,
               HowToInterpret,SEVAR_GET_OBJECT(stackvar),
               &scopes,
               (hSEObject)((params && params->default_this)?seobjectTohSEObject(call,params->default_this):hSEObjectNull),
               (params)?params->filename:NULL,
               (params)?params->line_num:0
               );
      if( newc!=NULL )
      {
         newc->params = params;

         if( flags&SE_START )
         {
            ret = TRUE;
         }
         else
         {
#           if JSE_COMPILER==1
               uint compilingSave;
#           endif

            /* This is a really ugly hack which is meant to preserve the compilation state.
             * Because we may actually do an interpret() within a compilation (as with our
             * binary object files), we want to make sure that the interpret doesn't think
             * we're still compiling files, because we're not.  Well, sort of.
             */
#           if JSE_COMPILER==1
               compilingSave = call->Global->CompileStatus.NowCompiling;
               call->Global->CompileStatus.NowCompiling = 0;
#           endif

            /* remain in loop calling statement after statement, even if the
             * level of function changes.
             */
            SEASSERT( 0 == newc->in_secodeInterpret );
            newc->in_secodeInterpret++;
            while( secodeInterpret(newc,False,False) )
               ;
            newc->in_secodeInterpret--;
            SEASSERT( 0 == newc->in_secodeInterpret );

            interpretTerm(newc);
#           if JSE_COMPILER==1
               call->Global->CompileStatus.NowCompiling = compilingSave;
#           endif

            /* it only fails on error, exiting is ok */
            ret = !CALL_ERROR(call);
         }
      }
      else
      {
         ret = FALSE;
      }

      /* if using SE_START, that extra item is buried beneath the
       * new info thrown on the stack and we cannot delete it
       * until the start has ended.
       */
      if( (flags&SE_START)==0 && params!=NULL && params->global!=NULL )
      {
         HSEOBJECT_ASSIGN(CALL_GLOBAL(call),SEVAR_GET_OBJECT(tmp));
         SEASSERT( items_pushed != 0 );
         items_pushed--;
         STACK_POP;
      }
   }

   END_TIMING(call);

   if( (flags&SE_REPORT_ERRORS) && CALL_ERROR(call) )
      CALL_SET_NORMAL(call);

   if( !ret || 0==(flags&SE_START) )
   {
      STACK_POPX(items_pushed);;
      CALL_SET_PRESERVE_RETURN(call); /* will want to return retrn_var in SE_RETURN */
   }
#  if !defined(SE_RELEASE_BUILD)
   else
   if ( ret  &&  0!=(flags&SE_START) )
   {
      /* this is one of a couple of cases where an API function is
       * allowed to leave with the stack at a different depth, becaues
       * a function may have started but not ended.
       */
      SEASSERT( ret  &&  0!=(flags&SE_START) );
      dbg_top_of_stack=STACK0;
   }
#  endif

   SE_API_RETURN(call,ret)
}


   JSECALLSEQ( sebool )
seExec(secontext se)
{
   struct seCall * call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   sebool ret;

   TIMING(call,se);

   seassert_is_context( call )

   /* if yield flag was set then this first call to seExec automatically clears it */
   if ( 0 != (call->state & StateYield) )
   {
      if ( 0 != (call->state & StateSorYInWrapper) )
      {
         /* top of stack is for return value from the wrapper function that yielded */
         SEASSERT(call->suspend_restore_loc != NULL);

         /* Copy the return var to the place on the stack where
          * the suspending wrapper function put its return value.
          * This lets the API user change the return value before
          * un-suspending the context
          */
         SEVAR_COPY(call->suspend_restore_loc,&(call->return_var));
      }
      call->state &= (uword8)~(StateYield|StateSorYInWrapper);
   }

   call->continueCount = call->resetContinueCount;

   if( call->start_info != NULL )
   {
      /* We are inside a function SE_START, use it to check for
       * completion
       */
      struct evalFuncStart *info;

      while ( call->start_info->done_with_func!=FRAME )
      {
         SEASSERT( 0 == call->in_secodeInterpret );
         call->in_secodeInterpret++;
         secodeInterpret(call,True,True);
         call->in_secodeInterpret--;
         SEASSERT( 0 == call->in_secodeInterpret );

         /* if this returned because of continueCount being reset then return from seExec, else continue */
         if ( call->continueCount == call->resetContinueCount )
            return True;
      }
      call->resetContinueCount = call->start_info->oldResetContinueCount;

      call->Global->call_func_mark = call->start_info->call_func_mark_save;

      /* Report error if one and asked to
       */
      if( CALL_ERROR(call) && (call->start_info->flags & SE_REPORT_ERRORS)!=0 )
      {
         /* error deliberately trapped above, else we will get confused
          * by the stuff that has called on us, when we shouldn't -
          * if we are inside a try/catch block, that is irrelevent because
          * we are called by an API who gets to specify whether or not
          * trapping should occur.
          *
          * In this case, we must print the error.
          */
         call->mustPrintError = True;
         callPrintError(call);
         CALL_SET_NORMAL(call);
      }

      call->mustPrintError = call->start_info->old_mpe;

      if( call->start_info->params!=NULL && call->start_info->params->global!=NULL )
      {
         HSEOBJECT_ASSIGN(CALL_GLOBAL(call),SEVAR_GET_OBJECT(call->start_info->tmp));
         STACK_POP;
      }

      /* free args allocated in seEval */
      STACK_POP;

      info = call->start_info;
      call->start_info = info->next;
      secoreFree(call,info);

      ret = FALSE;
   }
   else
   {
      SEASSERT( 0 == call->in_secodeInterpret );
      call->in_secodeInterpret++;
      ret = secodeInterpret(call,False,True);
      call->in_secodeInterpret--;
      SEASSERT( 0 == call->in_secodeInterpret );

      if( !ret )
      {
         sebool need_to_restore = call->params!=NULL && call->params->global!=NULL;

         interpretTerm(call);

         /* we just termed new call, need to restore in old call
          */
         call = CALL_FROM_JSECONTEXT(se);

         /* No need to check SE_START - we are in seExec() which
          * is only used in conjunction with SE_START.
          */
         if( need_to_restore )
         {

            HSEOBJECT_ASSIGN(CALL_GLOBAL(call),SEVAR_GET_OBJECT(STACK0));
            STACK_POP;
         }

         STACK_POP;
      }
   }
   if ( !ret )
   {
      CALL_SET_PRESERVE_RETURN(call); /* will want to return retrn_var in SE_RETURN */
   }
   END_TIMING(call);
   return ret;
}


   JSECALLSEQ( void )
seEnd(secontext se)
{
   struct seCall * call = CALL_FROM_JSECONTEXT(se);
   sebool need_to_restore = call->params!=NULL && call->params->global!=NULL;
   sebool disregard = False;
   TIMER_SAVE

   TIMING(call,se);

   /* If not a NULL frame, more code to execute, in which case
    * this is an 'abort', so disregard the return value.
    */
   if( FRAME!=NULL ) disregard = True;

   if( call->start_info!=NULL )
   {
      struct evalFuncStart *info;

      while( call->start_info->done_with_func!=FRAME )
      {
         callReturnFromFunction(call,SE_DEFAULT);
      }

      call->resetContinueCount = call->start_info->oldResetContinueCount;

      call->Global->call_func_mark = call->start_info->call_func_mark_save;

      call->mustPrintError = call->start_info->old_mpe;

      if( call->start_info->params!=NULL && call->start_info->params->global!=NULL )
      {
         HSEOBJECT_ASSIGN(CALL_GLOBAL(call),SEVAR_GET_OBJECT(call->start_info->tmp));
         STACK_POP;
      }

      /* free args allocated in seEval */
      STACK_POP;

      info = call->start_info;
      call->start_info = info->next;
      secoreFree(call,info);
   }
   else
   {
      STACK_POP;

      /* The return will be copied from the call back to its
       * parent, just as the return for this function needs.
       */
      call = interpretTerm(call);

      if( need_to_restore )
      {
         /* No need to check SE_START - we are in seExec() which
          * is only used in conjunction with SE_START.
          */
         if( need_to_restore )
         {
            /* we just termed new call, need to restore in old call
             */
            call = CALL_FROM_JSECONTEXT(se);

            HSEOBJECT_ASSIGN(CALL_GLOBAL(call),SEVAR_GET_OBJECT(STACK0));
            STACK_POP;
         }
      }
   }

   if( disregard )
   {
      /* In the case of an abort, any return is garbage */
      CALL_SET_NORMAL(call);
      SEVAR_INIT_UNDEFINED(&(call->return_var));
   }

   CALL_SET_PRESERVE_RETURN(call); /* will want to return retrn_var in SE_RETURN */

   END_TIMING(call);
}

#endif /* #if JSE_COMPILER_SEGMENT==1 */


#if JSE_UTIL_SEGMENT==1

   JSECALLSEQ( void )
seThrow(secontext se,seconstcharptr message,...)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   va_list arglist;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( message!=NULL );

   va_start(arglist,message);
   ErrorVPrintf(call,message,arglist);
   va_end(arglist);

   END_TIMING(call);
   SE_API_RETURN_VOID(call)
}

   JSECALLSEQ( void )
seGarbageCollect(secontext se,int action)
{
   struct seCall * call = CALL_FROM_JSECONTEXT(se);
   struct seGlobal_ * global = call->Global;
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )

#  if JSE_GC==1
   if ( SE_GARBAGE_COLLECT == action )
   {
      uword16 save_collect_disable = global->collect_disable;
      global->collect_disable = 0;
      secoreGarbageCollect(call);
      global->collect_disable += save_collect_disable;
   } else
   if ( SE_GARBAGE_OFF == action )
   {
      global->collect_disable++;
   } else
   if ( SE_GARBAGE_ON == action )
   {
      global->collect_disable--;
   } else
#  endif
#  if SE_ANALYZER==1
   if ( SE_COLLECT_AND_ANALYZE == action )
   {
      seInternalAnalysis(call);
   } else
#  endif
   if ( SE_COLLECT_AND_MINIMIZE == action )
   {
      /* set when we do not want the garbage collecter to refill pools */
#     if JSE_GC==1
      sebool refill_flag;

      refill_flag = global->flags & collect_do_not_refill;
      if ( 0 == refill_flag )
         global->flags |= collect_do_not_refill;
      secoreGarbageCollect(call);
#     endif
      seEmptyPools(call);
#     if JSE_GC==1
      if ( 0 == refill_flag )
         global->flags &= (uword8)~collect_do_not_refill;
#     endif
   }

   END_TIMING(call);
   SE_API_RETURN_VOID(call)
}

#if JSE_BREAKPOINT_TEST==1
   JSECALLSEQ( sebool )
seIsBreakpoint(secontext se,seconstcharptr filename,uint lineNumber)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   sebool ret;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( filename!=NULL );

   ret = callBreakpointTest(call,CALL_GLOBAL(call),filename,lineNumber,1);

   END_TIMING(call);

   SE_API_RETURN(call,ret)
}
#endif /* #if JSE_BREAKPOINT_TEST==1 */

/* Internalized string routines */


   JSECALLSEQ( sestring )
seInternalizeStringEx(secontext se,seconstcharptr str,sememcount len,int flags)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   sestring ret;
   sestringLenType vn_len;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( str!=NULL );

   vn_len = ( len == SE_IS_STRLEN ) ? CVN_USE_STRLEN : (sestringLenType)len ;

   /* What's wrong with internalizing ""? */
   /* SEASSERT( len>0 ); */

   ret = CreateSEVarName(call,str,vn_len,(sebool)flags);

   END_TIMING(call);

   SE_API_RETURN(call,ret)
}

   JSECALLSEQ( void )
seFreeInternalString(secontext se,sestring str)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   seassert_is_varname( str )

   SE_UNUSED_PARAMETER(call);

   RemoveSEVarNameLock(str);

   END_TIMING(call);
   SE_API_RETURN_VOID(call)
}


   JSECALLSEQ( sestring )
seCloneInternalString(secontext se,sestring origstr)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   seassert_is_varname( origstr )
   SE_UNUSED_PARAMETER(call);

   AddSEVarNameLock(origstr);

   END_TIMING(call);

   SE_API_RETURN(call,origstr)
}

   JSECALLSEQ( seconstcharptr )
#if JSE_TRACKVARS==0 || SE_GETINTERNALSTRING_NO_LIFETIME==1
seGetInternalString(secontext se,sestring str,sememcount *len)
#else
seGetInternalStringDbg(secontext se,sestring str,sememcount *len,seassert_filetype file,int line)
#endif
{
#if SE_GETINTERNALSTRING_NO_LIFETIME==0
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   seconstcharptr ret;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   seassert_is_varname( str )

   ret = seTempLockString(call,(const t_sememdata)str,seLOCKSTR__AS_NAME,len,True  PASS_FILE_AND_LINE_PARMS );

   END_TIMING(call);

   SE_API_RETURN(call,ret)
#else
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   seconstcharptr ret SE_UNUSED_INITIALIZER(NULL);
   sestringLenType sLen;
   SE_API_ENTER(call)

   TIMING(call,se);

   seassert_is_context( call )
   seassert_is_varname( str )

   /* Note, SE_POINTER_UINDEX and stringLengthType can be different
    * so cannot merge the call
    */
   ret = GetSEStringTableEntry(call,str,&sLen);
   if( len )
      *len = (sememcount)sLen;

   END_TIMING(call);

   SE_API_RETURN(call,ret)
#endif
}


#if JSE_TOKENSRC==1
   JSECALLSEQ( void )
seFreeBytecodes_(secontext se,ubyte *codes)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   TIMER_SAVE
   SE_API_ENTER(call)

   SE_UNUSED_PARAMETER(call);

   TIMING(call,se);

   seassert_is_context( call )
   SEASSERT( codes!=NULL );

   secoreFree(call,codes);

   END_TIMING(call);
   SE_API_RETURN_VOID(call)
}
#endif /* #if JSE_TOKENSRC==1 */


   JSECALLSEQ( void )
sePrepareContext(secontext se)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   SE_API_ENTER(call)

   if( call && call->Global->Params.sePrepareContextFunc!=NULL )
   {
#  if (defined(__JSE_WIN16__) || defined(__JSE_DOS16__)) && \
      (defined(__JSE_DLLLOAD__) || defined(__JSE_DLLRUN__))
      DispatchToClient(call->Global->ExternalDataSegment,
                       (ClientFunction)(call->Global->Params.sePrepareContextFunc),
                       (void *)JSECONTEXT_FROM_CALL(call));
#  else
      (*(call->Global->Params.sePrepareContextFunc))(JSECONTEXT_FROM_CALL(call));
#  endif
   }
   SE_API_RETURN_VOID(call)
}

/* Cannot be inlined due to different compilers handling
 * macro arguments differently. Some thing that a macro
 * (even one that resolves to a comma-separated list) as
 * a parameter is passed along as one parameter (cough, MSVC).
 * Others correctly do the entire substitution then rescan
 * the line and find a new macro invocation with multiple
 * parameters.
 */
   JSECALLSEQ( void )
seStoreMember(struct seMemberDesc *desc,int type,t_sememdata memdata)
{
   desc->type = type;
   desc->memdata = memdata;
}
#endif /* #if JSE_UTIL_SEGMENT==1 */

#if JSE_COMPILER_SEGMENT==1
   JSECALLSEQ(void *)
#if JSE_MEM_DEBUG==1
seGCAllocDbg
#else
seGCAlloc
#endif
(secontext se,void *old_pointer,sememcount size
#           if JSE_MEM_DEBUG==1
               ,seassert_filetype file,uint line
#           endif
)
{
   if ( NULL != se )
   {
      struct seCall *call = CALL_FROM_JSECONTEXT(se);
      return secore_Alloc(call,old_pointer,size,SE_DEFAULT
#                         if JSE_MEM_DEBUG==1
                             ,file,line
#                         endif
                          );
   }
   else
   {
#     if JSE_MEM_DEBUG==1
#        if defined(__JSE_PALMOS__)
            /* palm mem-debug is very tricky and requires that call != NULL */
            SEASSERT( False );
            return NULL;
#        else
            return jseUtilReMalloc(NULL,old_pointer,size,line,file);
#        endif
#     else
         return jseReMalloc(void,NULL,old_pointer,size);
#     endif
   }
}

   JSECALLSEQ(void *)
#if JSE_MEM_DEBUG==1
seGCAllocExDbg
#else
seGCAllocEx
#endif
(secontext se,void *old_pointer,size_t num_elem,int size_elem,sememcount *result_num_elem,int flags
#           if JSE_MEM_DEBUG==1
               ,seassert_filetype file,uint line
#           endif
)
{
   struct seCall *call;

   SEASSERT( NULL != se );

   call = CALL_FROM_JSECONTEXT(se);
   return secore_Alloc_Ex(call,old_pointer,num_elem,size_elem,result_num_elem,flags
#                         if JSE_MEM_DEBUG==1
                             ,file,line
#                         endif
                          );
}

   JSECALLSEQ(secharptr)
#if JSE_MEM_DEBUG==1
seGCStrdupDbg(secontext se,seconstcharptr orig,uint line,seassert_filetype file)
#else
seGCStrdup(secontext se,seconstcharptr orig)
#endif
{
   if( se!=NULL )
   {
      struct seCall *call = CALL_FROM_JSECONTEXT(se);
#     if JSE_MEM_DEBUG==1
         return secoreStrdupDbg(call,orig,file,line);
#     else
         return secoreStrdup(call,orig);
#     endif
   }
   else
   {
#     if JSE_MEM_DEBUG==1
         return seGCStrndupDbg(se,orig,strlen_sechar(orig),line,file);
#     else
         return seGCStrndup(se,orig,strlen_sechar(orig));
#     endif
   }
}


   JSECALLSEQ(secharptr)
#if JSE_MEM_DEBUG==1
seGCStrndupDbg(secontext se,seconstcharptr orig,size_t len,uint line,seassert_filetype file)
#else
seGCStrndup(secontext se,seconstcharptr orig,size_t len)
#endif
{
   if( se!=NULL )
   {
      struct seCall *call = CALL_FROM_JSECONTEXT(se);
#     if JSE_MEM_DEBUG==1
         return secoreStrndupDbg(call,orig,len,file,line);
#     else
         return secoreStrndup(call,orig,len);
#     endif
   }
   else
   {
      size_t _size = BYTECOUNT_FROM_STRLEN(orig,len);
      secharptr ret;

      SEASSERT( sizeof(secharptrdatum) == sizeof_sechar('\0') );
#     if JSE_MEM_DEBUG==1
#        if defined(__JSE_PALMOS__)
            /* palm mem-debug is very tricky and requires that call != NULL */
            SEASSERT( False );
            ret = NULL;
#        else
            ret = jseUtilMalloc(NULL,_size+sizeof(secharptrdatum),line,file);
#        endif
#     else
         ret = jseMalloc(secharptrdatum,NULL,_size+sizeof(secharptrdatum));
#     endif
      if ( NULL != ret )
      {
         memcpy(ret,orig,_size);
         *((secharptrdatum *)(((ubyte *)ret)+_size)) = 0;
      }
      return ret;
   }
}


   JSECALLSEQ(void)
seGCFree(secontext se,void *item)
{
   if( NULL != se )
   {
      secoreFree(CALL_FROM_JSECONTEXT(se),item);
   }
   else
   {
#     if JSE_MEM_DEBUG==1 && defined(__JSE_PALMOS__)
         /* palm mem-debug is very tricky and requires that call != NULL */
         SEASSERT( False );
#     else
         jseFree(NULL,item);
#     endif
   }
}
#endif /* #if JSE_COMPILER_SEGMENT==1 */

#if JSE_TOKENSRC==1  &&  JSE_COMPILER_SEGMENT==1
/* NYI: add eval params solely for the alternate filename/linenumber.
 * change CompileIntoTokens to take them so it can pass it along
 * to CompileFromText
 */
   JSECALLSEQ( ubyte * )
sePrecompile(secontext se,const void *to_interpret,int interp_type,
             sememcount *len,
             struct seEvalParams *params)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   struct seCall *newCall;
   void *ret;
   sememcount buflen;
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);

#  if JSE_EXECUTE_SEGMENT==0
      newCall = call;   /* if not executing, then only need top-level call */
#  else
      newCall = callInterpret(call,SE_NEW_GLOBALS,True,False);
#  endif

   if( newCall==NULL )
   {
      ret = NULL;
   }
   else
   {
      ret = CompileIntoTokens(newCall,to_interpret,interp_type==SE_FILE,&buflen,
                              (params)?params->filename:NULL,
                              (params)?params->line_num:0);

      if( len ) *len = (sememcount)buflen;

#     if JSE_EXECUTE_SEGMENT==1
         callDelete(newCall);
#     endif
   }

   END_TIMING(call);

   SE_API_RETURN(call,(ubyte *)ret)
}
#endif /* #if JSE_TOKENSRC==1  &&  JSE_COMPILER_SEGMENT==1 */


#if SE_SHARED_OBJECTS==1
#if JSE_EXECUTE_SEGMENT==1

   static void JSE_NEAR_CALL
moveStringToReadShared(struct seCall *call,struct _seString *str)
{
   if ( (str->flags&SESTR_SHARED) == 0 )
   {
      struct _seString **loop;
      for( loop=&(call->Global->stringdatas);(*loop)!=str;loop = &((*loop)->prev) )
      {
         SEASSERT( (*loop)->prev!=NULL );
      }

      (*loop) = (*loop)->prev;

      str->prev = se_all_strings;
      se_all_strings = str;

      str->flags |= SESTR_SHARED;
   }
}

   static void JSE_NEAR_CALL
moveFunctionToReadShared(struct seCall *call,struct seFunction *func)
{
   if( func!=NULL && (func->flags&Func_Shared)==0 )
   {
      struct seFunction **loop;
      for( loop=&(call->Global->funcs);*loop!=func;loop = &((*loop)->next) )
      {
         SEASSERT( *loop!=NULL );
      }

      *loop = (*loop)->next;

      func->next = se_all_funcs;
      se_all_funcs = func;

      func->flags |= Func_Shared;

#     if JSE_MULTIPLE_GLOBAL==1
         if( hSEObjectNull != func->hglobal_object )
         {
            moveObjectToReadShared(call,func->hglobal_object);
         }
#     endif

      if ( FUNCTION_IS_LOCAL(func) )
      {
         struct LocalFunction *lfunc = (struct LocalFunction *)func;
         uword16 li;

         if ( hSEObjectNull != lfunc->hConstants )
         {
            moveObjectToReadShared(call,lfunc->hConstants);
         }

         moveSEVarNameToReadShared(call,lfunc->FunctionName);

         for ( li = 0; li < lfunc->localItems.used; li++ )
         {
            moveSEVarNameToReadShared(call,lfunc->localItems.items[li].varName);
         }
      }
   }
}

/* Currently, this routine cannot fail (it only updates existing
 * structures), but I've left a boolean return for possible
 * future changes.
 */
   static sebool JSE_NEAR_CALL
moveObjectToReadShared(struct seCall *call,hSEObject hobj)
{
   struct seGlobal_ * global;
   objflag flag = SEOBJECT_GET(call,hobj,flag);
   hSEMembers hmems;
   sememcount i,used;
   hSEObject loop;

   /* If already shared, all done */
   if( (flag&SEOBJ_SHARED)!=0 )
      return TRUE;

   global = call->Global;

   flag |= SEOBJ_SHARED|SEOBJ_READ_ONLY;
   SEOBJECT_PUT(call,hobj,flag,flag);

   /* Move object from context list of objects to global
    * list of objects.
    */
   loop = global->all_hobjs;

   if( loop==hobj )
   {
      global->all_hobjs = SEOBJECT_GET(call,hobj,hNext);
   }
   else
   {
      while( SEOBJECT_GET(call,loop,hNext)!=hobj )
      {
         /* should be in the list */
         SEASSERT( loop->hNext!=NULL );

         loop = SEOBJECT_GET(call,loop,hNext);
      }

      SEOBJECT_PUT(call,loop,hNext,SEOBJECT_GET(call,hobj,hNext));
   }

   SEOBJECT_PUT(call,hobj,hNext,se_all_hobjs);
   se_all_hobjs = hobj;

   /* Iterate members marking each as read-only and don't
    * delete. If member is a string, func, or object
    * move and mark it. For all members names and varnames
    * in the object members, mark those and move them to the
    * table.
    */

   used = SEOBJECT_GET(call,hobj,used);

   for( i=0;i<used;i++ )
   {
      wSEVar tmp;
      rSEVar var;

      /* Done so that compact libfuncs will be expanded. */
      tmp = STACK_PUSH;
      SEVAR_INIT_UNDEFINED(tmp);
      seobjGetIndexMember(call,hobj,i,tmp);
      STACK_POP;

      /* big recursive routine, can definitely change */
      hmems = SEOBJECT_GET(call,hobj,hsemembers);

      moveSEVarNameToReadShared(call,SEMEMBERS_GET(call,hmems,i,name));

      SEMEMBERS_PUT(call,hmems,i,attributes,
                    (uword8)(SEMEMBERS_GET(call,hmems,i,attributes)|SE_READONLY|SE_DONTDELETE));


      var = SEMEMBERS_GET_sevar(call,hmems,i);

      switch( (var)->type )
      {
         case VString:
            if( (var->data.string_val->flags&SESTR_SHARED)==0 )
               moveStringToReadShared(call,var->data.string_val);
            break;
         case VObject:
            if( hSEObjectNull!=SEVAR_GET_OBJECT(var) )
               moveObjectToReadShared(call,SEVAR_GET_OBJECT(var));
            if( var->data.object_val.hSavedScopeChain!=hSEObjectNull )
               moveObjectToReadShared(call,var->data.object_val.hSavedScopeChain);
            break;
         case VReference:
            moveObjectToReadShared(call,var->data.ref_val.hBase);
            moveSEVarNameToReadShared(call,var->data.ref_val.reference);
            break;
         case VReferenceIndex:
            SEASSERT( var->data.ref_val.hBase!=hSEObjectNull );
            moveObjectToReadShared(call,var->data.ref_val.hBase);
            break;
      }
   }

#  if JSE_PER_OBJECT_MISS_CACHE==1
      SEOBJECT_PUT(call,hobj,miss_cache,SE_NO_VARNAME);
#  endif
   moveFunctionToReadShared(call,SEOBJECT_GET_func(call,hobj));

#  if JSE_PER_OBJECT_MISS_CACHE==1
      SEASSERT( SE_NO_VARNAME == SEOBJECT_GET(call,hobj,miss_cache) );
#  endif

   return TRUE;
}


   static void JSE_NEAR_CALL
moveObjectHandleToShared(seobject obj)
{
   SEASSERT( !IS_STOCK_OBJ(obj) );

   /* unlock it from existing area */
   if ( NULL != (obj->prev->next = obj->next) )
      obj->next->prev = obj->prev;

   /* relink it into the global one */
   obj->next = se_all_api_locks.next;
   obj->prev = &(se_all_api_locks);
   if( obj->next ) obj->next->prev = obj;
   se_all_api_locks.next = obj;
}

   JSECALLSEQ( sebool )
seShareReadObject(secontext se,seobject obj)
{
   struct seCall *call = CALL_FROM_JSECONTEXT(se);
   sebool ret = FALSE;
   TIMER_SAVE
   SE_API_ENTER(call)

   TIMING(call,se);


   if( 1 < se_context_count )
   {
      SEDBG(DebugPrintf(UNISTR("Objects can't be made shared with more than one context existing.\n")));
   }
   else
   {
      hSEObject hobj;

      if( obj!=SE_SHARED_SERVICES && IS_STOCK_OBJ(obj) )
      {
         SEDBG(DebugPrintf(UNISTR("Stock objects cannot be made shared.\n")));
      }
      else
      {
         HSEOBJECT_BRUTE_ASSIGN(hobj,seobjectTohSEObject(call,obj));

         if ( hobj != hSEObjectNull )
         {
            /* NYI: Turning off the garbage collector doesn't feel
             *      like the best solution but I'm not sure what else
             *      to do. While the objects are being transferred
             *      from normal->read, they are done top-down. I.e.
             *      an object is transferred then all of its children.
             *      This means that the children are not shared and
             *      the parent is at times when a garbage collection
             *      can go off, causing the collector to think the
             *      children are not used. There doesn't seem to be
             *      any good algorithm to transfer them bottom-up.
             */
            secoreGarbageCollect(call);
            call->Global->collect_disable++;
            if( moveObjectToReadShared(call,hobj) )
            {
               ret = TRUE;
               if( obj!=SE_SHARED_SERVICES ) moveObjectHandleToShared(obj);
            }
            call->Global->collect_disable--;
         }
      }
   }


   END_TIMING(call);

   SE_API_RETURN(call,ret)
}
#endif /* #if JSE_EXECUTE_SEGMENT==1 */
#endif /* #if SE_SHARED_OBJECTS==1 */
