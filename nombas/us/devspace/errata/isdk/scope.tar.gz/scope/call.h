/* call.h - The 'context' structure.
 */

/************************************************************************
 *  Copyright (c) 1993-2004 Anchor Acquisition, Inc., a subsidiary of   *
 *  Openwave Systems Inc. All rights reserved.                          *
 *                                                                      *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Openwave Systems Inc. *
 *    The copyright notice above does not evidence any                  *
 *    actual or intended publication of such source code.               *
 ************************************************************************/

/* The struct seCall, also known as a secontext, is the heart of
 * the ScriptEase engine. This data structure keeps track of a
 * script session. It keeps track of all memory used, all
 * variables, the current execution chain of functions, and so
 * forth. A pointer to a Call is passed to every function during
 * execution so each has access to all this needed information.
 *
 * An API application allocates one context (using the ScriptEase
 * API call 'seCreateContext') per script run simultaneously.
 * One Call can run one script at once, no more. A single context
 * cannot be used by multiple threads; if you need to run more
 * than one script at a time, initialize a new context for each
 * one.
 *
 * Note that a context keeps track of a script's execution such
 * that we can execute a line of script code, return to the user,
 * then pick up where we have left off. This is what the seExec
 * function does. However, when a wrapper function is invoked,
 * we cannot return in the middle of it since it is written in C.
 * For this reason, an invocation of a wrapper function is
 * considered one statement to seExec. If that wrapper function
 * uses seEval itself, that entire eval script must be considered
 * one statement for the same reason. Note that the wrapper
 * function itself can use SE_START and seExec, but the seExec
 * that called the wrapper function has to wait until the whole
 * wrapper function is complete.
 *
 *
 * As of SE430, nested functions are supported. The ECMA rules
 * specify that each function saves the scope chain in effect
 * when it is created to be used when it is run. This is how it
 * sees the local variables of its parent. We normally do not
 * save the global object as part of the scope chain. The global
 * object for the parent will be the same as for the child.
 * It is just implicitly understood to be part of the saved
 * scope chain. This allows the scope chain to be empty in
 * the majority of cases and be specified as just NULL. Only
 * in the case in which the global is in the 'middle' of the
 * scope chain do we explicitly save it. This happens when
 * we do child seEvals
 *
 *
 * Each call tracks one seEval invocation. If there are child
 * invocations, we end up with a chain of calls. Within an
 * seEval, many functions can be called. There is a functionSave
 * structure allocated for each such call. They too are chained
 * representing the recursive function calls currently being
 * executed. Each call also points to a Global structure. All
 * calls in the same chain have the same Global structure. It
 * keeps track of items that all calls share such as the structure
 * pools. One call chain is called a context and holds an
 * entire scripting context. Such contexts are independent, so
 * several call chains can exist at once such as in a multithreaded
 * application. In the case of fibers, each fiber is still an
 * independent call chain tracking all of the current function
 * invocations. Fibers do share the same Global among all calls
 * in any of the fibers. This allows fibers to use the same
 * memory pools and variables.
 *
 * A context (call chain) has a single runtime stack in which
 * ScriptEase variables are thrown. This stack holds parameters,
 * local variables, and temporary variables for evaluating
 * expressions. All calls in the chain share the same stack,
 * obviously sequentially stacking their information on top of
 * the information of earlier calls in the chain. If the stack
 * runs out of space, an additional stack is allocated for
 * that call in the chain and any later calls. These new calls
 * will use that stack until they are finished and clean up
 * themselves and their stack.
 */


#ifndef _SE_CALL_H
#define _SE_CALL_H

#include "extlib.h"

#if defined(__cplusplus)
extern "C"
{
#endif


#ifndef SE_RELEASE_BUILD


#endif


/* ----------------------------------------------------------------------
 * SECODE stack and manipulation functions
 * ---------------------------------------------------------------------- */

/* The stack is fixed in size and location. Since it cannot
 * move, indexes into it can be stored as direct pointers,
 * rather than having to resolve the index on each use.
 *
 * This results in faster AND smaller code
 *
 *
 * Stack space is allocated using the STACK_PUSH macro.
 * Note that the variable on the stack start uninitialized,
 * not initialized to undefined. Before any garbage collection
 * occurs, you must initialize it. When in doubt, immediately
 * use SEVAR_INIT_UNDEFINED() to initialize it.
 */


typedef struct _SEVar *STACKPTR;

#ifdef SE_RELEASE_BUILD
#  define STACK0 (call->stackptr)
#  define STACK1 (call->stackptr-1)
#  define STACK2 (call->stackptr-2)
#  define STACKX(x) (call->stackptr-(x))
#  define RESTORE_STACKPTR(call,old_ptr) (call)->stackptr = old_ptr;
#else
#  define STACK0     STACKX(0)
#  define STACK1     STACKX(1)
#  define STACK2     STACKX(2)
#  define STACKX(x)  STACKX_DEBUG(call,(x))
   struct _SEVar * STACKX_DEBUG(struct seCall *call,uint x);
   void RESTORE_STACKPTR(struct seCall *call,STACKPTR old_ptr);
#endif

#ifdef SE_RELEASE_BUILD
#  define STACK_POP (call->stackptr--)
#  define STACK_POPX(x) (call->stackptr -= (x))
#else
#  define STACK_POP     STACK_POPX(1)
#  define STACK_POPX(x) STACK_POPX_DEBUG(call,(x))

   void STACK_POPX_DEBUG(struct seCall *call,uint x);

#endif

#ifdef SE_RELEASE_BUILD
#  define STACK_PUSH (++call->stackptr)
#  define STACK_PUSHX(x) (call->stackptr+=x)
#else
   /* debug version will fill the field with garbage to catch bugs quicker */
#  define STACK_PUSH       STACK_PUSHX(1)
#  define STACK_PUSHX(x)   STACK_PUSHX_DEBUG(call,(x))

   struct _SEVar * STACK_PUSHX_DEBUG(struct seCall *call,uint x);

#endif

#define STACKBASE     (call->save.stackbase)
#define FRAME         (call->save.frameptr)
#define FRAMECALL(c)  ((c)->save.frameptr)


#define STACKPTR_SAVE(x) (x)
#define STACK_FROM_STACKPTR(x) (x)


/* STACK FRAME:
 *
 * FRAME is basically how we get at everything. This macro
 * gives the stack location from which we can get the important
 * information on the stack for the current function.
 *
 *
 *    FRAME[1]..FRAME[num_locals-1]    = local variable storage
 *    FRAME[0]..FRAME[-(num_args-1)]   = the arguments
 *    FRAME[-num_args]                 = current function variable
 *    FRAME[-num_args-1]               = current this variable
 *    FRAME[-num_args-2]..FRAME[-x]    = intermediate stuff for last function
 */

#define FUNC_OFFSET      0
#define THIS_OFFSET      1


/* ----------------------------------------------------------------------
 * functionSave structure
 * ---------------------------------------------------------------------- */

struct functionSave
{
   /* A linked list */
   struct functionSave *prev;

#  if JSE_MULTIPLE_GLOBAL==1
      /* We swap in the global saved with the function whenever
       * the function is run.
       */
      hSEObject CurrentGlobalObject;
#  endif

   struct _SEVar new_scope_chain;

   secode iptr;   /* when JSE_MEMEXT_SECODES==1 this is saved cast to ulong */

   uword16 num_args,true_args;

   hSEObject hVariableObject;

#  define FS_ISCONSTRUCTOR   0x01
#  define FS_INCALLBACK      0x02
#  define FS_DONOT_PRESERVE_RETURN 0x04
   uword8 flags;

   struct _SEVar callback_param;
   hSEObject     callback_this;

   struct _SEVar preserve_return_var; /* can preserve previous return variable */

#  if JSE_NAMED_PARAMS==1
      /* If this function has parameters passed to it by name,
       * we store those in an object with the object members
       * being the parameters by name along with their value.
       */
      hSEObject wrapper_named;
#  endif


   /* We now automatically allocate a new stack chunk when the
    * existing one runs out. This means the stack base could
    * change for any new function.
    *
    * We also save the old stackptr. It is needed when GC
    * needs to mark the old stack, to know how much of the
    * stack is valid.
    */
   STACKPTR stackbase;
   STACKPTR saved_stackptr;

   /* This variable is FRAME described extensively above.
    */
   STACKPTR frameptr;
};

#if JSE_REFCOUNT==1
#  define FUNCTIONSAVE_BRUTE_ASSIGN(Dst,Src)  ( *((struct _SEObject **)(&(Dst))) = ((struct _SEObject *)(Src)) )
#else
#  define FUNCTIONSAVE_BRUTE_ASSIGN(Dst,Src)  ( (Dst) = (Src) )
#endif

#define FUNCVAR         (FRAME-(FUNC_OFFSET+call->save.num_args))
#define FUNCVARCALL(c)  (FRAMECALL(c)-(FUNC_OFFSET+(c)->save.num_args))
#define FUNCPTR_STACK   (SEVAR_GET_OBJECT(FUNCVAR)->func)
#define FUNCPTR         (call->funcptr)

#define CALL_THIS       (FRAME-(THIS_OFFSET+call->save.num_args))


#define IPTR (call->save.iptr)
#if JSE_MEMEXT_SECODES==1
#  define IPTR_FROM_INDEX(c,i) (call->base + (i))
#  define INDEX_FROM_IPTR(c,i) ((i) - call->base)
#else
#  define IPTR_FROM_INDEX(c,i) (((struct LocalFunction *)(FUNCPTR))->opcodes + (i))
#  define INDEX_FROM_IPTR(c,i) ((i) - ((struct LocalFunction *)(FUNCPTR))->opcodes)
#endif


/* locals now numbered from 1 so that we don't have to add one here */
#define CALL_LOCAL(i) (FRAME+(i))
/* Parameters are numbered from 0 */
#define CALL_PARAM(i) (FRAME-call->save.num_args+i+1)


struct seGlobal_;

/* IMPORTANT: This value MUST be an even number of bytes!!! used for length of sevarname */
#if JSE_MIN_MEMORY==1 \
 || ( defined(__JSE_WIN16__) || defined(__JSE_DOS16__) )
   typedef uword16 sestringLenType;
#  define HIDDEN_SESTRING_BIT    0x8000
#  define LENGTH_SESTRING_BITS   0x7fff
#else
   typedef uword32 sestringLenType;
#  define HIDDEN_SESTRING_BIT    0x80000000
#  define LENGTH_SESTRING_BITS   0x7fffffff
#endif

#if JSE_ONE_STRING_TABLE==1
   extern VAR_DATA(struct seHashList **) sehashTable;
   extern VAR_DATA(uint) sehashSize;
#endif


#if JSE_MIN_MEMORY==1
   typedef uword16 sestringlocks;
#  define JSE_SESTRING_SWEEP_BIT    0x8000
#  define JSE_SESTRING_PERMLOCK_BIT 0x4000
      /* Garbage collector will mark the highest bit of locks */
#  define JSE_INC_SESTRING_LOCKS(str)  { SEASSERT((str)->locks < 0x3FFF); (str)->locks++; }
#else
   typedef uword32 sestringlocks;
#  define JSE_SESTRING_SWEEP_BIT    0x80000000
#  define JSE_SESTRING_PERMLOCK_BIT 0x40000000
      /* Garbage collector will mark the highest bit of locks */
#  define JSE_INC_SESTRING_LOCKS(str)  { SEASSERT((str)->locks < 0x3FFFFFFF); (str)->locks++; }
#endif

struct seHashList
{
   sestringlocks locks;/* This keeps track of how many locks there are on the
                        * string, when it reaches zero the string is removed.
                        * For RC this makes sense anyway.  In the case of
                        * GC some strings are locked for a long time because it
                        * would take too long for GC to run again and again and
                        * again.  For the GC case while sweeping it does a
                        * JSE_STRING_SWEEP bit as the top bit so it appears locked.
                        */

   /* The 'where it was allocated' info is now removed - we no longer explicitly
    * remove them, so there won't be any messages that they aren't removed.
    */

   struct seHashList * next;
   /* The string pointer is implicitly added after the end of the structure */
};


/* seVarName
 *
 * A seVarName is an internalized value that represents a string.
 * The key is that every string is uniquely identified by a
 * seVarName. Thus, internally strings can be compared via a direct
 * comparison. seVarNames are 4 bytes.
 *
 * The format of a seVarName is myriad, to encompass many forms
 * of string efficiently.
 */

/* All formats have lowbyte as specified by the following. The
 * high 3 bytes are the data field for the formats.
 */

#define ST_FORMAT(x) ((uword32)(x)&0xff)
#define ST_DATA(x) ((uword32)(x)>>8)

#define IsNormalSEStringTableEntry(x) (((uword32)(x)&0x01)==0)
#define NormalSEStringTableEntryData(x) ((void *)(x))

#define HashListFromSEVarName(x) \
   (((struct seHashList *)(((sestringLenType *)NormalSEStringTableEntryData(x))-1))-1)
#define SEVarNameFromseHashList(x) \
  ((seVarName)(SE_POINTER_UINT)(((sestringLenType *)((x)+1))+1))
#define NameFromseHashList(sehashlist) \
      ((secharptr )(((sestringLenType *)((sehashlist)+1))+1))
#define VisAndLenFromseHashList(sehashlist) \
      (*((sestringLenType *)((sehashlist)+1)))
#define LenFromseHashList(hashlist) (VisAndLenFromseHashList(hashlist) & LENGTH_SESTRING_BITS)

/* can check if a varname represents a hidden property - not incredibly fast but not too slow either */
#define IS_HIDDEN_PROP(name)              \
      ( IsNormalSEStringTableEntry(name)    \
     && ( 0 != (HIDDEN_SESTRING_BIT & VisAndLenFromseHashList(HashListFromSEVarName(name))) ) )




#define ST_NUMBER_VALUE_MASK  0x7fffff00

#define PositiveSEStringTableEntry(x) ((seVarName)((((uword32)(x))<<8)|ST_NUMBER_POS|0x80000000))
#define NegativeSEStringTableEntry(x) ((seVarName)((((uword32)(-(x)))<<8)|ST_NUMBER_NEG|0x80000000))
#define NumericSEStringTableEntry(x) (((x)<0)?NegativeSEStringTableEntry(x):\
                                            PositiveSEStringTableEntry(x))

#define IsPosNumericSEStringTableEntry(x)   (((uword32)(x)&0xff)==ST_NUMBER_POS)
#define IsNegNumericSEStringTableEntry(x)   (((uword32)(x)&0xff)==ST_NUMBER_NEG)

#define IsNumericSEStringTableEntry(x) \
        (IsPosNumericSEStringTableEntry((x)) || IsNegNumericSEStringTableEntry((x)))
#define GetNumericSEStringTableEntry(x) \
        ((IsPosNumericSEStringTableEntry((x)))?(ST_DATA(x)&0x7fffff):-(sword32)(ST_DATA(x)&0x7fffff))


/* All of the special formats must be odd, i.e. have the low bit set,
 * to differentiate them from the normal string table entry.
 */


/* This is up to 5 alnum characters (lower case, upper case, numbers,
 * _,$) which is 63 possibilities per char. Thus, 6 bits each, so up to 5 chars
 * can be stuffed in 30 bits plus this mask. Note that value 0 = '$'
 * for the 1st 4 characters, but means no character for the 5th, allowing
 * 4 or 5 length strings. This means a 5 length string ending in
 * '$' is not encoded using this format.
 */
#define ST_ALNUM_MASK 0x03 /* 00001 */

/* A positive number in the valid range. Positive numbers too
 * big are stored as text in the string table.
 */
#define ST_NUMBER_POS 0x05 /* 00101 note: this value & 0x03 must not be 0x03 */


/* A negative number in the valid range. Negative numbers too
 * small are stored as text in the string table.
 */
#define ST_NUMBER_NEG 0x09 /* 01001 note: this value & 0x03 must not be 0x03 */


/* A 0-3 byte ascii string. The unused bytes are filled
 * with '\0'. The high byte is the string's first byte,
 * the second byte is the next highest, and unused bytes
 * as I said are replaced with '\0'
 */
#define ST_SHORT_ASCII 0x0d /* 01101 note: this value & 0x03 must not be 0x03 */
#define NULL_SEVARNAME (seVarName)ST_SHORT_ASCII

/* An entry in the binary-sorted stock string table. The data
 * is just the index into the table. The data is not copied.
 */
#define ST_STOCK_ENTRY 0x11 /* 10001 note: this value & 0x03 must not be 0x03 */

#if JSE_UTIL_SEGMENT==1
   void cleanupSEStringTable(struct seCall *call,struct seHashList ** table,uint size,sebool reset_to_initial);
      /* will delete all strings from the table.  if reset_to_initial then will then reset the initial
       * state of table to have nothing allocated, else will free table from memory
       */
   struct seHashList ** allocateSEStringTable(struct seGlobal_ * global,size_t size);
#endif

#if JSE_COMPILER==1

union tokData
{
   sememcount const_index;/* only for Type() == Variable,
                             * into call->Global->CompileStatus.current_func's
                             * constant table.
                             */
   uint lineNumber;          /* only for Type() == SourceFileLineNumber        */
   seVarName name;          /* Type is not determined                         */
};

struct tok
{
   union tokData Data;
   setokval type;
};

struct CompileStatus_
{
   uint NowCompiling;
   seconstcharptr CompilingFileName;
   /* while compiling, keep track of current file name for debugging */
   uint CompilingLineNumber;  /* while compiling remember line number */

   struct Source *src;
   seconstcharptr srcptr;

   struct tok look_ahead;
   sebool look_used;
#  if JSE_HTML_COMMENT_STYLE==1
      sint paren_group_depth; /* track depth within ((())) */
#  endif

   sebool new_source;
   /* can only give out one token at a time, if we need to give a
    * second (i.e. filename/linenumber), do so.
    */
};

#endif /* #if JSE_COMPILER==1 */

   /* A lock on an object or string */
/* flags for the following flags field */
#define seLI_IS_TEMP    ((uword8)0x01)
#define seLI_WEAK       ((uword8)0x02)  /* used by object */

#if JSE_MEMEXT_STRINGS==0
#define seLI_SESTR      ((uword8)0x50)  /* type sestr - GC must mark */
#endif
#define seLI_HASHLIST   ((uword8)0x60)  /* hashlist varname - GC must mark */
#define seLI_OBJECT     ((uword8)0x70)  /* seobject - GC must mark */
#define seLI_STOCK      ((uword8)0x80)  /* from stock pool - no GC or freeing is needed */
#define seLI_STRALLOC   ((uword8)0x90)  /* allocated string - must free in seTempFreeItem */
#if SE_GETSTRING_SHORT_POOL!=0
#define seLI_STR_POOL   ((uword8)0xA0)  /* in short-string pool - must mark as unused in seTempFreeItem */
#endif

#define seLI_GET_TYPE(type)   ((uword8)( ((uword8)type) & ((uword8)0xF0) ))

struct seapiLockItem
{
#  if JSE_TRACKVARS==1
      /* if tracking vars, save where this was allocated from */
      seassert_filetype file;
      int line;
#  endif
   /* User can free them at will */
   struct seapiLockItem *prev, *next;

   union {
#     if JSE_MEMEXT_STRINGS==0
         seString          sestr; /* seLI_SESTR */
#     endif
      struct seHashList * name;   /* seLI_HASHLIST */
      hSEObject         obj;      /* seLI_OBJECT */
      sememcount        len;      /* seLI_STRALLOC and seLI_STR_POOL and seLI_STOCK */
   } data;

   seconstcharptr str_lookup; /* anything be seLI_OBJECT uses this field.  It always points to the
                               * string data directly.
                               */
   
   hSEObject hSavedScopeChain; /* Only used by seLI_OBJECT */
   
   uword8 flags;  /* see seLI_ flags above */
   uword16 mark;  /* callback depth at which this can be found */
};


#if JSE_MEMEXT_ANY==1
   struct seMemextCacheEntry
   {
      struct seMemextCacheLinks {
         /* create index of next entry in the list; prevtowardHead points to index to
          * the head of the list; towardTail points toward old entries (or free entries)
          */
         ubyte next;
         ubyte prev;
      } links;
      struct seMemextCacheData {
         /* handle being cached */
         jsememextHandle handle;
         /* in-memory version */
         void *ptr;
#        if JSE_MEMEXT_READONLY==1
            /* Is it just readable, or readable and writeable */
            ubyte writeable;
#        endif
      } data;
   };
   struct seMemextCache
   {
      ubyte size; /* how many entries in the cache */
      ubyte used; /* how many entries are used */
      ubyte first;/* first entry used, head of list */
      ubyte type; /* type used for locks and unlocks */
      sebool always_move_to_front; /* if lock will always move to beginning */
      struct seMemextCacheEntry entry[1]; /* one here, but JSE_MEMEXT_type_CACHE-1 will follow */
   };
#  define SE_MEMEXT_CACHE(name,size)                  \
      struct seMemextCache name;                      \
      struct seMemextCacheEntry name##_extra[size-1];
#  if JSE_COMPILER_SEGMENT==1
      JSE_MEMEXT_R void * lockMemextHandle(struct seCall *call,struct seMemextCache *cache,jsememextHandle handle
#                                          if JSE_MEMEXT_READONLY==1
                                              ,sebool writeable
#                                          endif
                                          );
      void freeMemextHandle(struct seCall *call,struct seMemextCache *cache,jsememextHandle handle);
      void uncacheMemextHandle(struct seCall *call,struct seMemextCache *cache,jsememextHandle which);
#  else
#     if JSE_MEMEXT_READONLY==1
#        define lockMemextHandle(call,cache,handle,writeable) \
         jseFuncs(call)->lockMemextHandleFunc((call),(cache),(handle),(writeable))
#     else
#        define lockMemextHandle(call,cache,handle) \
         jseFuncs(call)->lockMemextHandleFunc((call),(cache),(handle))
#     endif
#     define freeMemextHandle jseFuncs(call)->freeMemextHandleFunc
#  endif
#  if JSE_COMPILER_SEGMENT==1
      sebool INITIALIZE_MEMEXT(struct seCall *call);
      void PURGE_MEMEXT_CACHES(struct seCall *call,sebool and_terminate);
#  else
#     define INITIALIZE_MEMEXT jseFuncs(call)->INITIALIZE_MEMEXT_Func
#     define PURGE_MEMEXT_CACHES jseFuncs(call)->PURGE_MEMEXT_CACHES_Func
#  endif
#endif

#if JSE_TRACK_OBJECT_USE==1
/* NYI: Store a secharptr instead of a seVarName, since some seVarNames will
 * no longer be good when we exit the program and want to print out
 * the information
 */

struct DebugObjectCacheEntry
{
   seVarName name;
   uint      misses;
   uint      hits;
   uint      cached_misses;
   uint      cached_hits;

   struct DebugObjectCacheEntry *next;
};
#endif

#if defined(SE_RELEASE_BUILD)
#  define SE_API_ENTER(call) /* nada */
#  define SE_API_RETURN_VOID(call)  return;
#  define SE_API_RETURN(call,ret)   return (ret);
#else
#  define SE_API_ENTER(call) STACKPTR dbg_top_of_stack = STACK0; call->Global->api_depth++;
#  define SE_API_RETURN_VOID(call) {call->Global->api_depth--; SEASSERT(dbg_top_of_stack==STACK0); return;}
#  define SE_API_RETURN(call,ret)  {call->Global->api_depth--; SEASSERT(dbg_top_of_stack==STACK0); return (ret);}
#endif


#if JSE_CACHE_GLOBAL_VARS==1
   /* Globals are always cached for the main global for each
    * interpret. Note that you want to turn off caching if
    * you are going to be using a dynamic global object.
    * This cache is a double-linked list to make it trivial
    * to sort MRU items to the top.
    */
   struct secall_cache_data {
      seVarName entry;
      sememcount slot;
   };
   struct secall_cache {
      struct secall_cache *prev, *next;
      struct secall_cache_data data;
   };
#endif

#if SE_WRITE_SHARED_OBJECTS==1
/* ----------------------------------------------------------------------
 * Each context keeps a list of the shared items it is currently using.
 * This list is pruned whenever a garbage collection is performed. With
 * the lists maintained by all contexts, a higher-level, shared object
 * collection can be performed.
 *
 * There are 4 write-sharable item types: objects, strings, varnames
 * and functions. All are treated identically.
 * ---------------------------------------------------------------------- */


/* Since testing an item is a straight pointer comparison, trying to
 * sort this list and then binary search it would make the comparison
 * about as computationally intensive as traversing the list,
 * pointless to sort. If it proves to be slow, I'll make a hash table,
 * but I'd prefer to not use up so much memory unless needed.
 */
struct se_write_shared_item
{
   struct se_write_shared_item *prev,*next;

   void *item;
};

#endif


struct seCallbackSaver
{
   /* this structure containes information that needs to be saved across callbacks */
   struct seCallbackSaver *prev;
   struct _SEVar return_var;
   uword8 state;                /* FlowError, FlowExit, FlowNoReasonToQuit */
   hSEObject wrapper_temp;
   uword8 preserve_return_var;
   uword8 preserve_in_secodeInterpret;
};


#if JSE_GC==1
#  if JSE_DYNAMIC_CALLBACKS!=0
#     define final_destructors         0x01
#  endif
#endif
/* This flag is needed because if we are within an ErrorVPrintf, and we encounter
 * another error, then we don't want it printed, because most likely  the error
 * happened while within ErrorVPrintf (such as a prototype loop), and it will
 * create an infinite loop and a stack overflow.
 */
#define inErrorVPrintf                 0x02
/* This flag is used in the rare rare case that a GC must happen in the middle
 * of creating an sevarname.  This flags keeps it from happening recursively.
 */
#if JSE_GC==1
#  define within_createvarname_recursive 0x04
   /* this flag is set whenever memory allocation fails - it is used only
    * in the final instance of creating an error message if it cannot be
    * made into a string because of memory allocation failure.
    */
#endif
#define se_alloc_failed                0x08

#if JSE_GC==1
   /* set when we do not want the garbage collecter to refill pools */
#  define collect_do_not_refill          0x10
#endif
#if JSE_STACKCHK==1
   /* set when running out of stack during compilation so callQuit can be called later (when more stack available) */
#  define stack_error_in_compilation     0x20
#endif

struct seGlobal_
{
   /* parameters that cannot change as context depth changes;
    * created only at top level
    */

   /* IMPORTANT - this must always be the first entry of this structure! */
#  if JSE_LINK==1 || defined(__JSE_DLLRUN__)
      struct seFuncTable_t *seFuncTable;
#  endif

#  if SE_DEBUGGER_SUPPORT==1
      /* only used when debugging to give each text script evaled
       * a unique name.
       */
      uint no_filename_num;
#  endif


#  if JSE_GC==1
      uword16 collect_disable;
#  endif

#  if JSE_DONT_POOL==0

#     ifndef JSE_MEM_POOL_MAX_SIZE
#        if JSE_MIN_MEMORY==1
#           define JSE_MEM_POOL_MAX_SIZE (OBJ_DEFAULT_SIZE*2)
#        else
            /* This is the maximum sized member structure that will be put
             * into the pool.
             *
             * To get the best results out of our speed tests, make sure that
             * this is 64, not 32, because the object test uses ~60 members.
             * Frankly, I feel if someone is using objects that big, then
             * they're probably going to want to use them again, so why
             * not pool them?  Of course, if you grab the members for an
             * object that only uses 2 members, you're wasting lots of space.
             */
#           define JSE_MEM_POOL_MAX_SIZE (OBJ_DEFAULT_SIZE*4)
#        endif
#     endif

      hSEObject hobj_pool[SE_OBJ_POOL_SIZE];
                                   /* the pool of reusable objects */
      uint hobjPoolCount;           /* items in pool */

      hSEMembers mem_pool[SE_MEM_POOL_SIZE];
                                   /* the pool of reusable objects */
      uint memPoolCount;           /* items in pool */

#     if JSE_DONT_POOL==0
         seString sestring_pool[SE_STRING_POOL_SIZE];
         uint sestringPoolCount;        /* The pool of reusable _seStrings */
#     endif

#  endif

   /* This pointer saves the state of certain variables that need to be preserved
    * while calling a callback function, and restored when that callback function
    * returns--this allows not just restoration but also allows the GC to mark
    * them for later use.
    */
   struct seCallbackSaver *recentCallbackSaver;

   hSEObject *recurse_stack;
   sememcount recurse_depth;
   sememcount recurse_stack_alloced;

#  if JSE_GC==1
      hSEObject all_hobjs;           /* all objects currently allocated */
#  endif
#  if JSE_PER_OBJECT_CACHE==0
      /* cache most-recently used object and index */
      struct {
         hSEObject hobj;
         sememcount index;
      } recentObjectCache;
#  endif

   hSEObject api_services;
   /* The SE_SERVICES object, allocated only when first needed, and removed
    * only when the global is destroyed.
    */

#  if JSE_TRACK_OBJECT_USE==1
      struct DebugObjectCacheEntry * debugObjectCache;
#  endif
#  if !defined(SE_RELEASE_BUILD)
      uint api_depth;  /* show how deep we are within api functions */
#  endif

#  if JSE_GC==1
#     if JSE_DYNAMIC_CALLBACKS!=0
         hSEObject *hDestructors;   /* realloced list of VarObjs with destructors needed
                                     * to be called.
                                     */
         sememcount destructorCount;
         sememcount destructorAlloced;
#     endif
#  endif

#  if JSE_REFCOUNT==0
      uword32 stringallocs;
      seString stringdatas;        /* all strings currently allocated */
#  endif

#  if JSE_REFCOUNT==0
      struct seFunction *funcs;      /* all functions currently allocated */
#  endif

#  if JSE_NEVER_FREE==1
      void **blocks_to_free;
      uint num_blocks_to_free,max_blocks_to_free;
#  endif

#  if JSE_ONE_STRING_TABLE==0
      struct seHashList ** sehashTable;
      uint sehashSize;
#  endif

   /* prelocked */
   struct {
      seVarName global_object;
      seVarName hidden_value; /* hidden place for objects to store their native types */
#     if JSE_MIN_OBJ_SIZE==1
         seVarName hidden_function; /* hidden place for objects to store their function pointers */
#        if JSE_DYNAMIC_CALLBACKS==1
            seVarName hidden_callbacks; /* hidden place for objects to store their callback pointers */
#        endif
#     endif
   } vnames;

#  if JSE_COMPILER==1
      struct CompileStatus_ CompileStatus;
#     if JSE_CONDITIONAL_COMPILE==1
         uint ConditionalDepth; /* upped whenever in #if processing */
#     endif
#  endif

#  if JSE_GETFILENAMELIST==1
      /* this structure is build only if jseGetFileNameList is called */
      struct {
         SE_POINTER_UINDEX count;
         secharptr *list;
      } FileNames;
#  endif

   void /*_FAR_*/ * GenericData;
      /* this data may be specific to each implementation */

   struct seContextParams Params;

#  if JSE_SECUREJSE==1
      /* Security params */
      seobject security[SECURITY_OBJ_COUNT];
#  endif

   sechar tempNumToStringStorage[12];
      /* when numbers are converted to strings they are converted here
       * and this data is returned.  Note that this means there is
       * one number used at a time per context thread.  This is big
       * enough for longest number, which is -2147483648.
       */
#  if SE_GETSTRING_SHORT_POOL!=0
      struct seStringShortPoolItem {
         sechar data[12];   /* make same size as tempNumToStringStorage */
         ubyte used;
      } sestring_short_pool[SE_GETSTRING_SHORT_POOL];
#  endif

#  if (defined(__JSE_WIN16__) || defined(__JSE_DOS16__)) && \
      (defined(__JSE_DLLLOAD__) || defined(__JSE_DLLRUN__))
      uword16 ExternalDataSegment;
#  endif

   uword8 flags;

#  if JSE_SECUREJSE==1
      /* a record of all security so we can delete them on exit */
      struct Security *allSecurity;
#  endif

   struct dynacallRecurse *dynacallRecurseList;
   uint dynacallDepth;  /* prevent extreme depth-without-end on dynamic calling */
      /* linked list of all dynamic calls currently being executed */

#  if JSE_LINK==1
      /* These are all the freed extlibs. We don't actually release
       * them until we are about to exit, because they may still have
       * memory and routines we need to call, like if you return
       * a wrapper function defined in them, or if they set shared data.
       */
      struct ExtensionLibrary savedLibs;
#  endif

#  if JSE_MEMEXT_ANY==1
      jsememextService memextSvc;
#     if JSE_MEMEXT_OBJECTS==1
         SE_MEMEXT_CACHE(memextObjectsCache,JSE_MEMEXT_OBJECTS_CACHE)
#     endif
#     if JSE_MEMEXT_MEMBERS==1
         SE_MEMEXT_CACHE(memextMembersCache,JSE_MEMEXT_MEMBERS_CACHE)
#     endif
#     if JSE_MEMEXT_SECODES==1
         SE_MEMEXT_CACHE(memextSecodesCache,JSE_MEMEXT_SECODES_CACHE)
#     endif
#     if JSE_MEMEXT_STRINGS==1
         SE_MEMEXT_CACHE(memextStringsCache,JSE_MEMEXT_STRINGS_CACHE)
#     endif
#  endif

   /* API pools */
   seobject seapi_temp_pool[SE_API_TEMP_POOL_SIZE];
   uint seapi_temp_pool_count;

   /* The storage area for api-temporary variables */
   hSEObject global_temp;

   secharptrdatum null_TempString[1];  /* this string delivered by API if len string == 0
                                        * also use if string must be returned on error
                                        */

   struct seapiLockItem api_lock_items;/* Locks that exist until program exits. Making
                                        * it a struct rather than a pointer eases freeing
                                        * of all members of the linked list.
                                        */

   /* These correspond to the above, but for until-end-of-callback locks. */
   struct seapiLockItem api_local_lock_items;

   /* The api_mark is incremented whenever we enter a user callback
    * and decremented when we exit. All tempvars created at that
    * level also go away. Fibers can never switch in the middle
    * of a callback, only at the top level.
    *
    * Tempvars created at the top level go away when the last
    * call goes away and the global is going to be deleted.
    * All fibers share the same top-level tempvars.
    */
   uword16 api_mark;

#  if JSE_FLOATING_POINT==1
      /* wraparound values to be calculated only once */
      senumber jseFPx10000;
      senumber jseFPx100000000;
      senumber jseFPx7fffffff;
      senumber jseFPx7fffff;
      senumber jseFPx7fffffneg;
#  endif

#  ifndef FUNC_SAVE_POOL_SIZE
#     define FUNC_SAVE_POOL_SIZE 6
#  endif
   struct functionSave *func_save_pool[FUNC_SAVE_POOL_SIZE];
   uint func_save_pool_count;



#  if defined(JSE_INTERNAL_PROFILING) && JSE_INTERNAL_PROFILING==1
      ulong since;         /* clock()-since is time in current block */
      ulong *which;        /* points to one of the following: */


      ulong total;         /* total time between initialize and kill context */
      ulong dynacallback;
      ulong wrapper;       /* time spent in user wrapper functions, include dyn callbacks
                            * NOTE: simple API functions count as app time. In other
                            * words, if the function returns 'call->foo' or 'strlen(x)'
                            * or such, I think that should be recorded as the caller's
                            * time. If the wrapper function does anything inside the
                            * code, even access a variable (since it could call a
                            * dynamic function), that is tacked onto the ScriptEase
                            * time.
                            */
      ulong apptime;       /* time spent in user app */

      /* For the rest, they are additive, i.e. 'se+garbage' is total
       * time in ScriptEase, 'se+garbage+wrapper' is total time doing
       * ScriptEase stuff, and 'total' minus that would be time in
       * use app not calling ScriptEase stuff
       */

      ulong se;            /* generic time spent in ScriptEase API calls */
      ulong garbage;       /* time spent in garbage collection */
      ulong compile;       /* time spent compining */
      ulong peephole;      /* time spent peephole optimizing */
      ulong token;         /* time spent tokenizing */
      ulong num_parse;     /* time parsing numbers */
      ulong ident_parse;   /* time parsing idents and keywords */
#  endif /* #ifdef JSE_INTERNAL_PROFILING */

   STACKPTR call_func_mark;

   /* When running out of memory, an error object (generic)
    * to use. Since we have run out of memory, we cannot
    * allocate a new object.
    */
   hSEObject stock_out_of_mem_obj;

   /* This object is used when seobj_new has no new object to
    * give.
    */
#  if JSE_MEMEXT_OBJECTS==1
      hSEObject internal_out_of_mem_hobj;
#  else
      struct _SEObject internal_out_of_mem_obj;
#  endif

#  if JSE_MIN_OBJ_SIZE==1
      struct func_being_put *now_being_put;
#  endif

#  if SE_WRITE_SHARED_OBJECTS==1

      /* The lists of shared items this function is using.
       */
      struct se_write_shared_item *write_shared_functions;
      struct se_write_shared_item *write_shared_objects;
      struct se_write_shared_item *write_shared_strings;
      struct se_write_shared_item *write_shared_varnames;

      /* Caches for items recently added to the lists. Unused
       * entries are NULL.
       */
#     define WRITE_SHARED_CACHE_SIZE 4
      struct se_write_shared_item *write_shared_functions_cache[WRITE_SHARED_CACHE_SIZE];
      struct se_write_shared_item *write_shared_objects_cache[WRITE_SHARED_CACHE_SIZE];
      struct se_write_shared_item *write_shared_strings_cache[WRITE_SHARED_CACHE_SIZE];
      struct se_write_shared_item *write_shared_varnames_cache[WRITE_SHARED_CACHE_SIZE];
#  endif
#  if SE_API_OBJECT_COUNT_WARNING!=0
      uword8 object_count_was_warned;
#  endif
#  if SE_API_STRING_COUNT_WARNING!=0
      uword8 string_count_was_warned;
#  endif

   /* secode_datum_sizes - this is an array of all the sizes used by the elements in
    * secode.h.  To save space the sizes must be or'ed with certain flags
    * This shows how much space is used by the datum for that code (if code element
    * uses two type sof data then that is included).  See SECODE_SIZE_BYTES and
    * SECODE_SIZE_SECODELEMS for access to these.
    */
   uword8 secode_datum_sizes[NUM_SECODES];
};

#if JSE_MEMEXT_OBJECTS==1
#     define IS_OUT_OF_MEM_OBJ(call,hobj) ( (hobj) == (call)->Global->internal_out_of_mem_hobj )
#  else
#     define IS_OUT_OF_MEM_OBJ(call,obj) ( (obj) == &((call)->Global->internal_out_of_mem_obj) )
#  endif

#if JSE_INTERNAL_PROFILING==1
#include <time.h>

/* clock() is much slower and skews the time a bit; stuff that
 * does a lot of transitions is much slower than stuff that
 * stays in one 'section' for a while.
 *
 * For instance, wrldfrct takes 7 seconds vs 30 seconds
 * just by switching to clock(), it is that slow. Making sure
 * the clock is quick for a particular system is therefore
 * important (GetTickCount() is a Windows thing.)
 */
#   define PROFILETIME GetTickCount()

#   define TIMER_SAVE ulong *save_timer;

#   define TIMING(call,wh)                                  \
{                                                           \
   uint current = PROFILETIME;                              \
   save_timer = (call)->Global->which;                      \
   *(call)->Global->which += current-(call)->Global->since; \
   (call)->Global->total += current-(call)->Global->since;  \
   (call)->Global->since = current;                         \
   (call)->Global->which = &(call->Global->wh);             \
}

#   define END_TIMING(call)                                 \
{                                                           \
   uint current = PROFILETIME;                              \
   *(call)->Global->which += current-(call)->Global->since; \
   (call)->Global->total += current-(call)->Global->since;  \
   (call)->Global->since = current;                         \
   (call)->Global->which = save_timer;                      \
}

#else

#   define TIMING(call,wh)
#   define END_TIMING(call)
#   define TIMER_SAVE

#endif

/* ---------------------------------------------------------------------- */

struct TryBlock
{
   struct TryBlock *prev;

   SERUN_ADDR_TYPE begin,end;    /* block location so transfers outside it trigger */
   SERUN_ADDR_TYPE Catch;        /* catch location, SERUN_ADDR_NONE = none. */
   SERUN_ADDR_TYPE fin;          /* finally location */

   uword8 state;                 /* saved when entering finally */
   SERUN_ADDR_TYPE loc;          /* when enterring finally, save where we were - -1
                                  * means haven't entered finally yet */
   sebool incatch;               /* to know if we need to discard a scope chain entry */
   sebool endtryreached;

   STACKPTR fptr;                /* the state we were in when this was created
                                  * so we can return to it. Basically, we do
                                  * 'callReturnFromFunction' until the fptr saved
                                  * is FPTR, then goto the try handler.
                                  */
   STACKPTR sptr;
};


/* Structure used to track seEvals of functions using
 * SE_START
 */
struct evalFuncStart
{
   struct evalFuncStart *next;

   /* these mirror the local variables in seEvalFunc,
    * we need to preserve them.
    */
   STACKPTR call_func_mark_save;
   uword8 old_mpe;
   uword32 flags;
   struct seEvalParams *params;
   wSEVar tmp;


   /* to restore on exit */
   uword32 oldResetContinueCount;

   /* So we know when the function is finished */
   STACKPTR done_with_func;
};

/* The Call structure */

struct seCall
{
   /* IMPORTANT: The 'seFuncTable' entry MUST be FIRST!!! The external
    *            libraries rely on this! Do NOT put anything else first.
    *            It is the first member of Global!!
    */
   struct seGlobal_ *Global;      /* Information that is the same for one jseContext
                                   * regardless of subsequent calls and such.
                                   */

   struct seCall *next,*prev,*start,*end;
      /* Call chain. Requires both directions to be able to find all entries in a
       * chain given any element of the chain.  end is there for convenience
       * when the end of the chain must be found immediately.  end is a little
       * annoying because it is set throughout the chain any time the end changes,
       * but that happens rarely compared to how often we must retrieve it.  start
       * is a quick pointer to the beginning of this chaing, also for speed.
       */

#  if JSE_TASK_SCHEDULER==1
      struct seCall *fiber_next,*fiber_prev;
                                /* A linked list of fiber-level contexts
                                 * so the collector can find them all.
                                 */
#  endif

   struct PrototypeCache_
   {
      /* all objects by default (if not HAS_PROTOTYPE) will get the prototype
       * from either Object.prototype or Function.prototype.  These will already
       * be initialized. Of course, the garbage collector will have to note
       * that these are locked. They are 'per-interpret'.
       */
      hSEObject Object; /* if SE_LOCK_PROTOTYPE_CACHE==1 this must be the first of four */
      hSEObject Array;
      hSEObject Function;
      hSEObject String;
#     if SE_LOCK_PROTOTYPE_CACHE==1
         uint locked;/* usually used as a boolean to know if all are locked - during buildup the
                      * bits may be used as a counter to see if all four objects are created.
                      */
#     else
         /* remember what the global was when these were cached, so they only need
          * to be "re-found" if the global changes.
          */
         hSEObject GlobalObject;
#     endif
   } PrototypeCache;

   /* Value returned via dynamic properties indicating
    * 'do the regular thing', including callback
    * properties
    */
   hSEObject hDynamicDefault;

   /* it is possible for a new hidden member to be created in seobjCreateMemberCopy but the only
    * way for that to happen is while within a call to sePutMemberDepth_check_hidden (becuase
    * hidden members cannot be created from the language itself).  This keeps track of if
    * we're within an sePutMember call so that seobjCreateMemberCopy doesn't usually need
    * to make the extra check to see if the hidden flag must be set.
    */
   uword16  sePutMemberDepth_check_hidden;

#  ifndef SE_RELEASE_BUILD
      ubyte cookie;             /* This value is set on all calls to verify
                                 * that a pointer passed to the API is indeed
                                 * a call.
                                 */
#  endif

   uword8 CallSettings;
#  if JSE_SECUREJSE==1
      struct Security *currentSecurity;
#  endif
#  if JSE_DEFINE==1
      struct Define *Definitions;
#  endif
   struct secoreLibrary *TheLibrary;

   hSEObject atexit_functions;

#  if JSE_LINK==1
      struct ExtensionLibrary *ExtensionLib;
#  endif

   /* when reaches 0 then will call continueFunc (if running seEval()) or will
    * return (if running seExec())
    */
   uword32 continueCount;
   uword32 resetContinueCount; /* when has reached to zero, this is what it will be set to */

#  if JSE_MULTIPLE_GLOBAL==0
      hSEObject GlobalObject;      /* the current global for this interpret.
                                    * If JSE_MULTIPLE_GLOBAL, probably want to
                                    * use the function's stored global instead.
                                    * Thus, always use CALL_GLOBAL.
                                    */
#  endif

#  if JSE_CACHE_GLOBAL_VARS==1
      struct secall_cache *cache_begin; /* point to start in cache */
      struct secall_cache cache[JSE_GLOBAL_CACHE_SIZE];
      uint seglobal_cache_used; /* how many are in the cache */
      hSEObject cached_global_obj;
#  endif

   STACKPTR stackptr;           /* current location on the stack */

#  if JSE_MEMEXT_SECODES==1
      secode base;              /* the value we get when locking */
#  endif

   struct TryBlock *tries;      /* try blocks currently in operator */

   struct seFunction *funcptr;

   /* An unsorted variable object to be used as a ScopeChain. We
    * need to be able to garbage collect these things, and add
    * them to a list. It makes more sense to reuse object descriptors,
    * than to build a whole new data type, collect it, and so
    * forth. Later, this can be changed if it really is necessary.
    *
    * Each new function has its scope chain stored in this object,
    * delimited by a VNull entry. The VariableObject is stored
    * here, initially being VUndefined.
    */
   hSEObject hScopeChain;

   uword8 pastGlobals;         /* only for interpret level, inherit past globals? */
   uword8 state;               /* FlowError, FlowExit, FlowNoReasonToQuit */


   /* The return value from the function is stored here
    */
   struct _SEVar return_var;

   wSEVar suspend_restore_loc;

   uword8 mustPrintError;
   uword8 errorPrinted;

   uword8 in_secodeInterpret;  /* true if in the interpet engine - else in callbacks or elsewhere */

   hSEObject wrapper_temp;

   /* Many of the call settings must be saved whenever a new function
    * is invoked and restored when it finishes. This is the structure
    * that holds the old values.
    */

   /* This has been modified - All members that need to be saved are put
    * into this structure and accessed directly.  Because it is a structure,
    * there is no speed difference between (call->iptr) and (call->save.iptr).
    *
    * Then, when we want to save the values, we can just do a bulk copy
    * which will save on speed and make it easier to read.  The only
    * difference is that the previous saved data is located in 'save.save_last'
    * rather than directly in 'save').
    */
   struct functionSave save;

   /* When using seEval to eval a function plus SE_START, need
    * a structure to keep track of information
    */
   struct evalFuncStart *start_info;

#  if JSE_COMPILER==1
      /* used only for out-of-memory situations */
      struct tok eof_tok;
#  endif

#  if SE_ECMA_RETURNS==1
      /* Last expression evaluated is saved to be returned if the
       * init function doesn't have a return. Per call because
       * only used by init func.
       */
      struct _SEVar last_expr;
#  endif

   struct seEvalParams *params;

#  if !defined(SE_RELEASE_BUILD)
      STACKPTR interpretInit_stack_loc; /* debug to make sure stack returns exactly */
#  endif

};

/* ---------------------------------------------------------------------- */

/* string table stuff */

/* This is the version the API (and structure members with a string value
 * for a name) will use. This is for the 'get a lock' on a string table entry,
 * use it, then free it. Internally, once you release it, it will not
 * be freed immediately - it may be still locked in place by references and
 * if an object member uses it as a name. The garbage collector will get rid
 * of it when the engine is not using it anymore. The 'temp' is just a storage
 * space the locking mechanism needs (it saves each string table entry from
 * needing an extra 'count' field.)  It is possible fro CreateSEVarName to
 * run out of memory, in which case it will have set the error and will then
 * return the default NULL-string (seVarName)ST_SHORT_ASCII
 */
#if JSE_MULTI_CORE==0 \
 || (JSE_UTIL_SEGMENT==0 && JSE_EXECUTE_SEGMENT==0 && JSE_COMPILER_SEGMENT==0)
   seVarName CreateSEVarName(struct seCall *This,seconstcharptr Name,sestringLenType length,sebool hidden);
   seconstcharptr
GetSEStringTableEntry(struct seCall *call,seVarName entry,sestringLenType *length);
   /* pass length as NULL to ignore */
#else
#  define CreateSEVarName jseFuncs(call)->CreateSEVarNameFunc
#  define GetSEStringTableEntry jseFuncs(call)->GetSEStringTableEntryFunc
#endif
#define CVN_USE_STRLEN ((sestringLenType)(-1)) /* pass as length if strlen will determine */

void NEAR_CALL AddSEVarNameLock(seVarName entry); /* make additional reference on this sevarname */
#if JSE_REFCOUNT==1
   void NEAR_CALL RemoveSEVarNameLockEx(struct seCall *call,seVarName entry);
#  define RemoveSEVarNameLock(entry)    RemoveSEVarNameLockEx(call,(entry))
#else
   void NEAR_CALL RemoveSEVarNameLockEx(seVarName entry);
#  define RemoveSEVarNameLock RemoveSEVarNameLockEx
#endif

/* This one physically removes the entry, ignoring locking - it is called
 * by the collector when an entry can be freed, and always at program exit.
 */
#define RemoveSEStringTableEntry(call,hashlist_entry) secoreFree((call),(hashlist_entry))

#if JSE_ONE_STRING_TABLE==1
   sebool allocateGlobalSEStringTable();
   void freeGlobalSEStringTable();
#endif

/* ---------------------------------------------------------------------- */

/* information routines */

#if JSE_MULTIPLE_GLOBAL==1
#  define CALL_GLOBAL(c) ((c)->save.CurrentGlobalObject)
#else
#  define CALL_GLOBAL(c) ((c)->GlobalObject)
#endif

/* These are just convenient accessors.  At some point this data may become
 * allocated somehow to reduce copying overhead, so use these macros instead
 * of accessing them directly
 */
#define CALL_VAROBJ(c) ((c)->save.hVariableObject)
#define CALL_NEWSCOPE(c) (&((c)->save.new_scope_chain))
#define CALL_NUMARGS(c) ((c)->save.num_args)
#define CALL_TRUEARGS(c) ((c)->save.true_args)
#define CALL_USECACHE(c) ((c)->save.useCache)
#define CALL_INCALLBACK(c) ((c)->save.flags&FS_INCALLBACK)
#define CALL_SETINCALLBACK(c) ((c)->save.flags|=FS_INCALLBACK)
#define CALL_UNSETINCALLBACK(c) ((c)->save.flags&=(uword8)(~FS_INCALLBACK))
#define CALL_ISCONSTRUCTOR(c)   ((c)->save.flags&FS_ISCONSTRUCTOR)
#define CALL_SETISCONSTRUCTOR(c) ((c)->save.flags|=FS_ISCONSTRUCTOR)
#define CALL_UNSETISCONSTRUCTOR(c) ((c)->save.flags&=(uword8)(~FS_ISCONSTRUCTOR))
#define CALL_IS_PRESERVE_RETURN(c) (0==((c)->save.flags&FS_DONOT_PRESERVE_RETURN))
#define CALL_SET_PRESERVE_RETURN(c) ((c)->save.flags&=(uword8)(~FS_DONOT_PRESERVE_RETURN))
#define CALL_UNSET_PRESERVE_RETURN(c) ((c)->save.flags|=FS_DONOT_PRESERVE_RETURN)
#define CALL_CALLBACKPARAM(c) (&((c)->save.callback_param))
#define CALL_CALLBACKTHIS(c) ((c)->save.callback_this)
#define CALL_WRAPPER_TEMP(c) ((c)->save.wrapper_temp)
#if JSE_NAMED_PARAMS==1
#  define CALL_WRAPPER_NAMED(c) ((c)->save.wrapper_named)
#endif

#define CALL_NORMAL(call) ((call)->state==StateNormal)

#define CALL_ERROR(call) (((call)->state&StateError)!=0)
#define CALL_QUIT(call) (((call)->state&StateSomeError)!=0)
#define CALL_SUSPENDED_OR_YIELDED(call) (((call)->state&(StateSuspend|StateYield))!=0)

#define CALL_SET_STATE(call,s) ((call)->state |= (s))


/* What's the difference? RESET is used when explicitly unsuspending
 * a thread. The SET_NORMAL is used in the vast majority of the core
 * when we don't want to change the suspended state.
 */
#define CALL_RESET_STATE(call) ((call)->state = StateNormal)
#define CALL_SET_NORMAL(call) ((call)->state &= (uword8)(~StateSomeError))

#define FAV_DEFAULT                 0x00
#define FAV_FULL_LOOK               0x01
#define FAV_CREATE_REF              0x02  /* HP_REFERENCE */
#define FAV_CHECK_VAR_REQUIRED      0x04
#if JSE_EXECUTE_SEGMENT==1
   wSEVar secoreFindAnyVar(struct seCall *call,seVarName name,int flags);
   /* search the current scope for name variable.  This will always initialinze
    * the top of the stack for safety.  If not found then this will leave
    * the stack unchaged and return NULL.  If found then this will put that found
    * variable on top of the stack (so you can find it at STACK0); this will also
    * return a wSEVar which will usually be the same as STACK0 but in somet cases
    * may be a direct pointer to the real location of a writeable variable (for instance
    * if FAV_CREATE_REF then this will push a ref on the stack, but if it's a
    * directly writeable variable of an object then will return that variable).
    */
#else
#  define secoreFindAnyVar jseFuncs(call)->secoreFindAnyVarFunc
#endif

struct seCallFunctionScopes
{
   hSEObject start;
   hSEObject end;
};


#if JSE_EXECUTE_SEGMENT==1
      sememcount
   callCreateVariableObject(struct seCall *call,struct seFunction *lookfunc,uint depth);

      void
   callFunction(struct seCall *call,uword16 num_args,sebool constructor,
                struct seCallFunctionScopes *scopes /* may be NULL */);
#else
#  define callCreateVariableObject(a,b,c) jseFuncs(a)->callCreateVariableObjectFunc((a),(b),(c))
#  define callFunction jseFuncs(call)->callFunctionFunc
#endif /* #if JSE_EXECUTE_SEGMENT==1 */

#define CFF_DEFAULT     False
#define CFF_CONSTRUCTOR True
#if JSE_EXECUTE_SEGMENT==1
      void
   callFunctionFully(struct seCall *call,uword16 num_args,sebool call_as_constructor,
                     struct seCallFunctionScopes *scopes /* may be NULL */);
#else
#  define callFunctionFully jseFuncs(call)->callFunctionFullyFunc
#endif /* if JSE_EXECUTE_SEGMENT==1 */

#if JSE_EXECUTE_SEGMENT==1
   void callReturnFromFunction(struct seCall *call,int cleanup_flags);
#else
#  define callReturnFromFunction jseFuncs(call)->callReturnFromFunctionFunc
#endif

#define CALL_ADD_SCOPE_OBJECT(call,wScopeChain,rvar) \
   seobjCreateMemberCopy((call),(wScopeChain),SE_NO_VARNAME,(rvar),SE_DEFAULT)

#if JSE_MEMEXT_OBJECTS==1
   void NEAR_CALL CALL_REMOVE_SCOPE_OBJECT(struct seCall *call);
#else
#  define CALL_REMOVE_SCOPE_OBJECT(call) ((call)->hScopeChain->used--)
#endif

/* error routines */

#if JSE_UTIL_SEGMENT==1
   void callPrintError(struct seCall *call);  /* Must be an error object */
   void JSE_CFUNC callError(struct seCall * call,enum textcoreResourceID id,...);
   void JSE_CFUNC callQuit(struct seCall * call,enum textcoreResourceID id,...);
#else
#  define callPrintError  jseFuncs((call))->callPrintErrorFunc
#  define callError  jseFuncs((call))->callErrorFunc
#  define callQuit jseFuncs((call))->callQuitFunc
#endif

#define JSE_INTERPRET_DEFAULT          0x00
#define JSE_INTERPRET_NO_INHERIT       0x01
#define JSE_INTERPRET_CALL_MAIN        0x02
#define JSE_INTERPRET_LOAD             0x04
#define JSE_INTERPRET_KEEPTHIS         0x08
#define JSE_INTERPRET_TRAP_ERRORS      0x10
#define JSE_INTERPRET_INFREQUENT_CONT  0x20
#define JSE_INTERPRET_IMPLICIT_THIS    0x40
#define JSE_INTERPRET_IMPLICIT_PARENTS 0x80
#define JSE_INTERPRET_FUNCS_ONLY       0x100


#if JSE_COMPILER_SEGMENT==1
      struct seCall *
   interpretInit(struct seCall * call,seconstcharptr OriginalSourceFile,
              seconstcharptr OriginalSourceText,
              const void *PreTokenizedSource,
              seEvalSettings NewContextSettings,
              int HowToInterpret,
              hSEObject args,
              struct seCallFunctionScopes *scopes,
              hSEObject this_obj,
              seconstcharptr filename,
              uint line);
      struct seCall *
   interpretTerm(struct seCall *call);
#endif

#if JSE_UTIL_SEGMENT==1 || JSE_MULTI_CORE==0

   struct seCall * NEAR_CALL
callInitial(const struct seContextParams * const LinkParms);

#endif
#if JSE_UTIL_SEGMENT==1 && JSE_CACHE_GLOBAL_VARS==1
   void NEAR_CALL se_init_cache_global_vars(struct seCall *call);
#endif /* #if JSE_UTIL_SEGMENT==1 && JSE_CACHE_GLOBAL_VARS==1 */
#if JSE_UTIL_SEGMENT==1
      struct seCall *
   callInterpret(struct seCall *This,seEvalSettings settings,sebool see_old,
                 sebool traperrors);
#else
#  define callInterpret  jseFuncs(call)->callInterpretFunc
#endif
#if JSE_UTIL_SEGMENT==1
   void callDelete(struct seCall *call);
#else
#  define callDelete(call) jseFuncs(call)->callDeleteFunc(call)
#endif

   sebool NEAR_CALL
callErrorTrapped(struct seCall *call);

   sebool
callBreakpointTest(struct seCall *call,hSEObject hParentObject,
                   seconstcharptr WantedName,
                   uword32 LineNumber,uint depth);

/* initialization */

#if JSE_EXECUTE_SEGMENT==1
   void AssignGlobalPrototype(struct seCall *call,seVarName name,hSEObject * protoObj);
   void rebuildPrototypeCache(struct seCall *call);
#else
#  define rebuildPrototypeCache jseFuncs(call)->rebuildPrototypeCacheFunc
#endif
#if SE_LOCK_PROTOTYPE_CACHE==1
#  define SYNCH_PROTOTYPE_CACHE(call)                            \
      if ( !call->PrototypeCache.locked )                        \
      {                                                          \
         rebuildPrototypeCache(call);                            \
      }
#  define FLUSH_PROTOTYPE_CACHE(call);    /* nothing */
#else
#  define SYNCH_PROTOTYPE_CACHE(call)                               \
      if ( call->PrototypeCache.GlobalObject != CALL_GLOBAL(call) ) \
      {                                                             \
         rebuildPrototypeCache(call);                               \
      }
#  define FLUSH_PROTOTYPE_CACHE(call) \
      HSEOBJECT_ASSIGN_NULL((call)->PrototypeCache.GlobalObject) /* force rebuild or research */
#endif

#if JSE_UTIL_SEGMENT==1 || JSE_MULTI_CORE==0
   void callNewGlobalVariable(struct seCall *call);
   sebool JSE_CFUNC callNewSettings(struct seCall *This,uword8 NewContextSettings);
   void callCleanupGlobal(struct seCall *This);
#elif JSE_MULTI_CORE==1
#  define callNewSettings(call,NewContextSettings) \
          jseFuncs(call)->callNewSettings((call),(NewContextSettings))
#endif

/* ----------------------------------------------------------------------
 * Callback macros to make all callbacks have the same operation with
 * the core.
 * ----------------------------------------------------------------------
 */


/* remove all temp vars. We cannot just make a 'mark' like we
 * did in SE430, because it is possible to move a temp var to
 * a real var, or explicitly remove it. This could happen to
 * whatever 'mark' we used, thereby screwing everything up.
 * Instead we note the frame when each tempvar is created,
 * and use that frame to get rid of all tempvars still there.
 *
 * As for restoring the state, if there was an error already
 * then that takes precedence (i.e. new errors do not overwrite
 * old errors.) Otherwise, we restore the old state unless there
 * was some kind of error in the call.
 *
 *
 */

/* NYI: What happens if a GC happens in the middle of the callback?
 * If old_ret refers to an object, then won't we lose our reference
 * to it, thereby forcing it to be collected?
 */

/* Note: If you change this inline, be sure to change the non-inlined
 * version in util.c
 */
#define PRE_CALLBACK_SOURCE(call,callback_saver)                                 \
{                                                                                \
   (callback_saver).prev = (call)->Global->recentCallbackSaver;                  \
   (call)->Global->recentCallbackSaver = &(callback_saver);                      \
   SEVAR_COPY(&(callback_saver).return_var,&(call)->return_var);                 \
   (callback_saver).state = (call)->state;                                       \
   HSEOBJECT_INIT_ASSIGN((callback_saver).wrapper_temp,(call)->wrapper_temp);    \
   (call)->Global->api_mark++;                                                   \
   (call)->state = StateNormal;                                                  \
   (callback_saver).preserve_return_var = 0;                                     \
   (callback_saver).preserve_in_secodeInterpret = (call)->in_secodeInterpret;    \
   (call)->in_secodeInterpret = 0;                                               \
   SEVAR_INIT_UNDEFINED( &((call)->return_var) );                                \
   HSEOBJECT_ASSIGN_NULL((call)->wrapper_temp);                                  \
}
#define PRE_CALLBACK_PRESERVE_RETURN_VAR(callback_saver)                         \
   (callback_saver).preserve_return_var = 1;

#if JSE_INLINES==1
#  define PRE_CALLBACK(call,callback_saver) PRE_CALLBACK_SOURCE((call),(callback_saver))
#else
#  if JSE_EXECUTE_SEGMENT==1
      void reallyPreCallback(struct seCall *call, struct seCallbackSaver *callback_saver);
#  else
#     define reallyPreCallback jseFuncs(call)->reallyPreCallbackFunc
#  endif
#  define PRE_CALLBACK(c,callback_saver) reallyPreCallback((c),&(callback_saver))
#endif

#if JSE_EXECUTE_SEGMENT==1
   void SE_CALL_KILL_TEMPVARS(struct seCall *call,struct seCallbackSaver *callback_saver);
#else
#  define SE_CALL_KILL_TEMPVARS jseFuncs(call)->SE_CALL_KILL_TEMPVARSFunc
#endif

#define SE_CALL_KILL_TEMPVARS_GUTS(call,callback_saver)                    \
   {                                                                       \
      SE_CALL_KILL_TEMPVARS((call),&(callback_saver));                     \
      (call)->Global->api_mark--;                                          \
   }


#if JSE_INLINES==1
#  define POST_CALLBACK(c,callback_saver) SE_CALL_KILL_TEMPVARS_GUTS((c),(callback_saver))
#else
   void reallyPostCallback(struct seCall *call, struct seCallbackSaver *callback_saver);
#  define POST_CALLBACK(c,callback_saver) reallyPostCallback((c),&(callback_saver));
#endif

#ifdef SE_RELEASE_BUILD
#  define CALL_FROM_JSECONTEXT(jsecontext)  (((struct seCall *)(jsecontext))->end)
#else
   struct seCall * CALL_FROM_JSECONTEXT(secontext se);
#endif
#define JSECONTEXT_FROM_CALL(call)  ((secontext)(call->start))
void setCallEnds(struct seCall *call); /* set all call->end and call->prev...->end to this call */

#if JSE_MEMEXT_SECODES==1
#  if JSE_MEMEXT_READONLY==1
#     define LOCK_READ_SECODES(call,locfunc)  ((secode) \
             lockMemextHandle((call),&((call)->Global->memextSecodesCache),(locfunc)->op_handle,False))
#  else
#     define LOCK_READ_SECODES(call,locfunc)  ((secode) \
             lockMemextHandle((call),&((call)->Global->memextSecodesCache),(locfunc)->op_handle))
#  endif
#else
#  define LOCK_READ_SECODES(call,locfunc)  ((locfunc)->opcodes)
#endif

   void NEAR_CALL
ErrorVPrintf(struct seCall *call, seconstcharptr FormatS,va_list arglist);

#if JSE_EXECUTE_SEGMENT==1
   void callAtError(struct seCall *call,sebool trapped, rSEVar error_obj);
#else
#  define callAtError jseFuncs(call)->callAtErrorFunc
#endif

#define CALL_AT_ERROR(call,tr,eo)                                       \
   if( (call)->Global->Params.seAtErrorFunc!=NULL )                     \
   {                                                                    \
      callAtError(call,tr,eo);                                          \
   }



/* I think that LOCATE_RECENT_OPCODE_SENAME works well, after many different test,
 * but in case it does start reporting bad things in can be turned off by defining
 * as 0 in your jseopt.h
 */
#ifndef LOCATE_RECENT_OPCODE_SENAME
#  define LOCATE_RECENT_OPCODE_SENAME 1
#endif
#if LOCATE_RECENT_OPCODE_SENAME!=0 && LOCATE_RECENT_OPCODE_SENAME!=1
#  error LOCATE_RECENT_OPCODE_SENAME must be 0 or 1
#endif
#if LOCATE_RECENT_OPCODE_SENAME==1
#  if JSE_EXECUTE_SEGMENT==1
      /* return pointer to recent name in opcodes, or "" if none (will not return NULL) */
      seconstcharptr recent_sename(struct seCall *call,uint depth);
#  endif
#endif



#if defined(__cplusplus)
   }
#endif

#endif
